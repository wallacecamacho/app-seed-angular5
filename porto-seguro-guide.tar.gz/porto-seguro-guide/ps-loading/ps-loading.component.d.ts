/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { ElementRef, AfterViewInit, OnChanges } from '@angular/core';
/**
 * `<ps-loading>`
 *
 * Componente Loading (Carregamento).
 */
export declare class PsLoadingComponent implements OnChanges {
    /** Parâmetro de entrada que define a cor de fundo do loading.  */
    _color?: string;
    /** Parâmetro de entrada que define a tamanho do loading.  */
    _size?: string;
    constructor();
    ngOnChanges(): void;
}
/**
 * `<ps-loading-bar>`
 *
 * Componente Loading Bar (Horizontal).
 */
export declare class PsLoadingBarComponent implements AfterViewInit {
    /** Parâmetro de entrada que define a cor de fundo do loading.  */
    _color?: 'white';
    /** Referência ElementRef do elemento container do spinner. */
    _psLoadingBarContainer: ElementRef;
    /** Referência ElementRef do spinner. */
    _psBarSpinner: ElementRef;
    constructor();
    ngAfterViewInit(): void;
    private animate(object, property, start_value, end_value, time);
}
