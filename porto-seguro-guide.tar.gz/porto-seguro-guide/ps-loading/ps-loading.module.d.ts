export declare class PsLoadingModule {
}
