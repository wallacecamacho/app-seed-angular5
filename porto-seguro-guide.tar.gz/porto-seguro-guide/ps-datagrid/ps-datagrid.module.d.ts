export declare class PsDatagridModule {
}
