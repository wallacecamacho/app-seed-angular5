/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit } from '@angular/core';
import { Http } from '@angular/http';
/**
 * `<ps-datagrid>`
 *
 * Componente datagrid (tabela dinâmica com paginação e filtros de busca embutidos).
 * Baseado no componente 'ngx-datatable': https://github.com/swimlane/ngx-datatable
 * Documentação: https://swimlane.gitbook.io/ngx-datatable
 */
export declare class PsDatagridComponent implements OnInit {
    http: Http;
    temp: any[];
    loadingIndicator: boolean;
    Math: any;
    page: {
        totalElements: number;
        offset: number;
        limit: number;
    };
    parameters: {
        offset: number;
        sort: string;
        order: string;
        search: string;
        field: string;
        limit: number;
    };
    pagesize: number;
    columns: any[];
    filtering: boolean;
    rows: any[];
    private searchDelay;
    constructor(http: Http);
    ngOnInit(): void;
    updateFilter(value: any, field: any): void;
    setPage(data: any): void;
    onSort(data: any): void;
}
