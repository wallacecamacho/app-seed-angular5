/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, Renderer2, ElementRef } from '@angular/core';
import { Platform } from './../util/platform.service';
/**
 * Superclasse para a família de botões. Possui métodos usados para adicionar as classes css de acordo
 * com os atributos do elemento.
 */
export declare class PsBtnBase {
    protected _renderer: Renderer2;
    protected _elementRef: ElementRef;
    protected _platform: Platform;
    constructor(_renderer: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    protected _getHostElement(): any;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    protected _hasHostAttributes(...attributes: string[]): boolean;
}
/**
 * Diretiva que define um botão secundário.
 */
export declare class PsBtnDirective extends PsBtnBase {
    /** Flag que define se o botão deve estar desabilitado.  */
    _disabled?: any;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
}
/**
 * Diretiva que define um botão primário.
 */
export declare class PsBtnPrimaryDirective extends PsBtnBase implements OnInit {
    /** Flag que define se o botão deve estar desabilitado.  */
    private _disabled?;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Método hook do angular. Adiciona a classe específica.  */
    ngOnInit(): void;
}
/**
 * Diretiva que define um botão de alerta.
 */
export declare class PsBtnAlertDirective extends PsBtnBase implements OnInit {
    /** Flag que define se o botão deve estar desabilitado.  */
    private _disabled?;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Método hook do angular. Adiciona a classe específica.  */
    ngOnInit(): void;
}
