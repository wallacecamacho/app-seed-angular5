export declare class PsBtnModule {
}
