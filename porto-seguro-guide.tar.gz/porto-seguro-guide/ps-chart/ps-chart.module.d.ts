import 'hammerjs';
export declare class PsChartModule {
}
