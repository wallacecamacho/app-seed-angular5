import { Renderer2 } from '@angular/core';
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { AfterViewInit, ElementRef, OnInit, OnChanges, SimpleChanges } from '@angular/core';
/**
 * `<ps-chart>`
 *
 * Componente para geração de gráficos (charts).
 * Baseado no componente 'ng2-charts': https://valor-software.com/ng2-charts/
 */
export declare class PsChartComponent implements OnInit, AfterViewInit, OnChanges {
    private _renderer2;
    type: string;
    source: any[];
    config: any[];
    showLegend: boolean;
    height: number;
    download: boolean;
    grafico: any;
    pschart: ElementRef;
    base64Image: ElementRef;
    chartData: any[];
    chartLabels: any[];
    psChartOptions: any;
    private width;
    private isConfigured;
    constructor(_renderer2: Renderer2);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    LoadChartData(): void;
    ChartSetup1(): void;
    ChartSetup2(): void;
    ChartSetup3(): void;
    ChartColorScheme(type: any, color: any, bgColor: any): {};
    ConvertHexToRGB(hex: any): any;
    ChartColors(type: any, idx: any, bgColor: any): {};
}
