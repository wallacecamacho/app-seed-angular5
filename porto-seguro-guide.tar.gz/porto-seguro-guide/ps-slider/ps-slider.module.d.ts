export declare class PsSliderModule {
}
