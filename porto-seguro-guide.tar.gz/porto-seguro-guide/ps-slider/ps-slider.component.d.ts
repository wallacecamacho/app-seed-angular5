/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, EventEmitter } from '@angular/core';
/**
 * `<ps-slider>`
 *
 * Componente slider.
 */
export declare class PsSliderComponent implements OnInit {
    /** Valor inicial que o slider deve ser configurado.  */
    _defaultvalue?: number;
    /** Valor mínimo do intervalo.  */
    _minvalue: number;
    /** Valor máximo do intervalo.  */
    _maxvalue: number;
    /** Unidades adicionadas ou subtraidas do valor atual do slider quando altera-se o tracker.  */
    _steps: number;
    /** Flag para disabilitar o slider.  */
    _disabled: boolean;
    /** Callback chamado a cada alteração do valor atual no slider.  */
    onChange: EventEmitter<any>;
    constructor();
    ngOnInit(): void;
    _onChange($event: any): void;
}
