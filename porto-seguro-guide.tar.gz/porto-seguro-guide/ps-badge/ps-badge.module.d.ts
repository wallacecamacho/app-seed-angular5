export declare class PsBadgeModule {
}
