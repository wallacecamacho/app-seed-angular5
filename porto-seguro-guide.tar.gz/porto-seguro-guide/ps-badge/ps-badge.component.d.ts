/**
 * `<ps-badge>`
 *
 * Componente de badge padrão (crachá).
 */
export declare class PsBadgeComponent {
    /** Valor que deverá aparecer no badge.  */
    _value: number;
    /** Define o tipo caso não seja usado o componente ps-badge-alert ou sejam criados outros tipos.  */
    _type?: string;
    constructor();
}
