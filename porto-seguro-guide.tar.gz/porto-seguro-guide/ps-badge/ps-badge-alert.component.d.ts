/**
 * `<ps-badge-alert>`
 *
 * Componente de badge (crachá) de alerta.
 */
export declare class PsBadgeAlertComponent {
    /** Valor que deverá aparecer no badge.  */
    _value: number;
    /** Define o tipo como ps-badge-alert.  */
    _type: string;
    constructor();
}
