import { Component, ComponentFactoryResolver, ContentChild, ContentChildren, Directive, ElementRef, EventEmitter, HostListener, Inject, Injectable, Injector, Input, NgModule, NgZone, Output, PLATFORM_ID, Pipe, ReflectiveInjector, Renderer2, RendererFactory2, TemplateRef, ViewChild, ViewContainerRef, ViewEncapsulation, forwardRef } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Http, HttpModule } from '@angular/http';
import { FormControl, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Observable as Observable$1 } from 'rxjs/Observable';
import { NguiAutoCompleteModule } from '@ngui/auto-complete';
import 'pikaday';
import { Subject as Subject$1 } from 'rxjs/Subject';
import { fromEvent as fromEvent$1 } from 'rxjs/observable/fromEvent';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { NgxCarouselComponent } from 'ngx-carousel/src/ngx-carousel/ngx-carousel.component';
import { NgxCarouselModule } from 'ngx-carousel';
import 'hammerjs';
import { BaseChartDirective, ChartsModule } from 'ng2-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NouisliderModule } from 'ng2-nouislider';
import { DomSanitizer } from '@angular/platform-browser';
import 'rxjs/add/observable/of';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ng-template ps-panel-head>`
 *
 * Diretiva que corresponde ao 'cabeçalho' de um componente `<ps-panel>`.
 */
var PsPanelHeadDirective = (function () {
    function PsPanelHeadDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsPanelHeadDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-panel-head]'
                },] },
    ];
    /** @nocollapse */
    PsPanelHeadDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsPanelHeadDirective;
}());
/**
 * `<ng-template ps-panel-ctt>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-panel>`.
 */
var PsPanelCttDirective = (function () {
    function PsPanelCttDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsPanelCttDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-panel-ctt]'
                },] },
    ];
    /** @nocollapse */
    PsPanelCttDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsPanelCttDirective;
}());
/**
 * `<ng-template ps-panel-foot>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-panel>`.
 */
var PsPanelFootDirective = (function () {
    function PsPanelFootDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsPanelFootDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-panel-foot]'
                },] },
    ];
    /** @nocollapse */
    PsPanelFootDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsPanelFootDirective;
}());
/**
 * `<ps-panel>`
 *
 * Componente panel.
 */
var PsPanelComponent = (function () {
    function PsPanelComponent() {
    }
    PsPanelComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-panel',
                    template: "\n        <div [ngClass]=\"{'ps-panel-ico': _icon?.length}\" class=\"ps-panel {{_type}}\">\n          <span *ngIf=\"_icon?.length\" class=\"ps-ico {{_icon}}\"></span>\n          <div *ngIf=\"_psPanelHeadTpl?.templateRef\" class=\"ps-panel-head\">\n            <ng-template [ngTemplateOutlet]=\"_psPanelHeadTpl.templateRef\"></ng-template>\n          </div>\n          <div class=\"ps-panel-ctt\">\n            <ng-template [ngTemplateOutlet]=\"_psPanelCttTpl.templateRef\"></ng-template>\n          </div>\n          <div *ngIf=\"_psPanelFootTpl?.templateRef\" class=\"ps-panel-foot\">\n            <ng-template [ngTemplateOutlet]=\"_psPanelFootTpl.templateRef\"></ng-template>\n          </div>\n        </div>"
                },] },
    ];
    /** @nocollapse */
    PsPanelComponent.ctorParameters = function () { return []; };
    PsPanelComponent.propDecorators = {
        "_type": [{ type: Input, args: ['ps-type',] },],
        "_icon": [{ type: Input, args: ['ps-icon',] },],
        "_psPanelHeadTpl": [{ type: ContentChild, args: [PsPanelHeadDirective,] },],
        "_psPanelCttTpl": [{ type: ContentChild, args: [PsPanelCttDirective,] },],
        "_psPanelFootTpl": [{ type: ContentChild, args: [PsPanelFootDirective,] },],
    };
    return PsPanelComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var nextUniqueId = 1;
/**
 * `<ps-accordion-panel>`
 *
 * Este componente corresponde ao painel (panel) de um componente `<ps-accordion>`.
 */
var PsAccordionPanelComponent = (function () {
    function PsAccordionPanelComponent() {
        /**
         * Contém o id único da painel.
         */
        this.accordionId = "ps-panel-" + nextUniqueId++;
    }
    PsAccordionPanelComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-accordion-panel',
                    template: ""
                },] },
    ];
    /** @nocollapse */
    PsAccordionPanelComponent.ctorParameters = function () { return []; };
    PsAccordionPanelComponent.propDecorators = {
        "accordionId": [{ type: Input },],
        "open": [{ type: Input },],
        "disable": [{ type: Input },],
        "_psPanelHeadDirective": [{ type: ContentChild, args: [PsPanelHeadDirective,] },],
        "_psPanelCttDirective": [{ type: ContentChild, args: [PsPanelCttDirective,] },],
        "_psPanelFootDirective": [{ type: ContentChild, args: [PsPanelFootDirective,] },],
    };
    return PsAccordionPanelComponent;
}());
/**
 * `<ps-accordion>`
 *
 * Componente que contém os painés (accordion).
 */
var PsAccordionComponent = (function () {
    function PsAccordionComponent() {
        /**
         * Id do painel(s) que deve estar selecionado.
         */
        this.activeIds = [];
        /**
         * Evento de callback quando um painel é aberto.
         */
        this._accordionOnOpen = new EventEmitter();
        /**
         * Evento de callback quando um painel é fechado.
         */
        this._accordionOnClose = new EventEmitter();
    }
    /** Método que abre o painel com o id passado como parâmetro e fecha todos os demais. Emite o evento de open.  */
    /**
     * Método que abre o painel com o id passado como parâmetro e fecha todos os demais. Emite o evento de open.
     * @param {?} accordionId
     * @return {?}
     */
    PsAccordionComponent.prototype.openAccordion = /**
     * Método que abre o painel com o id passado como parâmetro e fecha todos os demais. Emite o evento de open.
     * @param {?} accordionId
     * @return {?}
     */
    function (accordionId) {
        var /** @type {?} */ accordion = this.psAccordionPanels.find(function (p) { return p.accordionId === accordionId; });
        if (accordion && !accordion.disable) {
            accordion.open = !accordion.open;
            this._closeOthers(accordionId);
            this._updateActiveIds();
            if (accordion.open) {
                this._accordionOnOpen.emit('Open accordion');
            }
        }
    };
    /**
     * Método que fecha todos os painéis com o id diferente do especificado como parâmetro. Emite o evento de close.
     * @param {?} accordionId
     * @return {?}
     */
    PsAccordionComponent.prototype._closeOthers = /**
     * Método que fecha todos os painéis com o id diferente do especificado como parâmetro. Emite o evento de close.
     * @param {?} accordionId
     * @return {?}
     */
    function (accordionId) {
        this.psAccordionPanels.forEach(function (accordion) {
            if (accordion.accordionId !== accordionId) {
                accordion.open = false;
            }
        });
        this._accordionOnClose.emit('Close accordion');
    };
    /**
     * Atualiza a lista de Ids de accordions ativos e não desabilitados.
     * @return {?}
     */
    PsAccordionComponent.prototype._updateActiveIds = /**
     * Atualiza a lista de Ids de accordions ativos e não desabilitados.
     * @return {?}
     */
    function () {
        this.activeIds = this.psAccordionPanels.filter(function (accordion) { return accordion.open && !accordion.disable; }).map(function (panel) { return panel.accordionId; });
    };
    PsAccordionComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-accordion',
                    template: "<div class=\"ps-accordion\">\n        <p *ngIf=\"links\">\n          <a *ngFor=\"let psAccordionPanel of psAccordionPanels\"\n              href=\"javascript:;\" (click)=\"openAccordion(psAccordionPanel.accordionId)\"\n              class=\"ps-openAccordion\">\n            <ng-template [ngTemplateOutlet]=\"psAccordionPanel._psPanelHeadDirective.templateRef\"></ng-template>\n          </a>\n        </p>\n      <div class=\"ps-panel\" *ngFor=\"let psAccordionPanel of psAccordionPanels\"\n          [ngClass]=\"{'ps-accordion-opened': psAccordionPanel.open, 'ps-accordion-disabled': psAccordionPanel.disable}\"\n          id=\"{{psAccordionPanel.accordionId}}\">\n          <a href=\"javascript:;\" (click)=\"openAccordion(psAccordionPanel.accordionId)\" class=\"ps-panel-head ps-headline\">\n            <ng-template [ngTemplateOutlet]=\"psAccordionPanel._psPanelHeadDirective.templateRef\"></ng-template>\n          </a>\n          <div class=\"ps-panel-ctt-animate\">\n            <div class=\"ps-panel-ctt\">\n              <ng-template [ngTemplateOutlet]=\"psAccordionPanel._psPanelCttDirective.templateRef\"></ng-template>\n            </div>\n            <div class=\"ps-panel-foot\">\n              <ng-template [ngTemplateOutlet]=\"psAccordionPanel._psPanelFootDirective.templateRef\"></ng-template>\n            </div>\n          </div>\n\n        </div>\n    <div>",
                    styles: ["\n  .ps-accordion {\n    .ps-panel {\n      position: relative;\n\n      .ps-panel-ctt, .ps-panel-foot {\n        display: block !important;\n        opacity: 1 !important;\n      }\n\n      .ps-panel-ctt-animate {\n        max-height: 0;\n        opacity: 0;\n        overflow: hidden;\n        transition: all 500ms ease-in-out;\n      }\n\n      &.ps-accordion-opened {\n        .ps-panel-ctt-animate {\n          max-height: 10000px;\n          opacity: 1;\n        }\n      }\n    }\n  }"]
                },] },
    ];
    /** @nocollapse */
    PsAccordionComponent.ctorParameters = function () { return []; };
    PsAccordionComponent.propDecorators = {
        "activeIds": [{ type: Input },],
        "psAccordionPanels": [{ type: ContentChildren, args: [PsAccordionPanelComponent,] },],
        "links": [{ type: Input, args: ['links',] },],
        "_accordionOnOpen": [{ type: Output, args: ['accordiononopen',] },],
        "_accordionOnClose": [{ type: Output, args: ['accordiononclose',] },],
    };
    return PsAccordionComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsPanelModule = (function () {
    function PsPanelModule() {
    }
    PsPanelModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsPanelComponent,
                        PsPanelHeadDirective,
                        PsPanelCttDirective,
                        PsPanelFootDirective
                    ],
                    declarations: [
                        PsPanelComponent,
                        PsPanelHeadDirective,
                        PsPanelCttDirective,
                        PsPanelFootDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsPanelModule.ctorParameters = function () { return []; };
    return PsPanelModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsAccordionModule = (function () {
    function PsAccordionModule() {
    }
    PsAccordionModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        PsPanelModule
                    ],
                    exports: [
                        PsAccordionComponent,
                        PsAccordionPanelComponent
                    ],
                    declarations: [
                        PsAccordionComponent,
                        PsAccordionPanelComponent
                    ],
                },] },
    ];
    /** @nocollapse */
    PsAccordionModule.ctorParameters = function () { return []; };
    return PsAccordionModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-autocomplete>`
 *
 * Complemente autocomplete.
 * Baseado no componente 'ng2-ui': https://github.com/ng2-ui/auto-complete
 */
var PsAutocompleteComponent = (function () {
    function PsAutocompleteComponent(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Evento de callback quando um valor é selecionado.
         */
        this.onselect = new EventEmitter();
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    PsAutocompleteComponent.prototype._onselect = /**
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
        this.onselect.emit($event);
    };
    /**
     * @return {?}
     */
    PsAutocompleteComponent.prototype.getSelected = /**
     * @return {?}
     */
    function () {
        return this.selected;
    };
    PsAutocompleteComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-autocomplete',
                    template: "<input type=\"text\"\n                       name=\"{{_name}}\"\n                       class=\"ps-frm-entry\"\n                       placeholder=\"{{_placeholder}}\"\n                       auto-complete\n                       [(ngModel)]=\"selected\"\n                       [source]=\"_source\"\n                       [min-chars]=\"_minlength\"\n                       (valueChanged)=\"_onselect($event)\"\n                       [no-match-found-text]=\"'Nenhum resultado encontrado'\"\n                       [loading-text]=\"'Carregando...'\"/>",
                    styles: ["\n  @keyframes slideDown {\n    0% {\n        transform: translateY(-10px);\n    }\n    100% {\n        transform: translateY(0px);\n    }\n  }\n  .ngui-auto-complete {\n      background-color: transparent;\n  }\n  .ngui-auto-complete > input {\n      outline: none;\n      border: 0;\n      padding: 2px;\n      box-sizing: border-box;\n      background-clip: content-box;\n  }\n  .ngui-auto-complete > ul {\n      background-color: #fff;\n      color: #1c1c1c;\n      font-size: 15px;\n      box-shadow: 0 2px 3px 0 rgba(0,0,0,.1);\n      border: none !important;\n      margin: 0;\n      width: 100%;\n      overflow-y: auto;\n      list-style-type: none;\n      padding: 0;\n      box-sizing: border-box;\n      animation: slideDown 0.3s;\n  }\n  .ngui-auto-complete > ul.empty {\n      display: none;\n      font-style: italic !important;\n  }\n  .ngui-auto-complete > ul li {\n      padding: 7px 10.5px !important;\n      border: none !important;\n  }\n  .ngui-auto-complete > ul li.selected {\n      font-weight: bold;\n      background: none !important;\n  }\n  .ngui-auto-complete > ul li:hover {\n      font-weight: bold;\n  }\n"],
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsAutocompleteComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsAutocompleteComponent.propDecorators = {
        "_name": [{ type: Input, args: ['name',] },],
        "_placeholder": [{ type: Input, args: ['placeholder',] },],
        "_minlength": [{ type: Input, args: ['minlength',] },],
        "_source": [{ type: Input, args: ['source',] },],
        "onselect": [{ type: Output },],
    };
    return PsAutocompleteComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsAutocompleteModule = (function () {
    function PsAutocompleteModule() {
    }
    PsAutocompleteModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        HttpModule,
                        FormsModule,
                        NguiAutoCompleteModule
                    ],
                    exports: [
                        PsAutocompleteComponent
                    ],
                    declarations: [
                        PsAutocompleteComponent
                    ]
                },] },
    ];
    /** @nocollapse */
    PsAutocompleteModule.ctorParameters = function () { return []; };
    return PsAutocompleteModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-badge>`
 *
 * Componente de badge padrão (crachá).
 */
var PsBadgeComponent = (function () {
    function PsBadgeComponent() {
    }
    PsBadgeComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-badge',
                    template: "<sup class=\"ps-badge {{_type}}\">{{_value}}</sup>"
                },] },
    ];
    /** @nocollapse */
    PsBadgeComponent.ctorParameters = function () { return []; };
    PsBadgeComponent.propDecorators = {
        "_value": [{ type: Input, args: ['ps-value',] },],
        "_type": [{ type: Input, args: ['ps-type',] },],
    };
    return PsBadgeComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-badge-alert>`
 *
 * Componente de badge (crachá) de alerta.
 */
var PsBadgeAlertComponent = (function () {
    function PsBadgeAlertComponent() {
        /**
         * Define o tipo como ps-badge-alert.
         */
        this._type = 'ps-badge-alert';
    }
    PsBadgeAlertComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-badge-alert',
                    template: "<sup class=\"ps-badge {{_type}}\">{{_value}}</sup>"
                },] },
    ];
    /** @nocollapse */
    PsBadgeAlertComponent.ctorParameters = function () { return []; };
    PsBadgeAlertComponent.propDecorators = {
        "_value": [{ type: Input, args: ['ps-value',] },],
        "_type": [{ type: Input, args: ['ps-type',] },],
    };
    return PsBadgeAlertComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsBadgeModule = (function () {
    function PsBadgeModule() {
    }
    PsBadgeModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsBadgeComponent,
                        PsBadgeAlertComponent
                    ],
                    declarations: [
                        PsBadgeComponent,
                        PsBadgeAlertComponent
                    ],
                },] },
    ];
    /** @nocollapse */
    PsBadgeModule.ctorParameters = function () { return []; };
    return PsBadgeModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
// Whether the current platform supports the V8 Break Iterator. The V8 check
// is necessary to detect all Blink based browsers.
var hasV8BreakIterator = (typeof Intl !== 'undefined' && (/** @type {?} */ (Intl)).v8BreakIterator);
/**
 * Service to detect the current platform by comparing the userAgent strings and
 * checking browser-specific global properties.
 */
var Platform = (function () {
    function Platform() {
        /**
         * Whether the Angular application is being rendered in the browser.
         */
        this.isBrowser = typeof document === 'object' && !!document;
        /**
         * Whether the current browser is Microsoft Edge.
         */
        this.EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent);
        /**
         * Whether the current rendering engine is Microsoft Trident.
         */
        this.TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent);
        /**
         * Whether the current rendering engine is Blink.
         */
        this.BLINK = this.isBrowser && (!!((/** @type {?} */ (window)).chrome || hasV8BreakIterator) &&
            typeof CSS !== 'undefined' && !this.EDGE && !this.TRIDENT);
        /**
         * Whether the current rendering engine is WebKit.
         */
        this.WEBKIT = this.isBrowser &&
            /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT;
        /**
         * Whether the current platform is Apple iOS.
         */
        this.IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) &&
            !(/** @type {?} */ (window)).MSStream;
        /**
         * Whether the current browser is Firefox.
         */
        this.FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent);
        /**
         * Whether the current platform is Android.
         */
        this.ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT;
        /**
         * Whether the current browser is Safari.
         */
        this.SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT;
        /**
         * @license
         * Copyright Porto Seguro All Rights Reserved.
         * @author
         * Porto Seguro https://www.portoseguro.com.br
         *
         */
        this.IsMobile = false;
        this.IsTablet = false;
        this.IsTabletPortrait = false;
        this.IsDesktop = false;
        this.IsHD = false;
    }
    /**
     * @param {?=} userAgent
     * @return {?}
     */
    Platform.prototype.detectMobile = /**
     * @param {?=} userAgent
     * @return {?}
     */
    function (userAgent) {
        if (userAgent === void 0) { userAgent = navigator.userAgent; }
        // valores do http://detectmobilebrowsers.com/
        var /** @type {?} */ mobile = {
            detectMobileBrowsers: {
                fullPattern: /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i,
                shortPattern: /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i
            }
        };
        return mobile.detectMobileBrowsers.fullPattern.test(userAgent) ||
            mobile.detectMobileBrowsers.shortPattern.test(userAgent.substr(0, 4));
    };
    /**
     * @param {?=} userAgent
     * @return {?}
     */
    Platform.prototype.detectTablet = /**
     * @param {?=} userAgent
     * @return {?}
     */
    function (userAgent) {
        if (userAgent === void 0) { userAgent = navigator.userAgent; }
        // valores do http://detectmobilebrowsers.com/
        var /** @type {?} */ tablets = {
            detectMobileBrowsers: {
                tabletPattern: /android|ipad|playbook|silk/i
            }
        };
        return tablets.detectMobileBrowsers.tabletPattern.test(userAgent);
    };
    /**
     * @return {?}
     */
    Platform.prototype.setScreen = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ w = window.innerWidth, /** @type {?} */
        orientation = window.matchMedia('(orientation: portrait)').matches;
        if (w > 990) {
            this.IsDesktop = true;
        }
        if (w > 1206) {
            this.IsHD = true;
        }
        if (this.detectMobile(navigator.userAgent)) {
            this.IsMobile = true;
        }
        if (this.detectTablet(navigator.userAgent)) {
            this.IsTablet = true;
            if (orientation) {
                this.IsTabletPortrait = true;
            }
            else {
                this.IsTabletPortrait = false;
            }
            var /** @type {?} */ platform_1 = this;
            window.addEventListener('orientationchange', function () {
                if (screen['orientation'].angle === 0) {
                    platform_1.IsTabletPortrait = true;
                }
                else {
                    platform_1.IsTabletPortrait = false;
                }
            });
        }
        if (navigator.appVersion.indexOf('MSIE 8') > -1) {
            this.IsMobile = false;
            this.IsTablet = false;
            this.IsDesktop = true;
            this.IsHD = false;
            document.getElementsByTagName('html').item(0).classList.add('lt-ie9');
        }
    };
    Platform.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    Platform.ctorParameters = function () { return []; };
    return Platform;
}());

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Classes css para configurar diferentes estilos de botões.
 */
var PS_BTN_HOST_ATTRIBUTES = [
    'matte-dark',
    'inline',
    'ico',
    'ico-right',
    'rounded',
];
/**
 * Prefixo das classes css, usado para concatenar nas propriedades definidas no elemento.
 */
var PS_BTN_PREFIX = 'ps-btn-';
/**
 * Superclasse para a família de botões. Possui métodos usados para adicionar as classes css de acordo
 * com os atributos do elemento.
 */
var PsBtnBase = (function () {
    function PsBtnBase(_renderer, _elementRef, _platform) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
        this._platform = _platform;
        _renderer.addClass(_elementRef.nativeElement, 'ps-btn');
        for (var _i = 0, PS_BTN_HOST_ATTRIBUTES_1 = PS_BTN_HOST_ATTRIBUTES; _i < PS_BTN_HOST_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_BTN_HOST_ATTRIBUTES_1[_i];
            if (this._hasHostAttributes(attribute)) {
                (/** @type {?} */ (this._elementRef.nativeElement)).classList.add(PS_BTN_PREFIX + attribute);
            }
        }
        if (this._hasHostAttributes('disabled')) {
            this._renderer.addClass(this._elementRef.nativeElement, PS_BTN_PREFIX + 'disabled');
        }
    }
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    PsBtnBase.prototype._getHostElement = /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsBtnBase.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        if (!this._platform.isBrowser) {
            return false;
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    return PsBtnBase;
}());
/**
 * Diretiva que define um botão secundário.
 */
var PsBtnDirective = (function (_super) {
    __extends(PsBtnDirective, _super);
    function PsBtnDirective(_renderer2, _elementRef, _platform) {
        return _super.call(this, _renderer2, _elementRef, _platform) || this;
    }
    PsBtnDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-btn]'
                },] },
    ];
    /** @nocollapse */
    PsBtnDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
    ]; };
    PsBtnDirective.propDecorators = {
        "_disabled": [{ type: Input, args: ['disabled',] },],
    };
    return PsBtnDirective;
}(PsBtnBase));
/**
 * Diretiva que define um botão primário.
 */
var PsBtnPrimaryDirective = (function (_super) {
    __extends(PsBtnPrimaryDirective, _super);
    function PsBtnPrimaryDirective(_renderer2, _elementRef, _platform) {
        return _super.call(this, _renderer2, _elementRef, _platform) || this;
    }
    /** Método hook do angular. Adiciona a classe específica.  */
    /**
     * Método hook do angular. Adiciona a classe específica.
     * @return {?}
     */
    PsBtnPrimaryDirective.prototype.ngOnInit = /**
     * Método hook do angular. Adiciona a classe específica.
     * @return {?}
     */
    function () {
        this._renderer.addClass(this._elementRef.nativeElement, PS_BTN_PREFIX + 'primary');
    };
    PsBtnPrimaryDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-btn-primary]'
                },] },
    ];
    /** @nocollapse */
    PsBtnPrimaryDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
    ]; };
    PsBtnPrimaryDirective.propDecorators = {
        "_disabled": [{ type: Input, args: ['disabled',] },],
    };
    return PsBtnPrimaryDirective;
}(PsBtnBase));
/**
 * Diretiva que define um botão de alerta.
 */
var PsBtnAlertDirective = (function (_super) {
    __extends(PsBtnAlertDirective, _super);
    function PsBtnAlertDirective(_renderer2, _elementRef, _platform) {
        return _super.call(this, _renderer2, _elementRef, _platform) || this;
    }
    /** Método hook do angular. Adiciona a classe específica.  */
    /**
     * Método hook do angular. Adiciona a classe específica.
     * @return {?}
     */
    PsBtnAlertDirective.prototype.ngOnInit = /**
     * Método hook do angular. Adiciona a classe específica.
     * @return {?}
     */
    function () {
        this._renderer.addClass(this._elementRef.nativeElement, PS_BTN_PREFIX + 'alert');
    };
    PsBtnAlertDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-btn-alert]'
                },] },
    ];
    /** @nocollapse */
    PsBtnAlertDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
    ]; };
    PsBtnAlertDirective.propDecorators = {
        "_disabled": [{ type: Input, args: ['disabled',] },],
    };
    return PsBtnAlertDirective;
}(PsBtnBase));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsBtnModule = (function () {
    function PsBtnModule() {
    }
    PsBtnModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsBtnDirective,
                        PsBtnPrimaryDirective,
                        PsBtnAlertDirective
                    ],
                    declarations: [
                        PsBtnDirective,
                        PsBtnPrimaryDirective,
                        PsBtnAlertDirective
                    ],
                    providers: [
                        Platform
                    ]
                },] },
    ];
    /** @nocollapse */
    PsBtnModule.ctorParameters = function () { return []; };
    return PsBtnModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsCalendarModel = (function () {
    function PsCalendarModel() {
    }
    /**
     * @param {?} dateString
     * @return {?}
     */
    PsCalendarModel.getDateFromStr = /**
     * @param {?} dateString
     * @return {?}
     */
    function (dateString) {
        var /** @type {?} */ day = parseInt(dateString.substring(0, 2));
        var /** @type {?} */ month = parseInt(dateString.substring(3, 5));
        var /** @type {?} */ year = parseInt(dateString.substring(6, 10));
        var /** @type {?} */ date = new Date(year, month - 1, day);
        return date;
    };
    /**
     * @param {?} date
     * @return {?}
     */
    PsCalendarModel.getFormattedDate = /**
     * @param {?} date
     * @return {?}
     */
    function (date) {
        var /** @type {?} */ day = date.getDate();
        var /** @type {?} */ month = date.getMonth() + 1;
        var /** @type {?} */ year = date.getFullYear();
        return this.paddingNumber(day) + "/" + this.paddingNumber(month) + "/" + year;
    };
    /**
     * @param {?} dateString
     * @return {?}
     */
    PsCalendarModel.getISOFormattedDate = /**
     * @param {?} dateString
     * @return {?}
     */
    function (dateString) {
        var /** @type {?} */ date = this.getDateFromStr(dateString);
        var /** @type {?} */ day = date.getDate();
        var /** @type {?} */ month = date.getMonth() + 1;
        var /** @type {?} */ year = date.getFullYear();
        return year + "-" + this.paddingNumber(month) + "-" + this.paddingNumber(day);
    };
    /**
     * @param {?} dateString
     * @return {?}
     */
    PsCalendarModel.getISODateFromStr = /**
     * @param {?} dateString
     * @return {?}
     */
    function (dateString) {
        var /** @type {?} */ year = parseInt(dateString.substring(0, 4));
        var /** @type {?} */ month = parseInt(dateString.substring(5, 7));
        var /** @type {?} */ day = parseInt(dateString.substring(8, 10));
        var /** @type {?} */ date = new Date(year, month - 1, day);
        return date;
    };
    /**
     * @param {?} num
     * @return {?}
     */
    PsCalendarModel.paddingNumber = /**
     * @param {?} num
     * @return {?}
     */
    function (num) {
        if (num < 10) {
            return "0" + num;
        }
        return num;
    };
    PsCalendarModel.setDefaultDate = true;
    PsCalendarModel.disableWeekends = false;
    PsCalendarModel.format = 'D/M/YYYY';
    PsCalendarModel.i18n = {
        previousMonth: '<span>Mês anterior</span>',
        nextMonth: '<span>Próximo mês</span>',
        months: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
            'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        weekdays: ['Domingo',
            'Segunda-feira',
            'Terça',
            'Quarta-feira',
            'Quinta-feira',
            'Sexta-feira',
            'Sábado'],
        weekdaysShort: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S']
    };
    return PsCalendarModel;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Classe que contém o css dos componentes PsCalendar e PsCalendarAvailability.
 * Obs.: Não foi usado um arquivo .scss por motivos de build da lib.
 *
 */
var PsCalendarStyle = (function () {
    function PsCalendarStyle() {
    }
    PsCalendarStyle.styles = [
        "@charset \"UTF-8\";\n        .pika-single {\n          z-index: 1;\n          display: block;\n          position: relative;\n          color: #1c1c1c !important;\n          background: #fff !important;\n          border: none;\n          border-bottom-color: none;\n          font-family: \"Open Sans\", sans-serif !important;\n        }\n        .pika-single.is-hidden {\n          display: none;\n        }\n        .pika-single.is-bound {\n          position: absolute;\n          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);\n          padding-top: 75px;\n          z-index: 9999;\n        }\n        .pika-single.is-bound:before {\n          content: \"Calend\u00E1rio\";\n          width: 100%;\n          height: 60px;\n          position: absolute;\n          left: 0px;\n          top: 0px;\n          text-align: center;\n          text-transform: uppercase;\n          color: #1c1c1c;\n          opacity: 0.6;\n          font-size: 11px;\n          font-weight: 600;\n          letter-spacing: 1px;\n          line-height: 55px;\n          border-bottom: 1px solid #c7c7c7;\n        }\n\n        .pika-single {\n          *zoom: 1;\n        }\n        .pika-single:before, .pika-single:after {\n          content: \" \";\n          display: table;\n        }\n        .pika-single:after {\n          clear: both;\n        }\n\n        .pika-lendar {\n          float: left;\n          width: 320px;\n          padding: 15px;\n          margin: 0;\n        }\n\n        .is-bound .pika-lendar {\n          padding-top: 0;\n        }\n\n        .pika-title {\n          position: relative;\n          text-align: center;\n          padding: 0 0 20px 0;\n        }\n        .pika-title select {\n          cursor: pointer;\n          position: absolute;\n          z-index: 9998;\n          margin: 0;\n          left: 50%;\n          top: 5px;\n          filter: alpha(opacity=0);\n          transform: translateX(-50%);\n          opacity: 0;\n        }\n\n        .pika-label {\n          display: block;\n          *display: inline;\n          position: relative;\n          z-index: 1;\n          overflow: hidden;\n          margin: 0;\n          padding: 0;\n          font-size: 12px;\n          text-transform: uppercase;\n          line-height: 20px;\n          letter-spacing: 1px;\n          font-weight: 400;\n          color: #1c1c1c !important;\n        }\n        .pika-label:first-child {\n          font-size: 10px;\n        }\n\n        .pika-prev,\n        .pika-next {\n          display: block;\n          cursor: pointer;\n          position: absolute;\n          z-index: 2;\n          top: 7px;\n          outline: none;\n          border: 0;\n          padding: 0;\n          width: 33px;\n          height: 33px;\n          text-indent: 0px;\n          white-space: nowrap;\n          overflow: hidden;\n          background: none !important;\n          opacity: 1;\n        }\n        .pika-prev span,\n        .pika-next span {\n          display: none;\n        }\n        .pika-prev:after,\n        .pika-next:after {\n          content: \"\";\n          display: inline-block;\n          position: absolute;\n          top: 0;\n          left: 0;\n          display: block;\n          font-family: \"ps_glyph_icons\";\n          line-height: 33px;\n          font-size: 16px;\n          color: #c7c7c7;\n          z-index: 3;\n          text-align: center;\n          letter-spacing: 0;\n        }\n        .pika-prev:hover,\n        .pika-next:hover {\n          opacity: 1;\n        }\n        .pika-prev:hover:after,\n        .pika-next:hover:after {\n          color: #1c1c1c;\n        }\n        .pika-prev.is-disabled,\n        .pika-next.is-disabled {\n          cursor: default;\n          opacity: 0.2;\n        }\n\n        .pika-prev,\n        .is-rtl .pika-next {\n          float: none !important;\n          left: 0;\n        }\n        .pika-prev:after,\n        .is-rtl .pika-next:after {\n          content: \"\\e961\";\n        }\n\n        .pika-next,\n        .is-rtl .pika-prev {\n          float: none !important;\n          right: 0;\n          text-indent: 20px;\n        }\n        .pika-next:after,\n        .is-rtl .pika-prev:after {\n          content: \"\\e962\";\n        }\n\n        .pika-select {\n          display: inline-block;\n          *display: inline;\n        }\n\n        .pika-table {\n          width: 100%;\n          border-collapse: collapse;\n          border-spacing: 0;\n          border: 0;\n        }\n        .pika-table th,\n        .pika-table td {\n          width: 14.2857142857%;\n          padding: 0;\n          text-align: center;\n          font-family: \"Open Sans\", sans-serif !important;\n        }\n        .pika-table th {\n          color: #1c1c1c;\n          font-size: 11px;\n          line-height: 15px;\n          font-weight: 400;\n          text-align: center;\n        }\n        .pika-table th:nth-child(1), .pika-table th:nth-child(7) {\n          color: #9c9c9c;\n        }\n        .pika-table abbr {\n          text-decoration: none;\n          border-bottom: none;\n          cursor: help;\n          display: inline-block;\n          height: 35px;\n        }\n\n        .pika-button {\n          cursor: pointer;\n          display: inline-block !important;\n          -moz-box-sizing: border-box;\n          box-sizing: border-box;\n          outline: none;\n          border: 0;\n          margin: 0;\n          width: 35px;\n          height: 35px;\n          padding: 0.4em 0.3em;\n          border-radius: 50%;\n          transition: all ease 0.3s;\n          background: none;\n          color: #1c1c1c;\n          font-size: 14px;\n          border: 2px solid transparent;\n          text-align: center;\n          font-weight: bold;\n          font-family: \"Open Sans\", sans-serif !important;\n        }\n        .is-selected .pika-button {\n          border-color: #33BFFF !important;\n          background: none !important;\n          box-shadow: none !important;\n          color: #1c1c1c !important;\n          border-radius: 50% !important;\n        }\n        .is-disabled .pika-button, .is-outside-current-month .pika-button {\n          color: #9c9c9c;\n          background: none !important;\n        }\n        .is-disabled .pika-button {\n          pointer-events: none;\n          cursor: default;\n        }\n        .pika-button:hover {\n          background: #f1f1f1 !important;\n          border-radius: 50% !important;\n          color: #1c1c1c !important;\n        }\n        .pika-button .is-selection-disabled {\n          pointer-events: none;\n          cursor: default;\n        }\n\n        .pika-week {\n          font-size: 11px;\n          color: #999 !important;\n        }\n\n        .is-inrange .pika-button {\n          background: #D5E9F7;\n        }\n\n        .is-startrange .pika-button {\n          color: #fff;\n          background: #6CB31D;\n          box-shadow: none;\n          border-radius: 3px;\n        }\n\n        .is-endrange .pika-button {\n          color: #fff;\n          background: #33aaff;\n          box-shadow: none;\n          border-radius: 3px;\n        }\n\n        .pika-close {\n          position: absolute;\n          display: inline-block;\n          top: 17px;\n          right: 0;\n          width: 30px;\n          height: 30px;\n          color: #C7C7C7;\n          transition: all ease 0.3s;\n          font-size: 16px;\n          text-decoration: none;\n          font-weight: 700;\n        }\n        .pika-close:hover {\n          color: #33BFFF;\n        }\n        .pika-close:before {\n          content: \"\\e969\";\n          font-family: \"ps_glyph_icons\";\n        }"
    ];
    return PsCalendarStyle;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(function () { return PsCalendarComponent; }),
    multi: true
};
var nextUniqueId$1 = 0;
/**
 * `<ps-calendar>`
 *
 * Componente que define um calendário (Datepicker).
 * Usa o JavaScript Datepicker: https://github.com/dbushell/Pikaday
 */
var PsCalendarComponent = (function () {
    function PsCalendarComponent(_renderer2, _plaftform, _elementRef) {
        this._renderer2 = _renderer2;
        this._plaftform = _plaftform;
        this._elementRef = _elementRef;
        /**
         * Placeholder input
         */
        this._placeholder = 'Selecione uma data';
        /**
         * Entrada de controle de formulário. Útil na validação e acesso ao controle de formulários.
         */
        this.formControl = new FormControl();
        /**
         * Evento de callback quando uma data é selecionada.
         */
        this.onSelect = new EventEmitter();
        /**
         * Id único para o calendário.
         */
        this._calendarId = "Calendar" + nextUniqueId$1++;
        /**
         * Erros para o controle de formulário serão armazenados neste array.
         */
        this.errors = ['Este campo é obrigatório'];
        this.innerValue = '';
        /* Propagar alterações no controle de formulário personalizado. */
        this.propagateChange = function (_) { };
        this._onTouched = function () { };
        this._plaftform.setScreen();
        this._isMobile = this._plaftform.IsMobile;
    }
    /** Método hook do angular. Instancia e configura o calendário.  */
    /**
     * Método hook do angular. Instancia e configura o calendário.
     * @return {?}
     */
    PsCalendarComponent.prototype.ngOnInit = /**
     * Método hook do angular. Instancia e configura o calendário.
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        self._pikaday = new Pikaday({
            field: self._getHostElement(),
            setDefaultDate: PsCalendarModel.setDefaultDate,
            disableWeekends: PsCalendarModel.disableWeekends,
            format: !self._format ? PsCalendarModel.format : self._format,
            defaultDate: (self._defaultdate) ? PsCalendarModel.getDateFromStr(self._defaultdate) : null,
            minDate: (self._mindate) ? PsCalendarModel.getDateFromStr(self._mindate) : null,
            maxDate: (self._maxdate) ? PsCalendarModel.getDateFromStr(self._maxdate) : null,
            toString: /**
             * @param {?} date
             * @param {?} format
             * @return {?}
             */
            function (date, format) {
                return PsCalendarModel.getFormattedDate(date);
            },
            i18n: PsCalendarModel.i18n,
            onSelect: function (date) {
                self.onSelect.emit(PsCalendarModel.getFormattedDate(date));
            },
            onOpen: function () {
                self._createCloseElement(self._pikaday.el);
            }
        });
        if (self._isMobile) {
            self._renderer2.setAttribute(self._getHostElement(), 'type', 'hidden');
            self._renderer2.setAttribute(self._elementRef.nativeElement, 'id', this._calendarId);
        }
        else {
            self._renderer2.setAttribute(self._elementRef.nativeElement, 'id', this._calendarId);
        }
        if (typeof self._mindate !== 'undefined') {
            self._renderer2.setAttribute(self._getMobileHostElement(), 'min', PsCalendarModel.getISOFormattedDate(self._mindate));
        }
        if (typeof self._maxdate !== 'undefined') {
            self._renderer2.setAttribute(self._getMobileHostElement(), 'max', PsCalendarModel.getISOFormattedDate(self._maxdate));
        }
    };
    /**
     * @return {?}
     */
    PsCalendarComponent.prototype.ngOnChanges = /**
     * @return {?}
     */
    function () { };
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    PsCalendarComponent.prototype.ngAfterViewInit = /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    function () {
        var _this = this;
        /** Set placeholder default value when no input given to pH property.  */
        if (this._placeholder === undefined) {
            this._placeholder = 'Selecione uma data.';
        }
        /** RESET the custom input form control UI when the form control is RESET  */
        this.formControl.valueChanges.subscribe(function () {
            /** check condition if the form control is RESET  */
            if (_this.formControl.value === '' || _this.formControl.value === null || _this.formControl.value === undefined) {
                _this.innerValue = '';
                _this._datepicker.nativeElement.value = '';
            }
        });
    };
    /**
     * Evento acionado quando o valor de entrada é alterado.
     * Posteriormente propagado até o controle de formulário usando a
     * interface acessadora de valor personalizado.
     * */
    /**
     * Evento acionado quando o valor de entrada é alterado.
     * Posteriormente propagado até o controle de formulário usando a
     * interface acessadora de valor personalizado.
     *
     * @param {?} e
     * @param {?} value
     * @return {?}
     */
    PsCalendarComponent.prototype.onChange = /**
     * Evento acionado quando o valor de entrada é alterado.
     * Posteriormente propagado até o controle de formulário usando a
     * interface acessadora de valor personalizado.
     *
     * @param {?} e
     * @param {?} value
     * @return {?}
     */
    function (e, value) {
        /* Defini o valor alterado. */
        this.innerValue = value;
        /* Propaga o valor no controle de formulário usando interface acessadora de valor de controle. */
        this.propagateChange(this.innerValue);
        this._onTouched();
        /* Reseta os errors.  */
        this.errors = [];
        /**
             * Configuração, redefinindo mensagens de erro em um array (para loop) e adicionando
             * as mensagens de validação para mostrar abaixo da área de campo.
             */
        for (var /** @type {?} */ key in this.formControl.errors) {
            if (this.formControl.errors.hasOwnProperty(key)) {
                if (key === 'required') {
                    this.errors.push('This field is required');
                }
                else {
                    this.errors.push(this.formControl.errors[key]);
                }
            }
        }
    };
    /**
     * @return {?}
     */
    PsCalendarComponent.prototype.onblur = /**
     * @return {?}
     */
    function () {
        this._onTouched();
    };
    Object.defineProperty(PsCalendarComponent.prototype, "value", {
        /* Recuperar o valor. */
        get: /**
         * @return {?}
         */
        function () {
            return this.innerValue;
        },
        /* Seta o valor incluindo chamar o retorno de chamada onchange. */
        set: /**
         * @param {?} v
         * @return {?}
         */
        function (v) {
            if (v !== this.innerValue) {
                this.innerValue = v;
            }
        },
        enumerable: true,
        configurable: true
    });
    /* From ControlValueAccessor interface */
    /**
     * @param {?} value
     * @return {?}
     */
    PsCalendarComponent.prototype.writeValue = /**
     * @param {?} value
     * @return {?}
     */
    function (value) {
        this.innerValue = value;
    };
    /* From ControlValueAccessor interface */
    /**
     * @param {?} fn
     * @return {?}
     */
    PsCalendarComponent.prototype.registerOnChange = /**
     * @param {?} fn
     * @return {?}
     */
    function (fn) {
        this.propagateChange = fn;
    };
    /* From ControlValueAccessor interface */
    /**
     * @param {?} fn
     * @return {?}
     */
    PsCalendarComponent.prototype.registerOnTouched = /**
     * @param {?} fn
     * @return {?}
     */
    function (fn) {
        this._onTouched = fn;
    };
    /** Permite que o Angular desative o input. */
    /**
     * Permite que o Angular desative o input.
     * @param {?} isDisabled
     * @return {?}
     */
    PsCalendarComponent.prototype.setDisabledState = /**
     * Permite que o Angular desative o input.
     * @param {?} isDisabled
     * @return {?}
     */
    function (isDisabled) {
        if (this._isMobile) {
            this._renderer2.setProperty(this._getMobileHostElement(), 'disabled', isDisabled);
        }
        else {
            this._renderer2.setProperty(this._getHostElement(), 'disabled', isDisabled);
        }
    };
    /**
     * Método que cria o link e registra o evento de fechar o calendário.
     * @param {?} calendarElement
     * @return {?}
     */
    PsCalendarComponent.prototype._createCloseElement = /**
     * Método que cria o link e registra o evento de fechar o calendário.
     * @param {?} calendarElement
     * @return {?}
     */
    function (calendarElement) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ span = self._renderer2.createElement('span');
        span.innerText = '';
        var /** @type {?} */ a = self._renderer2.createElement('a');
        self._renderer2.setAttribute(a, 'href', 'javascript:;');
        self._renderer2.addClass(a, 'pika-close');
        self._renderer2.appendChild(a, span);
        calendarElement.insertBefore(a, calendarElement.firstChild);
        a.addEventListener('click', function () {
            self._getHostElement().blur();
        });
    };
    /** Método que valida a data no ambiente mobile, pois o calendário usado é o nativo do browser.  */
    /**
     * Método que valida a data no ambiente mobile, pois o calendário usado é o nativo do browser.
     * @return {?}
     */
    PsCalendarComponent.prototype.validateCalendarMobile = /**
     * Método que valida a data no ambiente mobile, pois o calendário usado é o nativo do browser.
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        var /** @type {?} */ v = self._getMobileHostElement().value;
        var /** @type {?} */ vDate = new Date(PsCalendarModel.getISODateFromStr(v));
        var /** @type {?} */ nV = '';
        var /** @type {?} */ error = 0;
        if (typeof self._mindate !== 'undefined') {
            var /** @type {?} */ dateArray = self._mindate.split('/');
            var /** @type {?} */ minDate = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0];
            var /** @type {?} */ minDateArray = minDate.split('-');
            var /** @type {?} */ minDateArrayInt = [];
            for (var /** @type {?} */ i = 0, /** @type {?} */ l = minDateArray.length; i < l; i++) {
                minDateArrayInt[i] = parseInt(minDateArray[i]);
            }
            var /** @type {?} */ valMinDate = new Date(minDateArrayInt[0], minDateArrayInt[1] - 1, minDateArrayInt[2]);
            if (vDate < valMinDate) {
                alert('Data inválida, a data mínima permitida é ' + PsCalendarModel.getFormattedDate(valMinDate));
                error++;
            }
        }
        if (typeof self._maxdate !== 'undefined') {
            var /** @type {?} */ dateArray = self._maxdate.split('/');
            var /** @type {?} */ maxDate = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0];
            var /** @type {?} */ maxDateArray = maxDate.split('-');
            var /** @type {?} */ maxDateArrayInt = [];
            for (var /** @type {?} */ i = 0, /** @type {?} */ l = maxDateArray.length; i < l; i++) {
                maxDateArrayInt[i] = parseInt(maxDateArray[i]);
            }
            var /** @type {?} */ valMaxDate = new Date(maxDateArrayInt[0], maxDateArrayInt[1] - 1, maxDateArrayInt[2]);
            if (vDate > valMaxDate) {
                alert('Data inválida, a data máxima permitida é ' + PsCalendarModel.getFormattedDate(valMaxDate));
                error++;
            }
        }
        if (error > 0) {
            self._renderer2.addClass(self._getMobileHostElement(), 'ps-frm-error');
        }
        else {
            self._renderer2.removeClass(self._getMobileHostElement(), 'ps-frm-error');
        }
        v = v.split('-');
        nV = v[2] + '/' + v[1] + '/' + v[0];
        self._getHostElement().value = nV;
        self.onSelect.emit(nV);
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsCalendarComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._datepicker.nativeElement;
    };
    /**
     * Retorna uma referência HTMLElement do componente na versão mobile.
     * @return {?}
     */
    PsCalendarComponent.prototype._getMobileHostElement = /**
     * Retorna uma referência HTMLElement do componente na versão mobile.
     * @return {?}
     */
    function () {
        return this._datepickerMobile.nativeElement;
    };
    PsCalendarComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-calendar',
                    template: "<input type=\"text\" name=\"{{_name}}\"\n                                id=\"{{_id}}\"\n                                mask=\"99/99/9999\"\n                                class=\"ps-frm-entry\"\n                                [ngClass]=\"{'ps-mob-dateBuffer': _isMobile}\"\n                                autocomplete=\"off\"\n                                autocorrect=\"off\"\n                                autocapitalize=\"off\"\n                                spellcheck=\"false\"\n                                placeholder=\"{{_placeholder}}\"\n                                (blur)=\"onChange($event, datepicker.value); _onTouched();\"\n                                #datepicker/>\n            <input type=\"date\" [ngStyle]=\"{'display': _isMobile ? 'block' : 'none'}\"\n                                (blur)=\"validateCalendarMobile()\"\n                                name=\"\"\n                                class=\"ps-frm-entry ps-frm-valid ps-mob-dateBuffer\"\n                                min=\"\"\n                                max=\"\"\n                                value=\"\"\n                                placeholder=\"{{_placeholder}}\"\n                                (blur)=\"onChange($event, datepickerMobile.value); _onTouched();\"\n                                required\n                                #datepickerMobile/>",
                    styles: PsCalendarStyle.styles,
                    encapsulation: ViewEncapsulation.None,
                    providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
                },] },
    ];
    /** @nocollapse */
    PsCalendarComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: Platform, },
        { type: ElementRef, },
    ]; };
    PsCalendarComponent.propDecorators = {
        "_name": [{ type: Input, args: ['name',] },],
        "_placeholder": [{ type: Input, args: ['placeholder',] },],
        "_id": [{ type: Input, args: ['id',] },],
        "_defaultdate": [{ type: Input, args: ['defaultdate',] },],
        "_mindate": [{ type: Input, args: ['mindate',] },],
        "_maxdate": [{ type: Input, args: ['maxdate',] },],
        "_format": [{ type: Input, args: ['format',] },],
        "formControl": [{ type: Input },],
        "onSelect": [{ type: Output },],
        "_datepicker": [{ type: ViewChild, args: ['datepicker',] },],
        "_datepickerMobile": [{ type: ViewChild, args: ['datepickerMobile',] },],
        "onblur": [{ type: HostListener, args: ['blur',] },],
    };
    return PsCalendarComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ng-template ps-popover-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-popover>`.
 */
var PsPopoverTitleDirective = (function () {
    function PsPopoverTitleDirective(_elementRef, templateRef) {
        this._elementRef = _elementRef;
        this.templateRef = templateRef;
    }
    PsPopoverTitleDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-popover-title]'
                },] },
    ];
    /** @nocollapse */
    PsPopoverTitleDirective.ctorParameters = function () { return [
        { type: ElementRef, },
        { type: TemplateRef, },
    ]; };
    return PsPopoverTitleDirective;
}());
/**
 * `<ng-template ps-popover-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-popover>`.
 */
var PsPopoverContentDirective = (function () {
    function PsPopoverContentDirective(_elementRef, templateRef) {
        this._elementRef = _elementRef;
        this.templateRef = templateRef;
    }
    PsPopoverContentDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-popover-content]'
                },] },
    ];
    /** @nocollapse */
    PsPopoverContentDirective.ctorParameters = function () { return [
        { type: ElementRef, },
        { type: TemplateRef, },
    ]; };
    return PsPopoverContentDirective;
}());
var nextUniqueId$2 = 0;
/**
 * Mapeamento das classes e ícones para cada tipo de popover.
 */
var PS_POPOVER_ATTRIBUTES = [
    { prop: 'ps-popover-success', icon: 'ps-ico-check' },
    { prop: 'ps-popover-error', icon: 'ps-ico-alert' },
    { prop: 'ps-popover-alert', icon: 'ps-ico-alert' }
];
/**
 * `<ps-popover>`
 *
 * Componente popover.
 */
var PsPopoverComponent = (function () {
    function PsPopoverComponent(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        /**
         * Id único do componente.
         */
        this._popoverId = "Popover" + nextUniqueId$2++;
        /**
         * Flag indicando se deve conter ícone de fechar.
         */
        this._hasCloseIcon = true;
        this._platform.setScreen();
    }
    /**
     * @return {?}
     */
    PsPopoverComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        for (var _i = 0, PS_POPOVER_ATTRIBUTES_1 = PS_POPOVER_ATTRIBUTES; _i < PS_POPOVER_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_POPOVER_ATTRIBUTES_1[_i];
            if (self._hasHostAttributes(attribute.prop)) {
                self._renderer2.addClass(self._getHostElement().firstChild, attribute.prop);
                self._addIconToPopoverContainer(attribute.icon);
            }
        }
    };
    /**
     * @return {?}
     */
    PsPopoverComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        self._showHidePopoverElem();
    };
    /** Mostra o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseover, focusin, etc.).  */
    /**
     * Mostra o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseover, focusin, etc.).
     * @param {?} $event
     * @return {?}
     */
    PsPopoverComponent.prototype.open = /**
     * Mostra o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseover, focusin, etc.).
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
        if (typeof $event === 'undefined') {
            throw Error('Pass $event object to open function');
        }
        var /** @type {?} */ self = this;
        self._hasCloseIcon = ($event.type === 'mouseover') ? false : true;
        self._setPosition($event);
    };
    /** Esconde o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseout, focusout, etc.).  */
    /**
     * Esconde o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseout, focusout, etc.).
     * @return {?}
     */
    PsPopoverComponent.prototype.close = /**
     * Esconde o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseout, focusout, etc.).
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        self._show = false;
        self._renderer2.setStyle(self._popoverElem.nativeElement, 'margin-top', '0');
        self._renderer2.setStyle(self._popoverElem.nativeElement, 'margin-left', '0');
        self._showHidePopoverElem();
    };
    /**
     * Calcula a posição do popover de forma semelhante ao tooltip.
     * @param {?} $event
     * @return {?}
     */
    PsPopoverComponent.prototype._setPosition = /**
     * Calcula a posição do popover de forma semelhante ao tooltip.
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ triggerElem = /** @type {?} */ ($event.target);
        var /** @type {?} */ popoverElem = self._popoverElem.nativeElement;
        self._renderer2.addClass(triggerElem, 'ps-popover-toggle');
        self._renderer2.setStyle(popoverElem, 'display', 'block');
        self._show = true;
        var /** @type {?} */ _timeoutId = setTimeout(function () {
            var /** @type {?} */ triggerElem_offset = triggerElem.getBoundingClientRect();
            var /** @type {?} */ popoverElem_offset = popoverElem.getBoundingClientRect();
            if (self._platform.IsMobile) {
                self._renderer2.addClass(popoverElem, 'ps-popover-top');
                self._renderer2.setStyle(popoverElem, 'margin', '7px 0');
                self._renderer2.setStyle(popoverElem, 'width', '100%');
            }
            else {
                var /** @type {?} */ marginTop = triggerElem_offset.top - popoverElem_offset.top - 14;
                self._renderer2.setStyle(popoverElem, 'margin-top', marginTop + 'px');
                var /** @type {?} */ posicao_abertura_popover = (triggerElem_offset.left - popoverElem_offset.left) + (triggerElem_offset.width + 14);
                self._renderer2.setStyle(popoverElem, 'margin-left', posicao_abertura_popover + 'px');
                if ((triggerElem_offset.left + triggerElem_offset.width + popoverElem_offset.width) > window.innerWidth) {
                    self._renderer2.addClass(popoverElem, 'ps-popover-left');
                    posicao_abertura_popover = (triggerElem_offset.left - popoverElem_offset.left) - popoverElem_offset.width - 14;
                    self._renderer2.setStyle(popoverElem, 'margin-left', posicao_abertura_popover + 'px');
                }
            }
            self._renderer2.removeClass(popoverElem, 'ps-popover-initial');
        }, 50);
    };
    /**
     * Método que retorna o pai do elemento passado como parâmetro (selecionado via seletor com js nativo).
     * @param {?} elem Referência ao elemento.
     * @param {?} selector Valor do seletor que é usado para se buscar o pai.
     * @return {?} Referência ao elemento pai ou null.
     */
    PsPopoverComponent.prototype._getParentByClassWithRecursion = /**
     * Método que retorna o pai do elemento passado como parâmetro (selecionado via seletor com js nativo).
     * @param {?} elem Referência ao elemento.
     * @param {?} selector Valor do seletor que é usado para se buscar o pai.
     * @return {?} Referência ao elemento pai ou null.
     */
    function (elem, selector) {
        if (!Element.prototype.matches) {
            Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector ||
                function (s) {
                    var /** @type {?} */ matches = (this.document || this.ownerDocument).querySelectorAll(s);
                    var /** @type {?} */ i = matches.length;
                    while (--i >= 0 && matches.item(i) !== this) { }
                    return i > -1;
                };
        }
        for (; elem && elem !== document; elem = elem.parentNode) {
            if (elem.matches(selector)) {
                return elem;
            }
        }
        return null;
    };
    /**
     * Método que configura classe e altera a propriedade display do popover.
     * @return {?}
     */
    PsPopoverComponent.prototype._showHidePopoverElem = /**
     * Método que configura classe e altera a propriedade display do popover.
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        if (self._show) {
            self._renderer2.setStyle(self._popoverElem.nativeElement, 'display', 'block');
            self._renderer2.removeClass(self._popoverElem.nativeElement, 'ps-popover-initial');
        }
        else {
            self._renderer2.setStyle(self._popoverElem.nativeElement, 'display', 'none');
            self._renderer2.addClass(self._popoverElem.nativeElement, 'ps-popover-initial');
        }
    };
    /**
     * Método que adiciona o bloco HTML de ícone para o popover.
     * @param {?} icon
     * @return {?}
     */
    PsPopoverComponent.prototype._addIconToPopoverContainer = /**
     * Método que adiciona o bloco HTML de ícone para o popover.
     * @param {?} icon
     * @return {?}
     */
    function (icon) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ span = self._renderer2.createElement('span');
        self._renderer2.addClass(span, 'ps-ico');
        self._renderer2.addClass(span, icon);
        var /** @type {?} */ container = self._getChildElementByClassName('ps-popover-ctt');
        self._renderer2.addClass(container, 'ps-popover-ctt-icon');
        self._renderer2.insertBefore(container, span, container.firstChild);
    };
    /**
     * Retorna os elementos filhos do popover usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    PsPopoverComponent.prototype._getChildElementByClassName = /**
     * Retorna os elementos filhos do popover usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    function (css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsPopoverComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsPopoverComponent.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    PsPopoverComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-popover',
                    template: "<div class=\"ps-popover ps-popover-event ps-popover-initial\" id=\"{{_popoverId}}\"\n                [ngStyle]=\"{'display': 'none'}\"\n                #popoverElem>\n              <a *ngIf=\"_hasCloseIcon\" href=\"javascript:;\" (click)=\"close()\" class=\"ps-popover-close\">\n                <span class=\"ps-ico ps-ico-close\"></span>\n              </a>\n              <div class=\"ps-popover-title\">\n                <ng-template *ngIf=\"_popoverTitle\" [ngTemplateOutlet]=\"_popoverTitle.templateRef\"></ng-template>\n              </div>\n              <div class=\"ps-popover-ctt\">\n                <ng-template [ngTemplateOutlet]=\"_popoverContent.templateRef\"></ng-template>\n              </div>\n            </div>",
                    styles: ["\n    .ps-popover {\n      opacity: 1;\n    }\n\n    .ps-popover-initial {\n      opacity: 0;\n    }\n\n    @media all and (min-width: 768px) {\n      .ps-popover {\n        max-width: 200px;\n      }\n    }"],
                    encapsulation: ViewEncapsulation.None,
                    providers: [
                        Platform
                    ]
                },] },
    ];
    /** @nocollapse */
    PsPopoverComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
    ]; };
    PsPopoverComponent.propDecorators = {
        "_show": [{ type: Input, args: ['show',] },],
        "_popoverTitle": [{ type: ContentChild, args: [PsPopoverTitleDirective,] },],
        "_popoverContent": [{ type: ContentChild, args: [PsPopoverContentDirective,] },],
        "_popoverElem": [{ type: ViewChild, args: ['popoverElem',] },],
    };
    return PsPopoverComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-form-field>`
 *
 * Componente que controla a inclusão de mensagens de erro, popovers (dicas), labels
 * e textos de apoio (helpers) para os correspondentes campos input (Elementos
 * de Formulário).
 */
var PsFormFieldComponent = (function () {
    function PsFormFieldComponent(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    PsFormFieldComponent.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        this._addErrorCSSToChild();
    };
    /**
     * Método que altera a flag da mensagem de erro e adiciona a correspondente classe css.
     * @param {?} show boolean Flag para controlar visibilidade da mensagem de erro.
     * @return {?}
     */
    PsFormFieldComponent.prototype.showErrorMessage = /**
     * Método que altera a flag da mensagem de erro e adiciona a correspondente classe css.
     * @param {?} show boolean Flag para controlar visibilidade da mensagem de erro.
     * @return {?}
     */
    function (show) {
        this._showErrorMessage = show;
        this._addErrorCSSToChild();
    };
    /**
     * Método interno que adicona ou remove a classe css de erro se a classe do campo input
     * filho do componente for alguma das listadas no Array fieldTypes.
     * @return {?}
     */
    PsFormFieldComponent.prototype._addErrorCSSToChild = /**
     * Método interno que adicona ou remove a classe css de erro se a classe do campo input
     * filho do componente for alguma das listadas no Array fieldTypes.
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        var /** @type {?} */ fieldTypes = ['ps-frm-entry', 'ps-frm-checkbox', 'ps-frm-radio', 'ps-frm-select'];
        var /** @type {?} */ ERROR_CSS = 'ps-frm-error';
        fieldTypes.forEach(function (css) {
            var /** @type {?} */ elements = Array.from(self._getChildElementByClassName(css));
            if (elements.length > 0) {
                elements.forEach(function (element) {
                    self._renderer2.addClass(element, 'ps-frm-valid');
                    if (self._showErrorMessage) {
                        self._renderer2.addClass(element, ERROR_CSS);
                    }
                    else {
                        self._renderer2.removeClass(element, ERROR_CSS);
                    }
                });
            }
        });
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsFormFieldComponent.prototype.getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    PsFormFieldComponent.prototype._getChildElementByClassName = /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    function (css) {
        return this._psFormFieldContent.nativeElement.getElementsByClassName(css);
    };
    PsFormFieldComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-form-field',
                    template: "<div *ngIf=\"_showErrorMessage\" class=\"ps-frm-row\">\n                <ps-panel ps-type=\"ps-panel-error\" ps-icon=\"ps-ico-alert\">\n                  <ng-template ps-panel-ctt>\n                    {{_errorMessage}}\n                  </ng-template>\n                </ps-panel>\n             </div>\n             <div class=\"ps-frm-row\" #psFormFieldContent>\n                <label *ngIf=\"_label?.length || _labelInternal?.length\" class=\"ps-frm-lbl\"\n                  [ngClass]=\"{'ps-lbl-helper': _popoverText?.length, 'ps-frm-lbl-internal' : _labelInternal?.length }\">\n                  {{_label}}{{_labelInternal}}\n                </label>\n                <ng-content></ng-content>\n                <span *ngIf=\"_popoverText?.length\"\n                        class=\"ps-ico ps-ico-doubt ps-popover-toggle ps-popover-toggle-over ps-frm-helper-popover\"\n                        (mouseover)=\"_popoverComponent.open($event)\" (mouseleave)=\"_popoverComponent.close()\"></span>\n                <small *ngIf=\"_helper?.length\" class=\"ps-helper\">{{_helper}}</small>\n                <ps-popover *ngIf=\"_popoverText?.length\" #popoverComponent>\n                  <ng-template ps-popover-content>\n                    {{_popoverText}}\n                  </ng-template>\n                </ps-popover>\n             </div>",
                    styles: ["\n            .ps-frm-row {\n                position: relative;\n            }\n\n            .ps-frm-helper-popover {\n                position: absolute;\n                top: -7px;\n                right: 0;\n                z-index: 3;\n            }"],
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsFormFieldComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsFormFieldComponent.propDecorators = {
        "_label": [{ type: Input, args: ['label',] },],
        "_labelInternal": [{ type: Input, args: ['label-internal',] },],
        "_helper": [{ type: Input, args: ['helper',] },],
        "_errorMessage": [{ type: Input, args: ['error-message',] },],
        "_popoverText": [{ type: Input, args: ['popover',] },],
        "_popoverComponent": [{ type: ViewChild, args: ['popoverComponent',] },],
        "_psFormFieldContent": [{ type: ViewChild, args: ['psFormFieldContent',] },],
        "_showErrorMessage": [{ type: Input, args: ['show-error-message',] },],
    };
    return PsFormFieldComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Service para validação dos inputs dos elementos de formulários utilizando máscaras.
 */
var FormValidate = (function () {
    function FormValidate() {
    }
    /**
     * Transforma uma data no formato americano yyyy-mm-dd.
     * @param {?} str Data no format dd/mm/yyyy.
     * @return {?} Falso se o parâmetro for indefinido ou a data no formato yyyy-mm-dd.
     */
    FormValidate.prototype.FormCalendarDateFormatter = /**
     * Transforma uma data no formato americano yyyy-mm-dd.
     * @param {?} str Data no format dd/mm/yyyy.
     * @return {?} Falso se o parâmetro for indefinido ou a data no formato yyyy-mm-dd.
     */
    function (str) {
        if (typeof str === 'undefined') {
            return false;
        }
        var /** @type {?} */ rtn = '';
        if (str.indexOf('/') > -1) {
            str = str.split('/');
            rtn = str[2] + '-' + str[1] + '-' + str[0];
        }
        return rtn;
    };
    /**
     * Usa regex para testar se o email está em formato válido (texto, arroba, domínio, etc).
     * @param {?} email Email.
     * @return {?} Verdadeiro se o email é válido, falso caso contrário.
     */
    FormValidate.prototype.FormValidateMail = /**
     * Usa regex para testar se o email está em formato válido (texto, arroba, domínio, etc).
     * @param {?} email Email.
     * @return {?} Verdadeiro se o email é válido, falso caso contrário.
     */
    function (email) {
        // tslint:disable-next-line:max-line-length
        var /** @type {?} */ re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    };
    /**
     * Valida um cpf usando o algoritmo padrão.
     * @param {?} cpf Valor do cpf com pontuação.
     * @return {?} Verdadeiro se o cpf é válido, falso caso contrário.
     */
    FormValidate.prototype.FormValidateCPF = /**
     * Valida um cpf usando o algoritmo padrão.
     * @param {?} cpf Valor do cpf com pontuação.
     * @return {?} Verdadeiro se o cpf é válido, falso caso contrário.
     */
    function (cpf) {
        cpf = cpf.replace(/[^\d]+/g, '');
        var /** @type {?} */ Soma = 0;
        var /** @type {?} */ Resto;
        if (cpf === '00000000000' ||
            cpf === '11111111111' ||
            cpf === '22222222222' ||
            cpf === '33333333333' ||
            cpf === '44444444444' ||
            cpf === '55555555555' ||
            cpf === '66666666666' ||
            cpf === '77777777777' ||
            cpf === '88888888888' ||
            cpf === '99999999999') {
            return false;
        }
        for (var /** @type {?} */ i = 1; i <= 9; i++) {
            Soma = Soma + parseInt(cpf.substring(i - 1, i)) * (11 - i);
        }
        Resto = (Soma * 10) % 11;
        if ((Resto === 10) || (Resto === 11)) {
            Resto = 0;
        }
        if (Resto !== parseInt(cpf.substring(9, 10))) {
            return false;
        }
        Soma = 0;
        for (var /** @type {?} */ i = 1; i <= 10; i++) {
            Soma = Soma + parseInt(cpf.substring(i - 1, i)) * (12 - i);
        }
        Resto = (Soma * 10) % 11;
        if ((Resto === 10) || (Resto === 11)) {
            Resto = 0;
        }
        if (Resto !== parseInt(cpf.substring(10, 11))) {
            return false;
        }
        return true;
    };
    /**
     * Valida um CNPJ usando o algoritmo padrão.
     * @param {?} cnpj Valor do cnpj com pontuação.
     * @return {?} Verdadeiro se o cnpj é válido, falso caso contrário.
     */
    FormValidate.prototype.FormValidateCNPJ = /**
     * Valida um CNPJ usando o algoritmo padrão.
     * @param {?} cnpj Valor do cnpj com pontuação.
     * @return {?} Verdadeiro se o cnpj é válido, falso caso contrário.
     */
    function (cnpj) {
        cnpj = cnpj.replace(/[^\d]+/g, '');
        if (cnpj === '') {
            return false;
        }
        if (cnpj.length !== 14) {
            return false;
        }
        // Elimina CNPJs invalidos conhecidos
        if (cnpj === '00000000000000' ||
            cnpj === '11111111111111' ||
            cnpj === '22222222222222' ||
            cnpj === '33333333333333' ||
            cnpj === '44444444444444' ||
            cnpj === '55555555555555' ||
            cnpj === '66666666666666' ||
            cnpj === '77777777777777' ||
            cnpj === '88888888888888' ||
            cnpj === '99999999999999') {
            return false;
        }
        var /** @type {?} */ tamanho = cnpj.length - 2;
        var /** @type {?} */ numeros = cnpj.substring(0, tamanho);
        var /** @type {?} */ digitos = cnpj.substring(tamanho);
        var /** @type {?} */ soma = 0;
        var /** @type {?} */ pos = tamanho - 7;
        for (var /** @type {?} */ i = tamanho; i >= 1; i--) {
            soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
            if (pos < 2) {
                pos = 9;
            }
        }
        var /** @type {?} */ resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado !== parseInt(digitos.charAt(0))) {
            return false;
        }
        tamanho = tamanho + 1;
        numeros = cnpj.substring(0, tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (var /** @type {?} */ i = tamanho; i >= 1; i--) {
            soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
            if (pos < 2) {
                //
                pos = 9;
            }
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado !== parseInt(digitos.charAt(1))) {
            return false;
        }
        return true;
    };
    /**
     * Valida um número de telefone, evita que seja aceita números iguais.
     * @param {?} phone Número de telefone com pontuação.
     * @return {?} Verdadeiro se o telefone é válido, falso caso contrário.
     */
    FormValidate.prototype.FormValidatePhone = /**
     * Valida um número de telefone, evita que seja aceita números iguais.
     * @param {?} phone Número de telefone com pontuação.
     * @return {?} Verdadeiro se o telefone é válido, falso caso contrário.
     */
    function (phone) {
        var /** @type {?} */ rtn = true;
        phone = phone.replace(/\(/g, '').replace(/\)/g, '').replace(/ /g, '').replace(/\./g, '');
        if (phone !== '') {
            if (phone.indexOf('0000000') > -1 ||
                phone.indexOf('1111111') > -1 ||
                phone.indexOf('2222222') > -1 ||
                phone.indexOf('3333333') > -1 ||
                phone.indexOf('4444444') > -1 ||
                phone.indexOf('5555555') > -1 ||
                phone.indexOf('6666666') > -1 ||
                phone.indexOf('7777777') > -1 ||
                phone.indexOf('8888888') > -1 ||
                phone.indexOf('9999999') > -1) {
                rtn = false;
            }
        }
        return rtn;
    };
    /**
     * Remove caracteres que podem ocasionar problemas com encoding, permitindo ou não, números.
     * @param {?} string Texto para ser limpo.
     * @param {?} allowNumbers Opção de permitir números ou não.
     * @return {?} String contendo somente caracteres válidos.
     */
    FormValidate.prototype.FormCleanupString = /**
     * Remove caracteres que podem ocasionar problemas com encoding, permitindo ou não, números.
     * @param {?} string Texto para ser limpo.
     * @param {?} allowNumbers Opção de permitir números ou não.
     * @return {?} String contendo somente caracteres válidos.
     */
    function (string, allowNumbers) {
        if (typeof allowNumbers === 'undefined') {
            allowNumbers = false;
        }
        string = string.replace(/[áàâãä]/g, 'a');
        string = string.replace(/[ÁÀÂÃÄ]/g, 'A');
        string = string.replace(/[éèêë]/g, 'e');
        string = string.replace(/[ÉÈÊË]/g, 'E');
        string = string.replace(/[íìîï]/g, 'i');
        string = string.replace(/[ÍÌÎÏ]/g, 'I');
        string = string.replace(/[óòôõö]/g, 'o');
        string = string.replace(/[ÓÒÔÕÖ]/g, 'O');
        string = string.replace(/[úùûü]/g, 'u');
        string = string.replace(/[ÚÙÛÜ]/g, 'U');
        string = string.replace(/[ç]/g, 'c');
        string = string.replace(/[Ç]/g, 'C');
        string = string.replace(/\˜/g, '');
        string = string.replace(/\`/g, '');
        string = string.replace(/\;/g, '');
        string = string.replace(/\'/g, '');
        string = string.replace(/\//g, '');
        string = string.replace(/\\/g, '');
        string = string.replace(/\|/g, '');
        string = string.replace(/\[/g, '');
        string = string.replace(/\]/g, '');
        string = string.replace(/\{/g, '');
        string = string.replace(/\}/g, '');
        string = string.replace(/\?/g, '');
        string = string.replace(/\</g, '');
        string = string.replace(/\>/g, '');
        string = string.replace(/\-/g, '');
        string = string.replace(/\+/g, '');
        string = string.replace(/\=/g, '');
        string = string.replace(/\(/g, '');
        string = string.replace(/\)/g, '');
        string = string.replace(/\!/g, '');
        string = string.replace(/\@/g, '');
        string = string.replace(/\#/g, '');
        string = string.replace(/\$/g, '');
        string = string.replace(/\%/g, '');
        string = string.replace(/\^/g, '');
        string = string.replace(/\&/g, '');
        string = string.replace(/\*/g, '');
        if (!allowNumbers) {
            string = string.replace(/\d/g, '');
        }
        return string;
    };
    FormValidate.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    FormValidate.ctorParameters = function () { return []; };
    return FormValidate;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Mapeamento entre tipos de campos e atributos type dos elementos HTML.
 */
var PS_FIELD_ENTRY_ATTRIBUTES = [
    { prop: 'ps-field-entry', type: 'text' },
    { prop: 'ps-field-entry-email', type: 'email' },
    { prop: 'ps-field-entry-tel', type: 'tel' },
    { prop: 'ps-field-entry-cel', type: 'tel' },
    { prop: 'ps-field-entry-number', type: 'number' },
    { prop: 'ps-field-entry-cpf', type: 'tel' },
    { prop: 'ps-field-entry-cnpj', type: 'tel' },
    { prop: 'ps-field-entry-data', type: 'text' },
    { prop: 'ps-field-entry-cep', type: 'tel' }
];
/**
 * Diretiva de atributo que configura os diferentes tipos de campos dos elementos e formulários.
 */
var PsFieldEntryDirective = (function () {
    function PsFieldEntryDirective(_renderer2, _elementRef, _formValidate) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._formValidate = _formValidate;
        this._setAttributes();
    }
    /**
     * @return {?}
     */
    PsFieldEntryDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this._renderer2.addClass(this._getHostElement(), 'ps-frm-entry');
    };
    /**
     * @return {?}
     */
    PsFieldEntryDirective.prototype.ngAfterViewChecked = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ value = this._getHostElement().value;
        if (value) {
            this._addFormLabelFocusCSS(true);
        }
    };
    /**
     * @return {?}
     */
    PsFieldEntryDirective.prototype.focus = /**
     * @return {?}
     */
    function () {
        this._addFormLabelFocusCSS(true);
    };
    /**
     * @return {?}
     */
    PsFieldEntryDirective.prototype.blur = /**
     * @return {?}
     */
    function () {
        this._addFormLabelFocusCSS(false);
        this._validate();
    };
    /**
     * @param {?} event
     * @return {?}
     */
    PsFieldEntryDirective.prototype.keydown = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        if (this._fieldType === 'number') {
            this._validateNumbers(event);
        }
    };
    /**
     * @return {?}
     */
    PsFieldEntryDirective.prototype.change = /**
     * @return {?}
     */
    function () {
        if (this._fieldType === 'data') {
            this._validateDate();
        }
    };
    /**
     * Método que configura o input com a classe para animação do label.
     * @param {?} isToAdd Flag para inserir ou remover a classe css.
     * @return {?}
     */
    PsFieldEntryDirective.prototype._addFormLabelFocusCSS = /**
     * Método que configura o input com a classe para animação do label.
     * @param {?} isToAdd Flag para inserir ou remover a classe css.
     * @return {?}
     */
    function (isToAdd) {
        var /** @type {?} */ psFrmLblFocusCSS = 'ps-frm-lbl-focus';
        if (isToAdd) {
            this._renderer2.addClass(this._getLabelElement(), psFrmLblFocusCSS);
        }
        else {
            this._renderer2.removeClass(this._getLabelElement(), psFrmLblFocusCSS);
        }
    };
    /**
     * Método que verifica e adiciona os atributos no campo input.
     * @return {?}
     */
    PsFieldEntryDirective.prototype._setAttributes = /**
     * Método que verifica e adiciona os atributos no campo input.
     * @return {?}
     */
    function () {
        for (var _i = 0, PS_FIELD_ENTRY_ATTRIBUTES_1 = PS_FIELD_ENTRY_ATTRIBUTES; _i < PS_FIELD_ENTRY_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_FIELD_ENTRY_ATTRIBUTES_1[_i];
            if (this._hasHostAttributes(attribute.prop)) {
                if (!this._hasHostAttributes('type')) {
                    this._renderer2.setAttribute(this._getHostElement(), 'type', attribute.type);
                    this._fieldType = attribute.prop.replace('ps-field-entry-', '');
                }
                if (this._hasHostAttributes('mask') || this._hasHostAttributes('ps-mask')) {
                    this._renderer2.setAttribute(this._getHostElement(), 'autocomplete', 'off');
                    this._renderer2.setAttribute(this._getHostElement(), 'autocorrect', 'off');
                    this._renderer2.setAttribute(this._getHostElement(), 'autocapitalize', 'off');
                    this._renderer2.setAttribute(this._getHostElement(), 'spellcheck', 'false');
                }
            }
        }
    };
    /**
     * Método de validação do campo dependendo tipo (é reforçado pela mask / máscara).
     * @return {?}
     */
    PsFieldEntryDirective.prototype._validate = /**
     * Método de validação do campo dependendo tipo (é reforçado pela mask / máscara).
     * @return {?}
     */
    function () {
        var /** @type {?} */ value = this._getHostElement().value;
        switch (this._fieldType) {
            case 'cpf':
                if (this._removePontuationCharacters(value) !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidateCPF(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'cnpj':
                if (this._removePontuationCharacters(value) !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidateCNPJ(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'email':
                if (value !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidateMail(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'cel':
                if (value !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidatePhone(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'tel':
                if (value !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidatePhone(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
        }
    };
    /**
     * Método que permiti somente caracteres numéricos.
     * @param {?} e KeyboardEvent
     * @return {?}
     */
    PsFieldEntryDirective.prototype._validateNumbers = /**
     * Método que permiti somente caracteres numéricos.
     * @param {?} e KeyboardEvent
     * @return {?}
     */
    function (e) {
        var /** @type {?} */ keyAllowed = [46, 8, 9, 27, 13, 110];
        if (keyAllowed.indexOf(e.keyCode) !== -1 ||
            (e.keyCode === 65 && e.ctrlKey === true) ||
            (e.keyCode === 86 && e.ctrlKey === true) ||
            (e.keyCode === 82 && e.ctrlKey === true) ||
            (e.keyCode >= 35 && e.keyCode <= 39) ||
            (!e.shiftKey && ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)))) {
            return;
        }
        else {
            e.preventDefault();
        }
    };
    /**
     * Método que verifica se o elemento contém uma data válida (formato dd/mm/yyy) criando um objeto Date.
     * @return {?}
     */
    PsFieldEntryDirective.prototype._validateDate = /**
     * Método que verifica se o elemento contém uma data válida (formato dd/mm/yyy) criando um objeto Date.
     * @return {?}
     */
    function () {
        var /** @type {?} */ dateString = this._getHostElement().value.trim();
        var /** @type {?} */ v = dateString.split('/');
        var /** @type {?} */ vDate = new Date(v[2], (parseInt(v[1]) - 1), v[0]);
        var /** @type {?} */ invalid = (v !== '' && (parseInt(v[0]) !== vDate.getDate() || parseInt(v[1]) !== (vDate.getMonth() + 1)));
        this._addErrorCSS(invalid);
    };
    /**
     * Método que adiciona ou remove a classe de erro no campo.
     * @param {?} add Flag para adicionar ou remover a classe css.
     * @return {?}
     */
    PsFieldEntryDirective.prototype._addErrorCSS = /**
     * Método que adiciona ou remove a classe de erro no campo.
     * @param {?} add Flag para adicionar ou remover a classe css.
     * @return {?}
     */
    function (add) {
        var /** @type {?} */ errorCSS = 'ps-frm-error';
        if (add) {
            this._renderer2.addClass(this._getHostElement(), errorCSS);
        }
        else {
            this._renderer2.removeClass(this._getHostElement(), errorCSS);
        }
    };
    /**
     * Método que remove a pontuação de um texto.
     * @param {?} value Texto que deve ter a pontuação removida .
     * @return {?}
     */
    PsFieldEntryDirective.prototype._removePontuationCharacters = /**
     * Método que remove a pontuação de um texto.
     * @param {?} value Texto que deve ter a pontuação removida .
     * @return {?}
     */
    function (value) {
        return value.replace(/[^\d]+/g, '');
    };
    /**
     * Retorna uma referência HTMLElement contendo a diretiva.
     * @return {?}
     */
    PsFieldEntryDirective.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement contendo a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Método que retorna o label correspondente ao campo.
     * Levando em conta se existe o componente popover.
     * @return {?}
     */
    PsFieldEntryDirective.prototype._getLabelElement = /**
     * Método que retorna o label correspondente ao campo.
     * Levando em conta se existe o componente popover.
     * @return {?}
     */
    function () {
        var /** @type {?} */ previousTagName = (/** @type {?} */ (this._getHostElement().previousElementSibling)).tagName.toLowerCase();
        if (previousTagName === 'ps-popover') {
            return /** @type {?} */ (this._getHostElement().previousElementSibling.previousElementSibling);
        }
        return /** @type {?} */ (this._getHostElement().previousElementSibling);
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsFieldEntryDirective.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    PsFieldEntryDirective.decorators = [
        { type: Directive, args: [{
                    selector: "[ps-field-entry], [ps-field-entry-email],\n                [ps-field-entry-tel], [ps-field-entry-cel],\n                [ps-field-entry-number],[ps-field-entry-cpf],\n                [ps-field-entry-cnpj], [ps-field-entry-data],\n                [ps-field-entry-cep]",
                    providers: [FormValidate]
                },] },
    ];
    /** @nocollapse */
    PsFieldEntryDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: FormValidate, },
    ]; };
    PsFieldEntryDirective.propDecorators = {
        "focus": [{ type: HostListener, args: ['focus',] },],
        "blur": [{ type: HostListener, args: ['blur',] },],
        "keydown": [{ type: HostListener, args: ['keydown', ['$event'],] },],
        "change": [{ type: HostListener, args: ['change',] },],
    };
    return PsFieldEntryDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva de atributo para remover caracteres inválidos em campos input.
 */
var PsFrmCleanupDirective = (function () {
    function PsFrmCleanupDirective(_renderer2, _elementRef, _formValidate) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._formValidate = _formValidate;
    }
    /**
     * @param {?} event
     * @return {?}
     */
    PsFrmCleanupDirective.prototype.blur = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this._cleanUp(event);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    PsFrmCleanupDirective.prototype.keyup = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this._cleanUp(event);
    };
    /**
     * Método que remove caracteres inválidos no campo input anotado com a diretiva.
     * @param {?} e
     * @return {?}
     */
    PsFrmCleanupDirective.prototype._cleanUp = /**
     * Método que remove caracteres inválidos no campo input anotado com a diretiva.
     * @param {?} e
     * @return {?}
     */
    function (e) {
        var /** @type {?} */ v = this._getHostElement().value;
        var /** @type {?} */ keycodes = [38, 39, 40, 37, 16, 9];
        if (keycodes.indexOf(e.keyCode) !== -1 || ((e.shiftKey || e.ctrlKey || e.altKey) && keycodes.indexOf(e.keyCode) !== -1)) {
            return false;
        }
        v = v.toUpperCase();
        v = this._formValidate.FormCleanupString(v, this._allowNumbers);
        this._getHostElement().value = v;
    };
    /**
     * Retorna uma referência HTMLElement contendo a diretiva.
     * @return {?}
     */
    PsFrmCleanupDirective.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement contendo a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsFrmCleanupDirective.decorators = [
        { type: Directive, args: [{
                    selector: "[ps-frm-cleanup]"
                },] },
    ];
    /** @nocollapse */
    PsFrmCleanupDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: FormValidate, },
    ]; };
    PsFrmCleanupDirective.propDecorators = {
        "_allowNumbers": [{ type: Input, args: ['allowNumbers',] },],
        "blur": [{ type: HostListener, args: ['blur', ['$event'],] },],
        "keyup": [{ type: HostListener, args: ['keyup', ['$event'],] },],
    };
    return PsFrmCleanupDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var nextCheckboxId = 0;
/**
 * Diretiva de atributo para configurar um campo do tipo checkbox.
 */
var PsFormCheckboxDirective = (function () {
    function PsFormCheckboxDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único do campo.
         */
        this._checkboxId = "Checkbox" + nextCheckboxId++;
    }
    /**
     * Método que adiciona no input o atributo type como checkbox, a classe css específica
     * e verifica se o elemento já possui um id. Caso contrário, especifica um gerado
     * automaticamente.
     */
    /**
     * Método que adiciona no input o atributo type como checkbox, a classe css específica
     * e verifica se o elemento já possui um id. Caso contrário, especifica um gerado
     * automaticamente.
     * @return {?}
     */
    PsFormCheckboxDirective.prototype.ngOnInit = /**
     * Método que adiciona no input o atributo type como checkbox, a classe css específica
     * e verifica se o elemento já possui um id. Caso contrário, especifica um gerado
     * automaticamente.
     * @return {?}
     */
    function () {
        this._name = this._getHostElement().getAttribute('name');
        this._renderer2.setAttribute(this._getHostElement(), 'type', 'checkbox');
        if (!this._getHostElement().getAttribute('id')) {
            this._renderer2.setAttribute(this._getHostElement(), 'id', this._checkboxId);
        }
        else {
            this._checkboxId = this._getHostElement().getAttribute('id');
        }
        this._renderer2.setAttribute(this._getHostElement(), 'class', 'ps-frm-checkbox');
    };
    /**
     * @return {?}
     */
    PsFormCheckboxDirective.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        this._addForValueInLabel(this._checkboxId);
    };
    /**
     * Método que adiciona o valor do atributo 'for' do label correspondente ao campo.
     * @param {?} forValue
     * @return {?}
     */
    PsFormCheckboxDirective.prototype._addForValueInLabel = /**
     * Método que adiciona o valor do atributo 'for' do label correspondente ao campo.
     * @param {?} forValue
     * @return {?}
     */
    function (forValue) {
        this._renderer2.setAttribute(this._getLabelElement(), 'for', forValue);
    };
    /**
     * Método que retorna o label correspondente ao campo.
     * @return {?}
     */
    PsFormCheckboxDirective.prototype._getLabelElement = /**
     * Método que retorna o label correspondente ao campo.
     * @return {?}
     */
    function () {
        return this._getHostElement().nextElementSibling;
    };
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    PsFormCheckboxDirective.prototype._getHostElement = /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsFormCheckboxDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-form-checkbox]'
                },] },
    ];
    /** @nocollapse */
    PsFormCheckboxDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsFormCheckboxDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var nextUniqueId$3 = 0;
/**
 * Diretiva de atributo que configura um radio.
 */
var PsFormRadioDirective = (function () {
    function PsFormRadioDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único gerado automaticamente para evitar problemas caso o usuário não tenha definido.
         */
        this._radioId = "Radio" + nextUniqueId$3++;
    }
    /** Método hook do angular que configura o tipo, id e adicionada a classe css específica para o radio.  */
    /**
     * Método hook do angular que configura o tipo, id e adicionada a classe css específica para o radio.
     * @return {?}
     */
    PsFormRadioDirective.prototype.ngOnInit = /**
     * Método hook do angular que configura o tipo, id e adicionada a classe css específica para o radio.
     * @return {?}
     */
    function () {
        this._name = this._getHostElement().getAttribute('name');
        this._renderer2.setAttribute(this._getHostElement(), 'type', 'radio');
        if (!this._getHostElement().getAttribute('id')) {
            this._renderer2.setAttribute(this._getHostElement(), 'id', this._radioId);
        }
        else {
            this._radioId = this._getHostElement().getAttribute('id');
        }
        this._renderer2.setAttribute(this._getHostElement(), 'class', 'ps-frm-radio');
    };
    /**
     * @return {?}
     */
    PsFormRadioDirective.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        this._addForValueInLabel(this._radioId);
    };
    /**
     * Método que adiciona o valor do atributo for do label.
     * @param {?} forValue
     * @return {?}
     */
    PsFormRadioDirective.prototype._addForValueInLabel = /**
     * Método que adiciona o valor do atributo for do label.
     * @param {?} forValue
     * @return {?}
     */
    function (forValue) {
        this._renderer2.setAttribute(this._getLabelElement(), 'for', forValue);
    };
    /**
     * Método que retorna o label correspondente ao campo.
     * @return {?}
     */
    PsFormRadioDirective.prototype._getLabelElement = /**
     * Método que retorna o label correspondente ao campo.
     * @return {?}
     */
    function () {
        return this._getHostElement().nextElementSibling;
    };
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    PsFormRadioDirective.prototype._getHostElement = /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsFormRadioDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-form-radio]'
                },] },
    ];
    /** @nocollapse */
    PsFormRadioDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsFormRadioDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva de atributo que configura um elemento textarea adicionando a respectiva classe css.
 */
var PsFormTextAreaDirective = (function () {
    function PsFormTextAreaDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /** Método hook do angular que adiciona a classe css ao elemento textarea.  */
    /**
     * Método hook do angular que adiciona a classe css ao elemento textarea.
     * @return {?}
     */
    PsFormTextAreaDirective.prototype.ngOnInit = /**
     * Método hook do angular que adiciona a classe css ao elemento textarea.
     * @return {?}
     */
    function () {
        this._renderer2.addClass(this._getHostElement(), 'ps-frm-entry');
    };
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    PsFormTextAreaDirective.prototype._getHostElement = /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsFormTextAreaDirective.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    PsFormTextAreaDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-form-textarea]'
                },] },
    ];
    /** @nocollapse */
    PsFormTextAreaDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsFormTextAreaDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-form-select>`
 *
 * Componente de suporte para listas select adicionando um 'container' com a classe css específica.
 */
var PsFormSelectComponent = (function () {
    function PsFormSelectComponent() {
    }
    PsFormSelectComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-form-select',
                    template: " <div class=\"ps-frm-select\">\n                    <ng-content></ng-content>\n                </div>"
                },] },
    ];
    /** @nocollapse */
    PsFormSelectComponent.ctorParameters = function () { return []; };
    return PsFormSelectComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var nextUniqueId$4 = 0;
/**
 * `<ps-form-on-off>`
 *
 * Componente que cria o toggle de on / off (liga / desliga).
 */
var PsFormOnOffComponent = (function () {
    function PsFormOnOffComponent(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único gerado automaticamente para evitar problemas caso o usuário não tenha definido.
         */
        this._psFormOnOffId = "ps-frm-onOff" + nextUniqueId$4++;
    }
    /** Método que configura o label e o input checkbox contidos no componente.  */
    /**
     * Método que configura o label e o input checkbox contidos no componente.
     * @return {?}
     */
    PsFormOnOffComponent.prototype.ngAfterViewInit = /**
     * Método que configura o label e o input checkbox contidos no componente.
     * @return {?}
     */
    function () {
        var /** @type {?} */ labelElem = this._getHostElement().querySelector('.ps-frm-onOff-lbl');
        var /** @type {?} */ inputElem = labelElem.previousElementSibling;
        var /** @type {?} */ inputElemId = inputElem.getAttribute('id');
        if (typeof inputElemId === 'undefined' || inputElemId === '' || inputElem !== null) {
            inputElemId = this._psFormOnOffId;
            this._renderer2.setAttribute(inputElem, 'id', inputElemId);
        }
        this._renderer2.setAttribute(labelElem, 'for', inputElemId);
        this._renderer2.addClass(inputElem, 'ps-frm-onOff-ipt');
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsFormOnOffComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsFormOnOffComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-form-on-off',
                    template: "<div class=\"ps-row ps-frm-row\">\n                <div class=\"ps-mod5 ps-sm-mod9\">\n                    <label class=\"ps-frm-lbl\">{{_label}}</label>\n                </div>\n                <div class=\"ps-mod3 ps-sm-mod3 ps-alignRight\">\n                    <div class=\"ps-frm-onOff\" [style.display]=\"'inline-block'\">\n                        <ng-content></ng-content>\n                        <label class=\"ps-frm-onOff-lbl\" for=\"\" [style.textAlign]=\"'left'\">\n                            <span class=\"ps-frm-onOff-inner\"></span>\n                            <span class=\"ps-frm-onOff-switch\"></span>\n                        </label>\n                    </div>\n                </div>\n            </div>"
                },] },
    ];
    /** @nocollapse */
    PsFormOnOffComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsFormOnOffComponent.propDecorators = {
        "_label": [{ type: Input, args: ['label',] },],
    };
    return PsFormOnOffComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-form-select-list>`
 *
 * Componente que configura uma lista de seleção a partir de um select.
 */
var PsFormSelectListComponent = (function () {
    function PsFormSelectListComponent(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /**
     * @return {?}
     */
    PsFormSelectListComponent.prototype.ngAfterContentInit = /**
     * @return {?}
     */
    function () {
        this.selectElement = /** @type {?} */ (this._getElementHost().firstElementChild);
        this.renderSelectList();
    };
    /**
     * Método que configura o select interno (tornando invísivel) e cria a lista (ul, li) a partir dele.
     * @return {?}
     */
    PsFormSelectListComponent.prototype.renderSelectList = /**
     * Método que configura o select interno (tornando invísivel) e cria a lista (ul, li) a partir dele.
     * @return {?}
     */
    function () {
        this._renderer2.addClass(this.selectElement, 'ps-frm-select-list');
        var /** @type {?} */ options = this._getSelectValues2Array(this.selectElement, false);
        var /** @type {?} */ selectId = this.selectElement.id;
        if (typeof this._selectlistID === 'undefined' || !this._selectlistID) {
            this._selectlistID = 'ps-frm-select-list-' + Math.floor(Math.random() * 1000);
        }
        if (typeof selectId === 'undefined' || !selectId) {
            selectId = 'ps-frm-select-list-opts-' + Math.floor(Math.random() * 1000);
            this.selectElement.id = selectId;
        }
        if (options.length > 0) {
            var /** @type {?} */ ul_1;
            var /** @type {?} */ generatedList = this.selectElement.dataset["selectlistref"];
            var /** @type {?} */ listId = typeof this.selectElement.dataset["selectlistref"] !== 'undefined' ? generatedList : this._selectlistID;
            if (typeof generatedList === 'undefined') {
                ul_1 = this._renderer2.createElement('ul');
                this._renderer2.addClass(ul_1, 'ps-frm-select-list');
                if (this._is(this.selectElement, '.ps-frm-select-list-white')) {
                    this._renderer2.addClass(this.selectElement, 'ps-frm-select-list-white');
                }
                this._renderer2.setAttribute(ul_1, 'id', this._selectlistID);
                this.selectElement.dataset["selectlistref"] = this._selectlistID;
                this._getElementHost().appendChild(ul_1);
            }
            else {
                ul_1 = document.getElementById(this._selectlistID);
                ul_1.innerHTML = null;
            }
            var /** @type {?} */ self_1 = this;
            Array.prototype.forEach.call(options, function (option, i) {
                if (option.val === '') {
                    return;
                }
                var /** @type {?} */ li = self_1._renderer2.createElement('li');
                var /** @type {?} */ a = self_1._renderer2.createElement('a');
                self_1._renderer2.setAttribute(a, 'href', option.val);
                if (option.isSel) {
                    self_1._renderer2.addClass(a, 'ps-frm-sl-selected');
                }
                a.dataset.selectlistref = '#' + selectId;
                a.innerHTML = option.text;
                li.appendChild(a);
                ul_1.appendChild(li);
                self_1._bindClickEventHandler(a, ul_1, (/** @type {?} */ (self_1.selectElement)));
            });
        }
    };
    /**
     * Método que regista eventos na lista e sincroniza com o select.
     * @param {?} a
     * @param {?} ul
     * @param {?} selectList
     * @return {?}
     */
    PsFormSelectListComponent.prototype._bindClickEventHandler = /**
     * Método que regista eventos na lista e sincroniza com o select.
     * @param {?} a
     * @param {?} ul
     * @param {?} selectList
     * @return {?}
     */
    function (a, ul, selectList) {
        var /** @type {?} */ self = this;
        a.addEventListener('click', function (event) {
            event.preventDefault();
            var /** @type {?} */ select = a.dataset.selectlistref;
            var /** @type {?} */ val = a.getAttribute('href');
            var /** @type {?} */ txt = a.text;
            var /** @type {?} */ selectedElements = ul.querySelectorAll('.ps-frm-sl-selected');
            Array.prototype.forEach.call(selectedElements, function (el, j) {
                self._renderer2.removeClass(el, 'ps-frm-sl-selected');
            });
            self._renderer2.addClass(a, 'ps-frm-sl-selected');
            var /** @type {?} */ options = selectList.options;
            Array.prototype.forEach.call(options, function (option, l) {
                if (option.value === val) {
                    self._renderer2.setAttribute(option, 'selected', 'selected');
                }
                else {
                    self._renderer2.removeAttribute(option, 'selected');
                }
            });
        });
    };
    /**
     * Método que retorna um array contento os valores dos options no select.
     * @param {?} selectElement
     * @param {?} addOnlyValue
     * @return {?}
     */
    PsFormSelectListComponent.prototype._getSelectValues2Array = /**
     * Método que retorna um array contento os valores dos options no select.
     * @param {?} selectElement
     * @param {?} addOnlyValue
     * @return {?}
     */
    function (selectElement, addOnlyValue) {
        if (typeof addOnlyValue === 'undefined') {
            addOnlyValue = true;
        }
        if (!this._is(selectElement, 'select')) {
            return [];
        }
        var /** @type {?} */ arrayOfSelecteElementValues = [];
        var /** @type {?} */ options = selectElement.options;
        Array.prototype.forEach.call(options, function (option, i) {
            var /** @type {?} */ value = option.value;
            if (typeof value === 'undefined' || value === null) {
                return;
            }
            var /** @type {?} */ text = option.text;
            var /** @type {?} */ isSelected = option.selected;
            if (addOnlyValue) {
                arrayOfSelecteElementValues.push(value);
            }
            else {
                arrayOfSelecteElementValues.push({
                    'text': text,
                    'val': value,
                    'isSel': isSelected
                });
            }
        });
        return arrayOfSelecteElementValues;
    };
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param {?} el Referência HTMLElement do elemento que deve ser testado.
     * @param {?} selector Parâmetro para testar se o elemento possui.
     * @return {?} boolean.
     */
    PsFormSelectListComponent.prototype._is = /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param {?} el Referência HTMLElement do elemento que deve ser testado.
     * @param {?} selector Parâmetro para testar se o elemento possui.
     * @return {?} boolean.
     */
    function (el, selector) {
        return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector ||
            el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsFormSelectListComponent.prototype._getElementHost = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsFormSelectListComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-form-select-list',
                    template: "<ng-content></ng-content>"
                },] },
    ];
    /** @nocollapse */
    PsFormSelectListComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsFormSelectListComponent.propDecorators = {
        "_selectlistID": [{ type: Input, args: ['selectlistid',] },],
    };
    return PsFormSelectListComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsPopoverModule = (function () {
    function PsPopoverModule() {
    }
    PsPopoverModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        FormsModule
                    ],
                    exports: [
                        PsPopoverComponent,
                        PsPopoverTitleDirective,
                        PsPopoverContentDirective
                    ],
                    declarations: [
                        PsPopoverComponent,
                        PsPopoverTitleDirective,
                        PsPopoverContentDirective
                    ]
                },] },
    ];
    /** @nocollapse */
    PsPopoverModule.ctorParameters = function () { return []; };
    return PsPopoverModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Classe que contém o mapeamento de atributos e css do componente PsModal.
 */
var PsModalAttributes = (function () {
    function PsModalAttributes() {
    }
    PsModalAttributes.ATTRIBUTES = [
        { prop: 'ps-modal-small-tablet', css: 'ps-sm-modal-small' },
        { prop: 'ps-modal-small-desktop-sm', css: 'ps-md-modal-small' },
        { prop: 'ps-modal-small-desktop-lg', css: 'ps-lg-modal-small' },
        { prop: 'ps-modal-medium-tablet', css: 'ps-sm-modal-medium' },
        { prop: 'ps-modal-medium-desktop-sm', css: 'ps-md-modal-medium' },
        { prop: 'ps-modal-medium-desktop-lg', css: 'ps-lg-modal-medium' },
        { prop: 'ps-modal-large-tablet', css: 'ps-sm-modal-large' },
        { prop: 'ps-modal-large-desktop-sm', css: 'ps-md-modal-large' },
        { prop: 'ps-modal-large-desktop-lg', css: 'ps-lg-modal-large' }
    ];
    return PsModalAttributes;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ng-template ps-modal-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-modal>`.
 */
var PsModalTitleDirective = (function () {
    function PsModalTitleDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsModalTitleDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-modal-title]'
                },] },
    ];
    /** @nocollapse */
    PsModalTitleDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    PsModalTitleDirective.propDecorators = {
        "css": [{ type: Input, args: ['class',] },],
    };
    return PsModalTitleDirective;
}());
/**
 * `<ng-template ps-tab-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-modal>`.
 */
var PsModalContentDirective = (function () {
    function PsModalContentDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsModalContentDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-modal-content]'
                },] },
    ];
    /** @nocollapse */
    PsModalContentDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    PsModalContentDirective.propDecorators = {
        "css": [{ type: Input, args: ['class',] },],
    };
    return PsModalContentDirective;
}());
/**
 * `<ng-template ps-modal-foot>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-modal>`.
 */
var PsModalFootDirective = (function () {
    function PsModalFootDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsModalFootDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-modal-foot]'
                },] },
    ];
    /** @nocollapse */
    PsModalFootDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    PsModalFootDirective.propDecorators = {
        "css": [{ type: Input, args: ['class',] },],
    };
    return PsModalFootDirective;
}());
var nextUniqueId$5 = 0;
/**
 * `<ps-modal>`
 *
 * Componente Modal.
 */
var PsModalComponent = (function () {
    function PsModalComponent(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        /**
         * Evento disparado quando o modal é aberto (torna-se visível).
         */
        this._modalOnShow = new EventEmitter();
        /**
         * Evento disparado quando o modal é fechado.
         */
        this._modalOnHide = new EventEmitter();
        /**
         * Id único para o modal.
         */
        this._modalId = "Modal" + nextUniqueId$5++;
        /**
         * Id único para o container do modal.
         */
        this._modalContainerId = "ModalContainer" + nextUniqueId$5++;
        this._platform.setScreen();
    }
    /**
     * @return {?}
     */
    PsModalComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        for (var _i = 0, _a = PsModalAttributes.ATTRIBUTES; _i < _a.length; _i++) {
            var attribute = _a[_i];
            if (this._hasHostAttributes(attribute.prop)) {
                this._renderer2.addClass(this._getChildElementByClassName('ps-modal-container'), attribute.css);
                this._renderer2.addClass(this._getChildElementByClassName('ps-transition-modal'), attribute.css);
            }
        }
        if (this._show) {
            this.open(null);
        }
    };
    /**
     * @return {?}
     */
    PsModalComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        this._addCSSToViewChild();
        document.body.appendChild(this._getHostElement());
    };
    /** Método que abre o modal. Geralmente, chamado de algum evento de outro componente. */
    /**
     * Método que abre o modal. Geralmente, chamado de algum evento de outro componente.
     * @param {?} $event
     * @return {?}
     */
    PsModalComponent.prototype.open = /**
     * Método que abre o modal. Geralmente, chamado de algum evento de outro componente.
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
        var _this = this;
        this._setBodyOverflow('hidden');
        this._display = 'block';
        setTimeout(function () {
            _this._open = true;
        }, 100);
        if (!this._platform.IsMobile && $event !== null) {
            this._setupTransitionModalBeforeOpen($event);
        }
        this._modalOnShow.emit('Open modal');
    };
    /** Método que fecha o modal. */
    /**
     * Método que fecha o modal.
     * @return {?}
     */
    PsModalComponent.prototype.close = /**
     * Método que fecha o modal.
     * @return {?}
     */
    function () {
        var _this = this;
        this._open = false;
        setTimeout(function () {
            _this._display = 'none';
        }, 100);
        this._setBodyOverflow('auto');
        this._modalOnHide.emit('Close modal');
    };
    /** Método que verifica se houve um clique fora do modal.  */
    /**
     * Método que verifica se houve um clique fora do modal.
     * @param {?} e
     * @return {?}
     */
    PsModalComponent.prototype.closeOnClickedOutside = /**
     * Método que verifica se houve um clique fora do modal.
     * @param {?} e
     * @return {?}
     */
    function (e) {
        if (e.target === this._getHostElement().firstChild && !this._backdrop) {
            this.close();
        }
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    PsModalComponent.prototype.onkeyup = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        var /** @type {?} */ keyboarddisable = (typeof this._keyboard !== 'undefined' && this._keyboard === 'disable') ? true : false;
        if (ev.key === 'Escape' && !keyboarddisable) {
            this.close();
        }
    };
    /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @param {?} $event Evento passado do elemento trigger.
     * @return {?}
     */
    PsModalComponent.prototype._setupTransitionModalBeforeOpen = /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @param {?} $event Evento passado do elemento trigger.
     * @return {?}
     */
    function ($event) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ targetPosition = (/** @type {?} */ ($event.target)).getBoundingClientRect();
        var /** @type {?} */ unit = 'px';
        var /** @type {?} */ transitionModal = self._getChildElementByClassName('ps-transition-modal');
        var /** @type {?} */ top = targetPosition.top + unit;
        var /** @type {?} */ left = targetPosition.left + unit;
        var /** @type {?} */ width = targetPosition.width + unit;
        var /** @type {?} */ height = targetPosition.height + unit;
        self._renderer2.setStyle(transitionModal, 'top', top);
        self._renderer2.setStyle(transitionModal, 'left', left);
        self._renderer2.setStyle(transitionModal, 'width', width);
        self._renderer2.setStyle(transitionModal, 'height', height);
        self._renderer2.setStyle(transitionModal, 'display', 'block');
        var /** @type {?} */ transitionModalOpenCSS = 'ps-transition-modal-open';
        setTimeout(function () {
            var /** @type {?} */ modalCtt = document.getElementById(self._modalContainerId);
            var /** @type {?} */ modalContainerHeight = modalCtt.offsetHeight;
            var /** @type {?} */ newHeight = modalContainerHeight + unit;
            self._renderer2.setStyle(transitionModal, 'height', newHeight);
            self._renderer2.addClass(transitionModal, transitionModalOpenCSS);
        }, 50);
        setTimeout(function () {
            self._renderer2.removeClass(transitionModal, transitionModalOpenCSS);
            self._renderer2.setStyle(transitionModal, 'display', 'none');
        }, 1000);
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsModalComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Configura a propriedade overflow do body.
     * @param {?} overflow Valor da propriedade.
     * @return {?}
     */
    PsModalComponent.prototype._setBodyOverflow = /**
     * Configura a propriedade overflow do body.
     * @param {?} overflow Valor da propriedade.
     * @return {?}
     */
    function (overflow) {
        document.getElementsByTagName('body')[0].style.overflow = overflow;
    };
    /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    PsModalComponent.prototype._getChildElementByClassName = /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    function (css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsModalComponent.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    /**
     * Adiciona classes css passadas como parâmetros nos elementos filhos do modal (title, content e foot).
     * @return {?}
     */
    PsModalComponent.prototype._addCSSToViewChild = /**
     * Adiciona classes css passadas como parâmetros nos elementos filhos do modal (title, content e foot).
     * @return {?}
     */
    function () {
        if (this._modalTitle.css) {
            this._addClass(this.psModalTitle.nativeElement, this._modalTitle.css);
        }
        if (this._modalContent.css) {
            this._addClass(this.psModalContent.nativeElement, this._modalContent.css);
        }
        if (this._modalFoot.css) {
            this._addClass(this.psModalFoot.nativeElement, this._modalFoot.css);
        }
    };
    /**
     * Adiciona uma classe css ao elemento.
     * @param {?} element Referência de elemento HTMLElement.
     * @param {?} className Propriedade e valor css para ser adicionado no elemento.
     * @return {?}
     */
    PsModalComponent.prototype._addClass = /**
     * Adiciona uma classe css ao elemento.
     * @param {?} element Referência de elemento HTMLElement.
     * @param {?} className Propriedade e valor css para ser adicionado no elemento.
     * @return {?}
     */
    function (element, className) {
        if (element.classList) {
            element.classList.add(className);
        }
        else {
            element.className += ' ' + className;
        }
    };
    PsModalComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-modal',
                    template: "<div class=\"ps-modal\" [ngClass]=\"{'ps-modal-visible': _open,\n                                               'ps-modal-backdrop-static': _backdrop === 'static'}\"\n                  id=\"{{_modalId}}\"\n                  [ngStyle]=\"{'display': _display}\">\n              <div class=\"ps-modal-container\" (clickOutside)=\"closeOnClickedOutside($event)\" id=\"{{_modalContainerId}}\">\n                <a href=\"javascript:;\" (click)=\"close()\" class=\"ps-modal-close ps-modal-close-default\">\n                  <span class=\"ps-ico ps-ico-sm ps-sm-ico-lg ps-ico-close\"></span>\n                </a>\n                <div class=\"ps-modal-title\" #psModalTitle>\n                  <ng-template [ngTemplateOutlet]=\"_modalTitle.templateRef\"></ng-template>\n                </div>\n                <div class=\"ps-modal-content\" #psModalContent>\n                  <ng-template [ngTemplateOutlet]=\"_modalContent.templateRef\"></ng-template>\n                </div>\n                <div class=\"ps-modal-foot\" #psModalFoot>\n                  <ng-template [ngTemplateOutlet]=\"_modalFoot.templateRef\"></ng-template>\n                </div>\n              </div>\n            </div>\n            <div class=\"ps-transition-modal\" [hidden]=\"true\"></div>\n            ",
                    providers: [Platform]
                },] },
    ];
    /** @nocollapse */
    PsModalComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
    ]; };
    PsModalComponent.propDecorators = {
        "_show": [{ type: Input, args: ['show',] },],
        "_backdrop": [{ type: Input, args: ['backdrop',] },],
        "_keyboard": [{ type: Input, args: ['keyboard',] },],
        "_modalTitle": [{ type: ContentChild, args: [PsModalTitleDirective,] },],
        "psModalTitle": [{ type: ViewChild, args: ['psModalTitle',] },],
        "_modalContent": [{ type: ContentChild, args: [PsModalContentDirective,] },],
        "psModalContent": [{ type: ViewChild, args: ['psModalContent',] },],
        "_modalFoot": [{ type: ContentChild, args: [PsModalFootDirective,] },],
        "psModalFoot": [{ type: ViewChild, args: ['psModalFoot',] },],
        "_modalOnShow": [{ type: Output, args: ['modalonshow',] },],
        "_modalOnHide": [{ type: Output, args: ['modalonhide',] },],
        "onkeyup": [{ type: HostListener, args: ['document:keyup', ['$event'],] },],
    };
    return PsModalComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-form-multiselect>`
 *
 * Componente que define o select no formato de multiselect podendo selecionar
 * mais de um item em uma lista.
 */
var PsFormMultiselectComponent = (function () {
    function PsFormMultiselectComponent(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Array contendo as opções selecionadas no multiselect que são sincronizadas na select list de suporte.
         */
        this._modalCheckboxList = [];
    }
    /** Inicia a configuração do componente multiselect e suas dependências.  */
    /**
     * Inicia a configuração do componente multiselect e suas dependências.
     * @return {?}
     */
    PsFormMultiselectComponent.prototype.ngAfterContentInit = /**
     * Inicia a configuração do componente multiselect e suas dependências.
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        var /** @type {?} */ selectElement = /** @type {?} */ ((self._getHostElement().getElementsByTagName('select').item(0)));
        self._renderer2.addClass(selectElement, 'ps-frm-multiselect');
        self._renderer2.addClass(selectElement, 'ps-frm-valid');
        self._renderer2.setAttribute(selectElement, 'multiple', 'multiple');
        var /** @type {?} */ isValid = self._is(selectElement, '.ps-frm-valid');
        var /** @type {?} */ isDisabled = self._is(selectElement, 'disabled');
        var /** @type {?} */ thisId = Math.floor(Math.random() * 100);
        if (selectElement.id === '') {
            selectElement.id = 'psLib-select-' + thisId.toString();
        }
        var /** @type {?} */ modalId = 'psLib-ModalMultiple-' + thisId.toString();
        var /** @type {?} */ listId = 'psLib-ListMultiple-' + thisId.toString();
        if (typeof this._title === 'undefined' || !this._title) {
            this._title = 'Selecione uma op&ccedil;&atilde;o';
        }
        var /** @type {?} */ multiselectContainer = self._createMultiselectContainer(isValid, isDisabled, listId, selectElement);
        selectElement.dataset["multiselectlist"] = listId;
        var /** @type {?} */ selectOptions = selectElement.options;
        var /** @type {?} */ listBuffer = [];
        var /** @type {?} */ modalItens = [];
        self._createModalCheckboxList(selectOptions, thisId, modalItens, listBuffer);
        var /** @type {?} */ modal = self._getHostElement().getElementsByClassName('ps-modal').item(0);
        self._renderer2.addClass(modal, 'ps-multiselect-modal');
        var /** @type {?} */ modalContent = self._getHostElement().getElementsByClassName('ps-modal-content').item(0);
        self._renderer2.setStyle(modalContent, 'padding-bottom', '81px');
        modalItens.forEach(function (modalItem) {
            modalContent.appendChild(modalItem);
        });
        var /** @type {?} */ ul_psFrmMultiselectSelecteditens = self._renderer2.createElement('ul');
        self._renderer2.addClass(ul_psFrmMultiselectSelecteditens, 'ps-frm-multiselect-selecteditens');
        self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'none');
        listBuffer.forEach(function (li_Elem) {
            ul_psFrmMultiselectSelecteditens.appendChild(li_Elem);
        });
        multiselectContainer.appendChild(ul_psFrmMultiselectSelecteditens);
        var /** @type {?} */ a_psBtnMultiselectTrigger = self._renderer2.createElement('a');
        a_psBtnMultiselectTrigger.dataset.id = thisId;
        self._renderer2.addClass(a_psBtnMultiselectTrigger, 'ps-btn');
        self._renderer2.addClass(a_psBtnMultiselectTrigger, 'ps-btn-multiselect-trigger');
        a_psBtnMultiselectTrigger.innerHTML = 'Selecionar';
        a_psBtnMultiselectTrigger.addEventListener('click', function (event) {
            self._modalMultiselect.open(event);
        });
        multiselectContainer.appendChild(a_psBtnMultiselectTrigger);
        var /** @type {?} */ a_psBtnMultiselectAddRemove = self._renderer2.createElement('a');
        a_psBtnMultiselectAddRemove.dataset.id = thisId;
        self._renderer2.addClass(a_psBtnMultiselectAddRemove, 'ps-btn');
        self._renderer2.addClass(a_psBtnMultiselectAddRemove, 'ps-btn-primary');
        self._renderer2.addClass(a_psBtnMultiselectAddRemove, 'ps-btn-multiselect-addremove');
        self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'none');
        a_psBtnMultiselectAddRemove.innerHTML = '...';
        a_psBtnMultiselectAddRemove.addEventListener('click', function (event) {
            self._modalMultiselect.open(event);
        });
        multiselectContainer.appendChild(a_psBtnMultiselectAddRemove);
        if (listBuffer.length > 0) {
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'block');
            self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'block');
        }
    };
    /** Método que configura o multiselect quando o modal é fechado. */
    /**
     * Método que configura o multiselect quando o modal é fechado.
     * @return {?}
     */
    PsFormMultiselectComponent.prototype._formMultiSelectConfig = /**
     * Método que configura o multiselect quando o modal é fechado.
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        var /** @type {?} */ selectElement = /** @type {?} */ ((self._getHostElement().getElementsByTagName('select').item(0)));
        var /** @type {?} */ selectOptions = selectElement.options;
        var /** @type {?} */ ul_psFrmMultiselectSelecteditens = self._getHostElement().getElementsByClassName('ps-frm-multiselect-selecteditens').item(0);
        var /** @type {?} */ a_psBtnMultiselectAddRemove = this._getHostElement().getElementsByClassName('ps-btn-multiselect-addremove').item(0);
        var /** @type {?} */ a_psBtnMultiselectTrigger = this._getHostElement().getElementsByClassName('ps-btn-multiselect-trigger').item(0);
        var /** @type {?} */ hasChecked = false;
        Array.prototype.forEach.call(self._modalCheckboxList, function (checkbox, i) {
            var /** @type {?} */ id = checkbox.id;
            var /** @type {?} */ value = checkbox.value;
            var /** @type {?} */ checked = checkbox.checked;
            var /** @type {?} */ text = checkbox.dataset.multiselecttext;
            var /** @type {?} */ liCtt = ul_psFrmMultiselectSelecteditens.getElementsByClassName(id);
            var /** @type {?} */ li = null;
            if (liCtt !== null) {
                li = liCtt.item(0);
            }
            if (checked) {
                if (li === null) {
                    var /** @type {?} */ new_li = self._createListItem(id, text, value);
                    var /** @type {?} */ _a_psFrmMultiselectRemove_1 = new_li.getElementsByTagName('a').item(0);
                    Array.prototype.forEach.call(selectOptions, function (option, j) {
                        if (option.value === _a_psFrmMultiselectRemove_1.dataset.multiselectvalue) {
                            self._renderer2.setAttribute(option, 'selected', 'selected');
                            option.selected = true;
                        }
                    });
                    ul_psFrmMultiselectSelecteditens.appendChild(new_li);
                }
                hasChecked = true;
            }
            else {
                if (li !== null) {
                    var /** @type {?} */ _a_psFrmMultiselectRemove_2 = li.getElementsByTagName('a').item(0);
                    Array.prototype.forEach.call(selectOptions, function (option, j) {
                        if (option.value === _a_psFrmMultiselectRemove_2.dataset.multiselectvalue) {
                            self._renderer2.removeAttribute(option, 'selected');
                            option.selected = false;
                        }
                    });
                    ul_psFrmMultiselectSelecteditens.removeChild(li);
                }
            }
        });
        if (hasChecked) {
            self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'block');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'block');
            // TODO - Validation using data-onerror
            // psLib.FormShowFieldError("#"+list,true);
            // psLib.FormShowFieldError("#"+select,true);
        }
        else {
            self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'block');
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'none');
        }
    };
    /** Método que remove um item do multiselect e sincroniza com os checkboxes do modal.  */
    /**
     * Método que remove um item do multiselect e sincroniza com os checkboxes do modal.
     * @param {?} a_psFrmMultiselectRemove
     * @return {?}
     */
    PsFormMultiselectComponent.prototype._formMultiSelectRemove = /**
     * Método que remove um item do multiselect e sincroniza com os checkboxes do modal.
     * @param {?} a_psFrmMultiselectRemove
     * @return {?}
     */
    function (a_psFrmMultiselectRemove) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ li_psFrmMultiselectRemove = a_psFrmMultiselectRemove.parentElement;
        var /** @type {?} */ ul_psFrmMultiselectSelecteditens = self._getHostElement().getElementsByClassName('ps-frm-multiselect-selecteditens').item(0);
        var /** @type {?} */ selectElement = /** @type {?} */ ((self._getHostElement().getElementsByTagName('select').item(0)));
        var /** @type {?} */ selectOptions = selectElement.options;
        var /** @type {?} */ hasOptionSelected = false;
        Array.prototype.forEach.call(selectOptions, function (option, i) {
            if (option.value === a_psFrmMultiselectRemove.dataset.multiselectvalue) {
                self._renderer2.removeAttribute(option, 'selected');
                option.selected = false;
            }
            if (option.selected) {
                hasOptionSelected = true;
            }
            var /** @type {?} */ checkbox = self._modalCheckboxList[i];
            if (checkbox.value === a_psFrmMultiselectRemove.dataset.multiselectvalue) {
                self._renderer2.removeAttribute(checkbox, 'checked');
                checkbox.checked = false;
            }
        });
        ul_psFrmMultiselectSelecteditens.removeChild(li_psFrmMultiselectRemove);
        var /** @type {?} */ a_psBtnMultiselectAddRemove = this._getHostElement().getElementsByClassName('ps-btn-multiselect-addremove').item(0);
        var /** @type {?} */ a_psBtnMultiselectTrigger = this._getHostElement().getElementsByClassName('ps-btn-multiselect-trigger').item(0);
        if (!hasOptionSelected) {
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'block');
        }
        else {
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'block');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'none');
        }
    };
    /**
     * Cria o elemento container que conterá os elementos do multiselect.
     * @param {?} isValid
     * @param {?} isDisabled
     * @param {?} listId
     * @param {?} selectElement
     * @return {?}
     */
    PsFormMultiselectComponent.prototype._createMultiselectContainer = /**
     * Cria o elemento container que conterá os elementos do multiselect.
     * @param {?} isValid
     * @param {?} isDisabled
     * @param {?} listId
     * @param {?} selectElement
     * @return {?}
     */
    function (isValid, isDisabled, listId, selectElement) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ multiselectContainer = self._getHostElement().getElementsByClassName('ps-frm-multiselect-change').item(0);
        if (!multiselectContainer) {
            multiselectContainer = self._renderer2.createElement('div');
            this._renderer2.addClass(multiselectContainer, 'ps-frm-multiselect-change');
            if (isValid) {
                self._renderer2.addClass(multiselectContainer, 'ps-frm-valid');
            }
            if (isDisabled) {
                self._renderer2.addClass(multiselectContainer, 'ps-frm-disabled');
            }
            multiselectContainer.id = listId;
            multiselectContainer.dataset.onerror = self._onerror;
            self._insertAfter(multiselectContainer, selectElement);
        }
        return multiselectContainer;
    };
    /**
     * Método que cria a lista de checkbox a partir dos options no select definido para o componente.
     * @param {?} selectOptions
     * @param {?} thisId
     * @param {?} modalItens
     * @param {?} listBuffer
     * @return {?}
     */
    PsFormMultiselectComponent.prototype._createModalCheckboxList = /**
     * Método que cria a lista de checkbox a partir dos options no select definido para o componente.
     * @param {?} selectOptions
     * @param {?} thisId
     * @param {?} modalItens
     * @param {?} listBuffer
     * @return {?}
     */
    function (selectOptions, thisId, modalItens, listBuffer) {
        var /** @type {?} */ self = this;
        Array.prototype.forEach.call(selectOptions, function (option, i) {
            var /** @type {?} */ opt = option.value;
            var /** @type {?} */ optReplaced = opt.replace(/\//g, '-').replace(/\./g, '-').replace(/\|/g, '-').replace(/\#/g, '-');
            var /** @type {?} */ text = option.text;
            var /** @type {?} */ id = 'ps-frm-chk-' + optReplaced + '-' + thisId;
            var /** @type {?} */ modalItem = self._renderer2.createElement('div');
            self._renderer2.addClass(modalItem, 'ps-frm-multiselect-label');
            var /** @type {?} */ checkbox = self._renderer2.createElement('input');
            self._renderer2.setAttribute(checkbox, 'type', 'checkbox');
            self._renderer2.setAttribute(checkbox, 'name', 'ps-frm-chk-multiselect-' + thisId);
            self._renderer2.setAttribute(checkbox, 'value', opt);
            self._renderer2.addClass(checkbox, 'ps-frm-checkbox');
            checkbox.dataset.multiselecttext = text;
            self._renderer2.setAttribute(checkbox, 'id', id);
            if (option.selected) {
                self._renderer2.setAttribute(checkbox, 'checked', 'checked');
            }
            var /** @type {?} */ label = self._renderer2.createElement('label');
            self._renderer2.addClass(label, 'ps-frm-checkbox');
            self._renderer2.setAttribute(label, 'for', id);
            label.innerHTML = text;
            self._modalCheckboxList.push(checkbox);
            modalItem.appendChild(checkbox);
            modalItem.appendChild(label);
            modalItens.push(modalItem);
            if (option.selected) {
                var /** @type {?} */ li = self._createListItem(id, text, opt);
                listBuffer.push(li);
            }
        });
    };
    /**
     * Método que cria um item (li) de lista (ul) e configura o link para exclusão.
     * @param {?} id
     * @param {?} text
     * @param {?} value
     * @return {?}
     */
    PsFormMultiselectComponent.prototype._createListItem = /**
     * Método que cria um item (li) de lista (ul) e configura o link para exclusão.
     * @param {?} id
     * @param {?} text
     * @param {?} value
     * @return {?}
     */
    function (id, text, value) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ new_li = self._renderer2.createElement('li');
        self._renderer2.addClass(new_li, id);
        new_li.appendChild(self._renderer2.createText(text));
        var /** @type {?} */ a_psFrmMultiselectRemove = self._renderer2.createElement('a');
        self._renderer2.setAttribute(a_psFrmMultiselectRemove, 'href', 'javascript:;');
        self._renderer2.addClass(a_psFrmMultiselectRemove, 'ps-frm-multiselect-remove');
        a_psFrmMultiselectRemove.dataset.multiselect = id;
        a_psFrmMultiselectRemove.dataset.multiselectvalue = value;
        var /** @type {?} */ span = self._renderer2.createElement('span');
        self._renderer2.addClass(span, 'ps-ico');
        self._renderer2.addClass(span, 'ps-ico-close');
        a_psFrmMultiselectRemove.appendChild(span);
        new_li.appendChild(a_psFrmMultiselectRemove);
        a_psFrmMultiselectRemove.addEventListener('click', function (event) {
            self._formMultiSelectRemove(a_psFrmMultiselectRemove);
        });
        return new_li;
    };
    /**
     * Método que insere um novo elemento após o elemento alvo.
     * @param {?} newElement Referência HTMLElement do novo elemento.
     * @param {?} targetElement Referência HTMLElement do elemento que deve ser predecessor do novo.
     * @return {?}
     */
    PsFormMultiselectComponent.prototype._insertAfter = /**
     * Método que insere um novo elemento após o elemento alvo.
     * @param {?} newElement Referência HTMLElement do novo elemento.
     * @param {?} targetElement Referência HTMLElement do elemento que deve ser predecessor do novo.
     * @return {?}
     */
    function (newElement, targetElement) {
        var /** @type {?} */ parent = targetElement.parentNode;
        if (parent.lastChild === targetElement) {
            parent.appendChild(newElement);
        }
        else {
            parent.insertBefore(newElement, targetElement.nextSibling);
        }
    };
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param {?} el Referência HTMLElement do elemento que deve ser testado.
     * @param {?} selector Parâmetro para testar se o elemento possui.
     * @return {?} boolean.
     */
    PsFormMultiselectComponent.prototype._is = /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param {?} el Referência HTMLElement do elemento que deve ser testado.
     * @param {?} selector Parâmetro para testar se o elemento possui.
     * @return {?} boolean.
     */
    function (el, selector) {
        return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector ||
            el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsFormMultiselectComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsFormMultiselectComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-form-multiselect',
                    template: "<ng-content></ng-content>\n               <ps-modal #ModalMultiSelect (modalonhide)=\"_formMultiSelectConfig()\" ps-modal-medium-desktop-sm>\n                    <ng-template ps-modal-title>{{_title}}</ng-template>\n                    <ng-template ps-modal-content></ng-template>\n                    <ng-template ps-modal-foot>\n                        <div class=\"ps-mod8 ps-sm-mod4 ps-sm-lspan4\">\n                            <a href=\"javascript:;\"\n                               class=\"ps-btn ps-btn-primary ps-modal-close\"\n                               (click)=\"ModalMultiSelect.close();\">\n                                Selecionar\n                            </a>\n                        </div>\n                    </ng-template>\n                </ps-modal>"
                },] },
    ];
    /** @nocollapse */
    PsFormMultiselectComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsFormMultiselectComponent.propDecorators = {
        "_label": [{ type: Input, args: ['label',] },],
        "_title": [{ type: Input, args: ['title',] },],
        "_onerror": [{ type: Input, args: ['onerror',] },],
        "_modalMultiselect": [{ type: ViewChild, args: [PsModalComponent,] },],
    };
    return PsFormMultiselectComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Eugene Cheung Rights Reserved.
 * @author
 * Eugene Cheung https://github.com/arkon/ng-click-outside
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/arkon/ng-click-outside/blob/master/LICENSE
 */
var ClickOutsideDirective = (function () {
    function ClickOutsideDirective(_el, _ngZone, platformId) {
        this._el = _el;
        this._ngZone = _ngZone;
        this.platformId = platformId;
        this.attachOutsideOnClick = false;
        this.delayClickOutsideInit = false;
        this.exclude = '';
        this.excludeBeforeClick = false;
        this.clickOutsideEvents = '';
        this.clickOutsideEnabled = true;
        this.clickOutside = new EventEmitter();
        this._nodesExcluded = [];
        this._events = ['click'];
        this._initOnClickBody = this._initOnClickBody.bind(this);
        this._onClickBody = this._onClickBody.bind(this);
    }
    /**
     * @return {?}
     */
    ClickOutsideDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        this._init();
    };
    /**
     * @return {?}
     */
    ClickOutsideDirective.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        var _this = this;
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        if (this.attachOutsideOnClick) {
            this._events.forEach(function (e) { return _this._el.nativeElement.removeEventListener(e, _this._initOnClickBody); });
        }
        this._events.forEach(function (e) { return document.body.removeEventListener(e, _this._onClickBody); });
    };
    /**
     * @param {?} changes
     * @return {?}
     */
    ClickOutsideDirective.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        if (changes['attachOutsideOnClick'] || changes['exclude']) {
            this._init();
        }
    };
    /**
     * @return {?}
     */
    ClickOutsideDirective.prototype._init = /**
     * @return {?}
     */
    function () {
        var _this = this;
        if (this.clickOutsideEvents !== '') {
            this._events = this.clickOutsideEvents.split(',').map(function (e) { return e.trim(); });
        }
        this._excludeCheck();
        if (this.attachOutsideOnClick) {
            this._ngZone.runOutsideAngular(function () {
                _this._events.forEach(function (e) { return _this._el.nativeElement.addEventListener(e, _this._initOnClickBody); });
            });
        }
        else {
            this._initOnClickBody();
        }
    };
    /**
     * @return {?}
     */
    ClickOutsideDirective.prototype._initOnClickBody = /**
     * @return {?}
     */
    function () {
        if (this.delayClickOutsideInit) {
            setTimeout(this._initClickListeners.bind(this));
        }
        else {
            this._initClickListeners();
        }
    };
    /**
     * @return {?}
     */
    ClickOutsideDirective.prototype._initClickListeners = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this._ngZone.runOutsideAngular(function () {
            _this._events.forEach(function (e) { return document.body.addEventListener(e, _this._onClickBody); });
        });
    };
    /**
     * @return {?}
     */
    ClickOutsideDirective.prototype._excludeCheck = /**
     * @return {?}
     */
    function () {
        if (this.exclude) {
            try {
                var /** @type {?} */ nodes = /** @type {?} */ (Array.from(document.querySelectorAll(this.exclude)));
                if (nodes) {
                    this._nodesExcluded = nodes;
                }
            }
            catch (/** @type {?} */ err) {
                console.error('[ng-click-outside] Check your exclude selector syntax.', err);
            }
        }
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    ClickOutsideDirective.prototype._onClickBody = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        var _this = this;
        if (!this.clickOutsideEnabled) {
            return;
        }
        if (this.excludeBeforeClick) {
            this._excludeCheck();
        }
        if (!this._el.nativeElement.contains(ev.target) && !this._shouldExclude(ev.target)) {
            this._ngZone.run(function () { return _this.clickOutside.emit(ev); });
            if (this.attachOutsideOnClick) {
                this._events.forEach(function (e) { return document.body.removeEventListener(e, _this._onClickBody); });
            }
        }
    };
    /**
     * @param {?} target
     * @return {?}
     */
    ClickOutsideDirective.prototype._shouldExclude = /**
     * @param {?} target
     * @return {?}
     */
    function (target) {
        for (var _i = 0, _a = this._nodesExcluded; _i < _a.length; _i++) {
            var excludedNode = _a[_i];
            if (excludedNode.contains(target)) {
                return true;
            }
        }
        return false;
    };
    ClickOutsideDirective.decorators = [
        { type: Injectable },
        { type: Directive, args: [{ selector: '[clickOutside]' },] },
    ];
    /** @nocollapse */
    ClickOutsideDirective.ctorParameters = function () { return [
        { type: ElementRef, },
        { type: NgZone, },
        { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] },] },
    ]; };
    ClickOutsideDirective.propDecorators = {
        "attachOutsideOnClick": [{ type: Input },],
        "delayClickOutsideInit": [{ type: Input },],
        "exclude": [{ type: Input },],
        "excludeBeforeClick": [{ type: Input },],
        "clickOutsideEvents": [{ type: Input },],
        "clickOutsideEnabled": [{ type: Input },],
        "clickOutside": [{ type: Output },],
    };
    return ClickOutsideDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var nextUniqueId$6 = 0;
/**
 * Componente Modal aberto somente via service.
 */
var PsModalRefComponent = (function () {
    function PsModalRefComponent(_renderer2, _elementRef, _platform, psModalConfig) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        this.psModalConfig = psModalConfig;
        /**
         * Id único para o modal.
         */
        this._modalId = "Modal" + nextUniqueId$6++;
        /**
         * Id único para o container do modal.
         */
        this._modalContainerId = "ModalContainer" + nextUniqueId$6++;
        /**
         * Evento disparado quando o modal é fechado.
         */
        this._afterClosedObservable = new Subject$1();
        this._platform.setScreen();
    }
    /**
     * @return {?}
     */
    PsModalRefComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        if (this._show) {
            this.open(null);
        }
    };
    /**
     * @return {?}
     */
    PsModalRefComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        this._appendChild((/** @type {?} */ (this.psModalTitle.nativeElement)), this.psModalConfig.title);
        this._appendChild((/** @type {?} */ (this.psModalContent.nativeElement)), this.psModalConfig.content);
        this._appendChild((/** @type {?} */ (this.psModalFoot.nativeElement)), this.psModalConfig.foot);
        if (typeof this.psModalConfig.backdrop !== 'undefined') {
            this._backdrop = this.psModalConfig.backdrop;
        }
        if (typeof this.psModalConfig.keyboard !== 'undefined') {
            this._keyboard = this.psModalConfig.keyboard;
        }
        if (typeof this.psModalConfig.size !== 'undefined') {
            for (var _i = 0, _a = PsModalAttributes.ATTRIBUTES; _i < _a.length; _i++) {
                var attribute = _a[_i];
                if (attribute.prop === this.psModalConfig.size) {
                    this._renderer2.addClass(this._getChildElementByClassName('ps-modal-container'), attribute.css);
                    this._renderer2.addClass(this._getChildElementByClassName('ps-transition-modal'), attribute.css);
                }
            }
        }
        if (typeof this.psModalConfig.afterClosed !== 'undefined') {
            this.afterClosed = this.psModalConfig.afterClosed;
        }
        this._show = this.psModalConfig.show;
        document.body.appendChild(this._getHostElement());
    };
    /** Método que abre o modal. Chamado pelo service do modal. */
    /**
     * Método que abre o modal. Chamado pelo service do modal.
     * @param {?} $event
     * @return {?}
     */
    PsModalRefComponent.prototype.open = /**
     * Método que abre o modal. Chamado pelo service do modal.
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
        var _this = this;
        this._setBodyOverflow('hidden');
        this._display = 'block';
        setTimeout(function () {
            _this._open = true;
        }, 100);
        if (!this._platform.IsMobile && $event !== null) {
            this._setupTransitionModalBeforeOpen($event);
        }
    };
    /** Método que fecha o modal. */
    /**
     * Método que fecha o modal.
     * @return {?}
     */
    PsModalRefComponent.prototype.close = /**
     * Método que fecha o modal.
     * @return {?}
     */
    function () {
        var _this = this;
        this._open = false;
        this._afterClosedObservable.next(this.afterClosed);
        setTimeout(function () {
            _this._display = 'none';
        }, 100);
        this._setBodyOverflow('auto');
    };
    /** Método que verifica se houve um clique fora do modal.  */
    /**
     * Método que verifica se houve um clique fora do modal.
     * @param {?} e
     * @return {?}
     */
    PsModalRefComponent.prototype.closeOnClickedOutside = /**
     * Método que verifica se houve um clique fora do modal.
     * @param {?} e
     * @return {?}
     */
    function (e) {
        if (e.target === this._getHostElement().firstChild && !this._backdrop) {
            this.close();
        }
    };
    /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @param {?} $event Evento passado do elemento trigger.
     * @return {?}
     */
    PsModalRefComponent.prototype._setupTransitionModalBeforeOpen = /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @param {?} $event Evento passado do elemento trigger.
     * @return {?}
     */
    function ($event) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ targetPosition = (/** @type {?} */ ($event.target)).getBoundingClientRect();
        var /** @type {?} */ unit = 'px';
        var /** @type {?} */ transitionModal = self._getChildElementByClassName('ps-transition-modal');
        var /** @type {?} */ top = targetPosition.top + unit;
        var /** @type {?} */ left = targetPosition.left + unit;
        var /** @type {?} */ width = targetPosition.width + unit;
        var /** @type {?} */ height = targetPosition.height + unit;
        self._renderer2.setStyle(transitionModal, 'top', top);
        self._renderer2.setStyle(transitionModal, 'left', left);
        self._renderer2.setStyle(transitionModal, 'width', width);
        self._renderer2.setStyle(transitionModal, 'height', height);
        self._renderer2.setStyle(transitionModal, 'display', 'block');
        var /** @type {?} */ transitionModalOpenCSS = 'ps-transition-modal-open';
        setTimeout(function () {
            var /** @type {?} */ modalCtt = document.getElementById(self._modalContainerId);
            var /** @type {?} */ modalContainerHeight = modalCtt.offsetHeight;
            var /** @type {?} */ newHeight = modalContainerHeight + unit;
            self._renderer2.setStyle(transitionModal, 'height', newHeight);
            self._renderer2.addClass(transitionModal, transitionModalOpenCSS);
        }, 50);
        setTimeout(function () {
            self._renderer2.removeClass(transitionModal, transitionModalOpenCSS);
            self._renderer2.setStyle(transitionModal, 'display', 'none');
        }, 1000);
    };
    /**
     * @param {?} element
     * @param {?=} content
     * @return {?}
     */
    PsModalRefComponent.prototype._appendChild = /**
     * @param {?} element
     * @param {?=} content
     * @return {?}
     */
    function (element, content) {
        if (typeof content !== 'undefined') {
            element.appendChild(content);
        }
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsModalRefComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Configura a propriedade overflow do body.
     * @param {?} overflow Valor da propriedade.
     * @return {?}
     */
    PsModalRefComponent.prototype._setBodyOverflow = /**
     * Configura a propriedade overflow do body.
     * @param {?} overflow Valor da propriedade.
     * @return {?}
     */
    function (overflow) {
        document.getElementsByTagName('body')[0].style.overflow = overflow;
    };
    /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    PsModalRefComponent.prototype._getChildElementByClassName = /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    function (css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsModalRefComponent.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    /**
     * Adiciona uma classe css ao elemento.
     * @param {?} element Referência de elemento HTMLElement.
     * @param {?} className Propriedade e valor css para ser adicionado no elemento.
     * @return {?}
     */
    PsModalRefComponent.prototype._addClass = /**
     * Adiciona uma classe css ao elemento.
     * @param {?} element Referência de elemento HTMLElement.
     * @param {?} className Propriedade e valor css para ser adicionado no elemento.
     * @return {?}
     */
    function (element, className) {
        if (element.classList) {
            element.classList.add(className);
        }
        else {
            element.className += ' ' + className;
        }
    };
    PsModalRefComponent.decorators = [
        { type: Component, args: [{
                    template: " <div class=\"ps-modal\" [ngClass]=\"{'ps-modal-visible': _open,\n                                                'ps-modal-backdrop-static': _backdrop === 'static'}\"\n                     id=\"{{_modalId}}\"\n                     [ngStyle]=\"{'display': _display}\">\n                    <div class=\"ps-modal-container\" (clickOutside)=\"closeOnClickedOutside($event)\" id=\"{{_modalContainerId}}\">\n                        <a href=\"javascript:;\" (click)=\"close()\" class=\"ps-modal-close ps-modal-close-default\">\n                            <span class=\"ps-ico ps-ico-sm ps-sm-ico-lg ps-ico-close\"></span>\n                        </a>\n\n                        <div class=\"ps-modal-title\" #psModalTitle></div>\n\n                        <div class=\"ps-modal-content\" #psModalContent></div>\n\n                        <div class=\"ps-modal-foot\" #psModalFoot></div>\n                    </div>\n                </div>\n            <div class=\"ps-transition-modal\" [hidden]=\"true\"></div>"
                },] },
    ];
    /** @nocollapse */
    PsModalRefComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
        { type: undefined, decorators: [{ type: Inject, args: ['psModalConfig',] },] },
    ]; };
    PsModalRefComponent.propDecorators = {
        "psModalTitle": [{ type: ViewChild, args: ['psModalTitle',] },],
        "psModalContent": [{ type: ViewChild, args: ['psModalContent',] },],
        "psModalFoot": [{ type: ViewChild, args: ['psModalFoot',] },],
    };
    return PsModalRefComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Service para criar um componente modal dinamicamente.
 */
var PsModalService = (function () {
    function PsModalService(_renderer2, _injector, _resolver) {
        this._renderer2 = _renderer2;
        this._injector = _injector;
        this._resolver = _resolver;
        /**
         * Variável para listeners do callback chamado depois de abrir o modal.
         */
        this._afterOpen = new Subject$1();
        /**
         * Variável para listeners do callback chamado depois de fechar o modal.
         */
        this._afterClosed = new Subject$1();
    }
    /**
     * Método que configura, cria e abre um componente modal.
     * @param config Valores de configuração passados para o modal.
     * @param viewContainerRef Referência passada do componente que utiliza o service.
     * @param afterOpen Valor que deve ser passado quando o modal abrir aos callbacks.
     * @param afterClosed Valor que deve ser passado quando o modal fechar aos callbacks.
     */
    /**
     * Método que configura, cria e abre um componente modal.
     * @param {?} config Valores de configuração passados para o modal.
     * @param {?} viewContainerRef Referência passada do componente que utiliza o service.
     * @param {?=} afterOpen Valor que deve ser passado quando o modal abrir aos callbacks.
     * @param {?=} afterClosed Valor que deve ser passado quando o modal fechar aos callbacks.
     * @return {?}
     */
    PsModalService.prototype.openModal = /**
     * Método que configura, cria e abre um componente modal.
     * @param {?} config Valores de configuração passados para o modal.
     * @param {?} viewContainerRef Referência passada do componente que utiliza o service.
     * @param {?=} afterOpen Valor que deve ser passado quando o modal abrir aos callbacks.
     * @param {?=} afterClosed Valor que deve ser passado quando o modal fechar aos callbacks.
     * @return {?}
     */
    function (config, viewContainerRef, afterOpen, afterClosed) {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
        var /** @type {?} */ factory = this._resolver.resolveComponentFactory(PsModalRefComponent);
        var /** @type {?} */ injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psModalConfig',
                useValue: {
                    title: config.title,
                    content: config.content,
                    foot: config.foot,
                    backdrop: config.backdrop,
                    keyboard: config.keyboard,
                    size: config.size,
                    afterClosed: afterClosed,
                    show: true
                }
            }
        ]);
        this.componentRef = viewContainerRef.createComponent(factory, 0, injector);
        var /** @type {?} */ psModalRefComponent = (/** @type {?} */ (this.componentRef.instance));
        psModalRefComponent.open(null);
        this._afterClosed = psModalRefComponent._afterClosedObservable;
        this._afterOpen.next(afterOpen);
    };
    /** Método que retorna um Observable para escutar evento de abertura do modal.  */
    /**
     * Método que retorna um Observable para escutar evento de abertura do modal.
     * @return {?}
     */
    PsModalService.prototype.afterOpen = /**
     * Método que retorna um Observable para escutar evento de abertura do modal.
     * @return {?}
     */
    function () {
        return this._afterOpen.asObservable();
    };
    /** Método que fecha (esconde) o modal criado dinamicamente.  */
    /**
     * Método que fecha (esconde) o modal criado dinamicamente.
     * @param {?=} afterClosed
     * @return {?}
     */
    PsModalService.prototype.closeModal = /**
     * Método que fecha (esconde) o modal criado dinamicamente.
     * @param {?=} afterClosed
     * @return {?}
     */
    function (afterClosed) {
        if (this.componentRef) {
            (/** @type {?} */ (this.componentRef.instance)).close();
            this._afterClosed.next(afterClosed);
        }
    };
    /** Método que retorna um Observable para escutar evento de fechamento do modal.  */
    /**
     * Método que retorna um Observable para escutar evento de fechamento do modal.
     * @return {?}
     */
    PsModalService.prototype.afterClosed = /**
     * Método que retorna um Observable para escutar evento de fechamento do modal.
     * @return {?}
     */
    function () {
        if (this.componentRef) {
            return this._afterClosed.asObservable();
        }
    };
    PsModalService.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    PsModalService.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: Injector, },
        { type: ComponentFactoryResolver, },
    ]; };
    return PsModalService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsModalModule = (function () {
    function PsModalModule() {
    }
    PsModalModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsModalComponent,
                        PsModalTitleDirective,
                        PsModalContentDirective,
                        PsModalFootDirective,
                        ClickOutsideDirective
                    ],
                    declarations: [
                        PsModalComponent,
                        PsModalRefComponent,
                        PsModalTitleDirective,
                        PsModalContentDirective,
                        PsModalFootDirective,
                        ClickOutsideDirective
                    ],
                    providers: [PsModalService],
                    entryComponents: [PsModalRefComponent]
                },] },
    ];
    /** @nocollapse */
    PsModalModule.ctorParameters = function () { return []; };
    return PsModalModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-form-field-item>`
 *
 * Componente que adiciona o label correspondente para campos do tipo checkbox e radio.
 * É específico somente para estes dois casos pois a classe css não é a mesma.
 */
var PsFormFieldItemComponent = (function () {
    function PsFormFieldItemComponent() {
    }
    PsFormFieldItemComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-form-field-item',
                    template: "<ng-content></ng-content>\n                <label *ngIf=\"_labelCheckbox?.length\" class=\"ps-frm-checkbox\" for=\"\">{{_labelCheckbox}}</label>\n                <label *ngIf=\"_labelRadio?.length\" class=\"ps-frm-radio\" for=\"\">{{_labelRadio}}</label>"
                },] },
    ];
    /** @nocollapse */
    PsFormFieldItemComponent.ctorParameters = function () { return []; };
    PsFormFieldItemComponent.propDecorators = {
        "_labelCheckbox": [{ type: Input, args: ['label-checkbox',] },],
        "_labelRadio": [{ type: Input, args: ['label-radio',] },],
    };
    return PsFormFieldItemComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva de atributo que adiciona uma máscara ao campo input.
 * Baseado no plugin jQuery Mask Plugin do Igor Escobar sem uso do jquery.
 * https://github.com/igorescobar/jQuery-Mask-Plugin
 */
var PsMaskDirective = (function () {
    function PsMaskDirective(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        /**
         * O resto do código é praticamente idêntico ao original.
         */
        this.invalid = [];
        this.maskDigitPosMap = {};
        this.maskDigitPosMapOld = {};
        this.options = {
            maskElements: 'input,td,span,div',
            dataMask: true,
            keyStrokeCompensation: 5,
            reverse: false,
            // old versions of chrome dont work great with input event
            useInput: !/Chrome\/[2-4][0-9]|SamsungBrowser/.test(window.navigator.userAgent) && PsMaskDirective.eventSupported('input'),
            byPassKeys: [9, 16, 17, 18, 36, 37, 38, 39, 40, 91],
            translation: {
                '0': { pattern: /\d/ },
                '9': { pattern: /\d/, optional: true },
                '#': { pattern: /\d/, recursive: true },
                'A': { pattern: /[a-zA-Z0-9]/ },
                'S': { pattern: /[a-zA-Z]/ }
            }
        };
    }
    /**
     * @param {?} eventName
     * @return {?}
     */
    PsMaskDirective.eventSupported = /**
     * @param {?} eventName
     * @return {?}
     */
    function (eventName) {
        var /** @type {?} */ el = document.createElement('div'), /** @type {?} */ isSupported;
        eventName = 'on' + eventName;
        isSupported = (eventName in el);
        if (!isSupported) {
            el.setAttribute(eventName, 'return;');
            isSupported = typeof el[eventName] === 'function';
        }
        el = null;
        return isSupported;
    };
    /**
     * @return {?}
     */
    PsMaskDirective.prototype.ngAfterContentInit = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        var /** @type {?} */ inputElement = self._getHostElement();
        self._platform.setScreen();
        self.oldValue = inputElement.value;
        self._setHostElementAttribute('autocomplete', 'off');
        self._setHostElementAttribute('autocorrect', 'off');
        self._setHostElementAttribute('autocapitalize', 'off');
        self._setHostElementAttribute('spellcheck', 'false');
        self.regexMask = self.getRegexMask();
        if (!self._is(inputElement, 'input')) {
            self.events(inputElement);
            inputElement.value = self.getMasked(inputElement);
        }
        else {
            var /** @type {?} */ maxlength = true;
            for (var /** @type {?} */ i = 0; i < self._mask.length; i++) {
                var /** @type {?} */ translation = self.options.translation[self._mask.charAt(i)];
                if (translation && translation.recursive) {
                    maxlength = false;
                    break;
                }
            }
            if (maxlength) {
                self._setHostElementAttribute('maxlength', "" + self._mask.length);
                inputElement.dataset.maskMaxlength = true;
            }
            self.events(inputElement);
            var /** @type {?} */ caret = self.getCaret(inputElement);
            inputElement.value = self.getMasked(inputElement);
            self.setCaret(caret, inputElement);
        }
    };
    /**
     * @param {?} inputElement
     * @return {?}
     */
    PsMaskDirective.prototype.events = /**
     * @param {?} inputElement
     * @return {?}
     */
    function (inputElement) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ eventType = (self.options.useInput) ? 'input' : 'keyup';
        if (self._platform.IsMobile) {
            var /** @type {?} */ _observable = fromEvent$1(inputElement, eventType).pipe(map(function (e) { return e; }), debounceTime(200), distinctUntilChanged());
            _observable.subscribe(function (event) {
                self.behaviour(event, inputElement);
            });
        }
        else {
            inputElement.addEventListener(eventType, function (event) {
                self.behaviour(event, inputElement);
            });
        }
        inputElement.addEventListener('keydown', function (event) {
            inputElement.dataset.maskKeycode = /** @type {?} */ ((event.keyCode || event.which));
            inputElement.dataset.maskPreviusValue = inputElement.value;
            inputElement.dataset.maskPreviusCaretPos = self.getCaret(inputElement);
            self.maskDigitPosMapOld = self.maskDigitPosMap;
        });
        inputElement.addEventListener('focusout', function (event) {
            if (self._clearIfNotMatch && !self.regexMask.test(inputElement.value)) {
                inputElement.value = '';
            }
        });
        inputElement.addEventListener('change', function (event) {
            inputElement.dataset.changed = true;
        });
        inputElement.addEventListener('blur', function (event) {
            inputElement.dataset.changed = (self.oldValue === inputElement.value);
        });
        inputElement.addEventListener('blur', function (event) {
            self.oldValue = inputElement.value;
        });
    };
    /**
     * @param {?} inputElement
     * @param {?=} skipMaskChars
     * @param {?=} val
     * @return {?}
     */
    PsMaskDirective.prototype.getMasked = /**
     * @param {?} inputElement
     * @param {?=} skipMaskChars
     * @param {?=} val
     * @return {?}
     */
    function (inputElement, skipMaskChars, val) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ buf = [];
        var /** @type {?} */ value = val === undefined ? inputElement.value : val + '';
        var /** @type {?} */ m = 0;
        var /** @type {?} */ maskLen = self._mask.length;
        var /** @type {?} */ v = 0;
        var /** @type {?} */ valLen = value.length;
        var /** @type {?} */ offset = 1;
        var /** @type {?} */ addMethod = 'push';
        var /** @type {?} */ resetPos = -1;
        var /** @type {?} */ maskDigitCount = 0;
        var /** @type {?} */ maskDigitPosArr = [];
        var /** @type {?} */ lastMaskChar;
        var /** @type {?} */ check;
        self.options.reverse = inputElement.dataset.maskReverse ? true : false;
        if (self.options.reverse) {
            addMethod = 'unshift';
            offset = -1;
            lastMaskChar = 0;
            m = maskLen - 1;
            v = valLen - 1;
            check = function () {
                return m > -1 && v > -1;
            };
        }
        else {
            lastMaskChar = maskLen - 1;
            check = function () {
                return m < maskLen && v < valLen;
            };
        }
        var /** @type {?} */ lastUntranslatedMaskChar;
        while (check()) {
            var /** @type {?} */ maskDigit = self._mask.charAt(m);
            var /** @type {?} */ valDigit = value.charAt(v);
            var /** @type {?} */ translation = self.options.translation[maskDigit];
            if (translation) {
                if (valDigit.match(translation.pattern)) {
                    buf[addMethod](valDigit);
                    if (translation.recursive) {
                        if (resetPos === -1) {
                            resetPos = m;
                        }
                        else if (m === lastMaskChar && m !== resetPos) {
                            m = resetPos - offset;
                        }
                        if (lastMaskChar === resetPos) {
                            m -= offset;
                        }
                    }
                    m += offset;
                }
                else if (valDigit === lastUntranslatedMaskChar) {
                    // matched the last untranslated (raw) mask character that we encountered
                    // likely an insert offset the mask character from the last entry; fall
                    // through and only increment v
                    maskDigitCount--;
                    lastUntranslatedMaskChar = undefined;
                }
                else if (translation.optional) {
                    m += offset;
                    v -= offset;
                }
                else if (translation.fallback) {
                    buf[addMethod](translation.fallback);
                    m += offset;
                    v -= offset;
                }
                else {
                    self.invalid.push({ p: v, v: valDigit, e: translation.pattern });
                }
                v += offset;
            }
            else {
                if (!skipMaskChars) {
                    buf[addMethod](maskDigit);
                }
                if (valDigit === maskDigit) {
                    maskDigitPosArr.push(v);
                    v += offset;
                }
                else {
                    lastUntranslatedMaskChar = maskDigit;
                    maskDigitPosArr.push(v + maskDigitCount);
                    maskDigitCount++;
                }
                m += offset;
            }
        }
        var /** @type {?} */ lastMaskCharDigit = self._mask.charAt(lastMaskChar);
        if (maskLen === valLen + 1 && !self.options.translation[lastMaskCharDigit]) {
            buf.push(lastMaskCharDigit);
        }
        var /** @type {?} */ newVal = buf.join('');
        self.mapMaskdigitPositions(newVal, maskDigitPosArr, valLen);
        return newVal;
    };
    /**
     * @param {?} newVal
     * @param {?} maskDigitPosArr
     * @param {?} valLen
     * @return {?}
     */
    PsMaskDirective.prototype.mapMaskdigitPositions = /**
     * @param {?} newVal
     * @param {?} maskDigitPosArr
     * @param {?} valLen
     * @return {?}
     */
    function (newVal, maskDigitPosArr, valLen) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ maskDiff = self.options.reverse ? newVal.length - valLen : 0;
        self.maskDigitPosMap = {};
        for (var /** @type {?} */ i = 0; i < maskDigitPosArr.length; i++) {
            self.maskDigitPosMap[maskDigitPosArr[i] + maskDiff] = 1;
        }
    };
    /**
     * @param {?} inputElement
     * @return {?}
     */
    PsMaskDirective.prototype.getCaret = /**
     * @param {?} inputElement
     * @return {?}
     */
    function (inputElement) {
        try {
            var /** @type {?} */ sel = void 0;
            var /** @type {?} */ pos = 0;
            var /** @type {?} */ dSel = (/** @type {?} */ (document)).selection;
            var /** @type {?} */ cSelStart = inputElement.selectionStart;
            // IE Support
            if (dSel && navigator.appVersion.indexOf('MSIE 10') === -1) {
                sel = dSel.createRange();
                sel.moveStart('character', -inputElement.value.length);
                pos = sel.text.length;
            }
            else if (cSelStart || cSelStart === '0') {
                // Firefox support
                pos = cSelStart;
            }
            return pos;
        }
        catch (/** @type {?} */ e) { }
    };
    /**
     * @param {?} pos
     * @param {?} inputElement
     * @return {?}
     */
    PsMaskDirective.prototype.setCaret = /**
     * @param {?} pos
     * @param {?} inputElement
     * @return {?}
     */
    function (pos, inputElement) {
        var /** @type {?} */ self = this;
        try {
            if (self._is(inputElement, ':focus')) {
                // Firefox, WebKit, etc..
                if (inputElement.setSelectionRange) {
                    inputElement.setSelectionRange(pos, pos);
                }
                else {
                    // IE
                    var /** @type {?} */ range = inputElement.createTextRange();
                    range.collapse(true);
                    range.moveEnd('character', pos);
                    range.moveStart('character', pos);
                    range.select();
                }
            }
        }
        catch (/** @type {?} */ e) { }
    };
    /**
     * @param {?} e
     * @param {?} inputElement
     * @return {?}
     */
    PsMaskDirective.prototype.behaviour = /**
     * @param {?} e
     * @param {?} inputElement
     * @return {?}
     */
    function (e, inputElement) {
        var /** @type {?} */ self = this;
        e = e || window.event;
        self.invalid = [];
        var /** @type {?} */ keyCode = inputElement.dataset.maskKeycode;
        if (self.options.byPassKeys.indexOf(keyCode) === -1) {
            var /** @type {?} */ newVal = self.getMasked(inputElement);
            setTimeout(function () {
                self.setCaret(self.calculateCaretPosition(inputElement), inputElement);
            }, self.options.keyStrokeCompensation);
            inputElement.value = newVal;
        }
    };
    /**
     * @param {?} inputElement
     * @return {?}
     */
    PsMaskDirective.prototype.calculateCaretPosition = /**
     * @param {?} inputElement
     * @return {?}
     */
    function (inputElement) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ oldVal = inputElement.dataset.maskPreviusValue || '';
        var /** @type {?} */ newVal = self.getMasked(inputElement);
        var /** @type {?} */ caretPosNew = self.getCaret(inputElement);
        if (oldVal !== newVal) {
            var /** @type {?} */ caretPosOld = inputElement.dataset.maskPreviusCaretPos || 0;
            var /** @type {?} */ newValL = newVal.length;
            var /** @type {?} */ oldValL = oldVal.length;
            var /** @type {?} */ maskDigitsBeforeCaret = 0;
            var /** @type {?} */ maskDigitsAfterCaret = 0;
            var /** @type {?} */ maskDigitsBeforeCaretAll = 0;
            var /** @type {?} */ maskDigitsBeforeCaretAllOld = 0;
            var /** @type {?} */ i = 0;
            for (i = caretPosNew; i < newValL; i++) {
                if (!self.maskDigitPosMap[i]) {
                    break;
                }
                maskDigitsAfterCaret++;
            }
            for (i = caretPosNew - 1; i >= 0; i--) {
                if (!self.maskDigitPosMap[i]) {
                    break;
                }
                maskDigitsBeforeCaret++;
            }
            for (i = caretPosNew - 1; i >= 0; i--) {
                if (self.maskDigitPosMap[i]) {
                    maskDigitsBeforeCaretAll++;
                }
            }
            for (i = caretPosOld - 1; i >= 0; i--) {
                if (self.maskDigitPosMapOld[i]) {
                    maskDigitsBeforeCaretAllOld++;
                }
            }
            // if the cursor is at the end keep it there
            if (caretPosNew > oldValL) {
                caretPosNew = newValL * 10;
            }
            else if (caretPosOld >= caretPosNew && caretPosOld !== oldValL) {
                if (!self.maskDigitPosMapOld[caretPosNew]) {
                    var /** @type {?} */ caretPos = caretPosNew;
                    caretPosNew -= maskDigitsBeforeCaretAllOld - maskDigitsBeforeCaretAll;
                    caretPosNew -= maskDigitsBeforeCaret;
                    if (self.maskDigitPosMap[caretPosNew]) {
                        caretPosNew = caretPos;
                    }
                }
            }
            else if (caretPosNew > caretPosOld) {
                caretPosNew += maskDigitsBeforeCaretAll - maskDigitsBeforeCaretAllOld;
                caretPosNew += maskDigitsAfterCaret;
            }
        }
        return caretPosNew;
    };
    /**
     * @return {?}
     */
    PsMaskDirective.prototype.getRegexMask = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        var /** @type {?} */ maskChunks = [];
        var /** @type {?} */ translation;
        var /** @type {?} */ pattern;
        var /** @type {?} */ optional;
        var /** @type {?} */ recursive;
        var /** @type {?} */ oRecursive;
        var /** @type {?} */ r;
        for (var /** @type {?} */ i = 0; i < self._mask.length; i++) {
            translation = self.options.translation[self._mask.charAt(i)];
            if (translation) {
                pattern = translation.pattern.toString().replace(/.{1}$|^.{1}/g, '');
                optional = translation.optional;
                recursive = translation.recursive;
                if (recursive) {
                    maskChunks.push(self._mask.charAt(i));
                    oRecursive = { digit: self._mask.charAt(i), pattern: pattern };
                }
                else {
                    maskChunks.push(!optional && !recursive ? pattern : (pattern + '?'));
                }
            }
            else {
                maskChunks.push(self._mask.charAt(i).replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
            }
        }
        r = maskChunks.join('');
        if (oRecursive) {
            r = r.replace(new RegExp('(' + oRecursive.digit + '(.*' + oRecursive.digit + ')?)'), '($1)?')
                .replace(new RegExp(oRecursive.digit, 'g'), oRecursive.pattern);
        }
        return new RegExp(r);
    };
    /**
     * @param {?} attr
     * @param {?} value
     * @return {?}
     */
    PsMaskDirective.prototype._setHostElementAttribute = /**
     * @param {?} attr
     * @param {?} value
     * @return {?}
     */
    function (attr, value) {
        this._renderer2.setAttribute(this._getHostElement(), attr, value);
    };
    /**
     * @param {?} el
     * @param {?} selector
     * @return {?}
     */
    PsMaskDirective.prototype._is = /**
     * @param {?} el
     * @param {?} selector
     * @return {?}
     */
    function (el, selector) {
        return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector ||
            el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
    };
    /**
     * @return {?}
     */
    PsMaskDirective.prototype._getHostElement = /**
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsMaskDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-mask]',
                    providers: [Platform]
                },] },
    ];
    /** @nocollapse */
    PsMaskDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, decorators: [{ type: Inject, args: [Platform,] },] },
    ]; };
    PsMaskDirective.propDecorators = {
        "_mask": [{ type: Input, args: ['ps-mask',] },],
        "_clearIfNotMatch": [{ type: Input, args: ['ps-mask-clearIfNotMatch',] },],
    };
    return PsMaskDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsFormResourcesModule = (function () {
    function PsFormResourcesModule() {
    }
    PsFormResourcesModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        PsPopoverModule,
                        PsModalModule,
                        PsPanelModule
                    ],
                    exports: [
                        PsFormFieldComponent,
                        PsFieldEntryDirective,
                        PsFrmCleanupDirective,
                        PsFormCheckboxDirective,
                        PsFormRadioDirective,
                        PsFormTextAreaDirective,
                        PsFormSelectComponent,
                        PsFormOnOffComponent,
                        PsFormSelectListComponent,
                        PsFormMultiselectComponent,
                        PsFormFieldItemComponent,
                        PsMaskDirective
                    ],
                    declarations: [
                        PsFormFieldComponent,
                        PsFieldEntryDirective,
                        PsFrmCleanupDirective,
                        PsFormCheckboxDirective,
                        PsFormRadioDirective,
                        PsFormTextAreaDirective,
                        PsFormSelectComponent,
                        PsFormOnOffComponent,
                        PsFormSelectListComponent,
                        PsFormMultiselectComponent,
                        PsFormFieldItemComponent,
                        PsMaskDirective
                    ],
                    providers: [FormValidate]
                },] },
    ];
    /** @nocollapse */
    PsFormResourcesModule.ctorParameters = function () { return []; };
    return PsFormResourcesModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsCalendarModule = (function () {
    function PsCalendarModule() {
    }
    PsCalendarModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        PsFormResourcesModule
                    ],
                    exports: [
                        PsCalendarComponent
                    ],
                    declarations: [
                        PsCalendarComponent
                    ],
                    providers: [
                        Platform
                    ]
                },] },
    ];
    /** @nocollapse */
    PsCalendarModule.ctorParameters = function () { return []; };
    return PsCalendarModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva que define o elemento que contém a data para o calendário.
 */
var PsDateDirective = (function () {
    function PsDateDirective(elementRef) {
        this.elementRef = elementRef;
    }
    /**
     * @return {?}
     */
    PsDateDirective.prototype.getTextContent = /**
     * @return {?}
     */
    function () {
        return this.elementRef.nativeElement.textContent;
    };
    PsDateDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ps-date'
                },] },
    ];
    /** @nocollapse */
    PsDateDirective.ctorParameters = function () { return [
        { type: ElementRef, },
    ]; };
    return PsDateDirective;
}());
/**
 * `<ps-calendar-availability>`
 *
 * Componente que define um calendário de disponibilidade de datas (Calendário in-page).
 * Usa o JavaScript Datepicker: https://github.com/dbushell/Pikaday
 */
var PsCalendarAvailabilityComponent = (function () {
    function PsCalendarAvailabilityComponent() {
        /**
         * Evento de callback quando uma data é selecionada.
         */
        this.onSelect = new EventEmitter();
    }
    /** Método hook do angular. Instancia e configura o calendário.  */
    /**
     * Método hook do angular. Instancia e configura o calendário.
     * @return {?}
     */
    PsCalendarAvailabilityComponent.prototype.ngAfterContentInit = /**
     * Método hook do angular. Instancia e configura o calendário.
     * @return {?}
     */
    function () {
        var /** @type {?} */ self = this;
        var /** @type {?} */ dates = [];
        this._psDates.forEach(function (element) {
            dates.push(PsCalendarModel.getDateFromStr(element.getTextContent()));
        });
        self._pikaday = new Pikaday({
            field: self._datepicker.nativeElement,
            bound: false,
            container: self._datepickerContainer.nativeElement,
            setDefaultDate: PsCalendarModel.setDefaultDate,
            disableWeekends: PsCalendarModel.disableWeekends,
            format: !self._format ? PsCalendarModel.format : self._format,
            defaultDate: null,
            minDate: null,
            maxDate: null,
            toString: /**
             * @param {?} date
             * @param {?} format
             * @return {?}
             */
            function (date, format) {
                return PsCalendarModel.getFormattedDate(date);
            },
            i18n: PsCalendarModel.i18n,
            onSelect: function (date) {
                self.onSelect.emit(PsCalendarModel.getFormattedDate(date));
            },
            disableDayFn: function (dateTime) {
                var /** @type {?} */ disable = true;
                var /** @type {?} */ formattedDate = PsCalendarModel.getFormattedDate(dateTime);
                dates.forEach(function (element) {
                    if (PsCalendarModel.getFormattedDate(element) === formattedDate) {
                        disable = false;
                        return;
                    }
                });
                return disable;
            }
        });
    };
    PsCalendarAvailabilityComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-calendar-availability',
                    template: "<div class=\"ps-frm-row\">\n                <label class=\"ps-frm-lbl\">{{_label}}</label>\n                <input type=\"text\" [style.display]=\"'none'\" name=\"{{_name}}\" id=\"{{_id}}\" class=\"ps-frm-entry\" #datepicker/>\n                <div #datepickerContainer></div>\n             </div>",
                    styles: PsCalendarStyle.styles,
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsCalendarAvailabilityComponent.ctorParameters = function () { return []; };
    PsCalendarAvailabilityComponent.propDecorators = {
        "_label": [{ type: Input, args: ['label',] },],
        "_name": [{ type: Input, args: ['name',] },],
        "_id": [{ type: Input, args: ['id',] },],
        "_format": [{ type: Input, args: ['format',] },],
        "onSelect": [{ type: Output },],
        "_psDates": [{ type: ContentChildren, args: [PsDateDirective,] },],
        "_datepicker": [{ type: ViewChild, args: ['datepicker',] },],
        "_datepickerContainer": [{ type: ViewChild, args: ['datepickerContainer',] },],
    };
    return PsCalendarAvailabilityComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsCalendarAvailabilityModule = (function () {
    function PsCalendarAvailabilityModule() {
    }
    PsCalendarAvailabilityModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        FormsModule
                    ],
                    exports: [
                        PsCalendarAvailabilityComponent,
                        PsDateDirective
                    ],
                    declarations: [
                        PsCalendarAvailabilityComponent,
                        PsDateDirective
                    ]
                },] },
    ];
    /** @nocollapse */
    PsCalendarAvailabilityModule.ctorParameters = function () { return []; };
    return PsCalendarAvailabilityModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Mapeamento dos atributos que definem tamanho para as respectivas classes css.
 */
var PS_CARD_ATTRIBUTES = [
    { prop: 'smaller', css: 'ps-card--smaller' },
    { prop: 'small', css: 'ps-card--small' },
    { prop: 'medium', css: 'ps-card--medium' },
    { prop: 'big', css: 'ps-card--big' },
    { prop: 'bigger', css: 'ps-card--bigger' }
];
/**
 * `<ps-card>`
 *
 * Componente que cria um card (cartão ou painel) responsive.
 */
var PsCardComponent = (function () {
    function PsCardComponent(_renderer, _elementRef) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
    }
    /** Método hook do angular que adiciona as classes css de acordo com os atributos contidos no  host elemento.  */
    /**
     * Método hook do angular que adiciona as classes css de acordo com os atributos contidos no  host elemento.
     * @return {?}
     */
    PsCardComponent.prototype.ngAfterContentInit = /**
     * Método hook do angular que adiciona as classes css de acordo com os atributos contidos no  host elemento.
     * @return {?}
     */
    function () {
        for (var _i = 0, PS_CARD_ATTRIBUTES_1 = PS_CARD_ATTRIBUTES; _i < PS_CARD_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_CARD_ATTRIBUTES_1[_i];
            if (this._hasHostAttributes(attribute.prop)) {
                this._renderer.addClass(this._getChildElementByClassName('ps-card'), attribute.css);
            }
        }
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsCardComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    PsCardComponent.prototype._getChildElementByClassName = /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    function (css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsCardComponent.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    PsCardComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-card',
                    template: "<div class=\"ps-card ps-bg--white ps-alignCenter\">\n             <ng-content></ng-content>\n            </div>"
                },] },
    ];
    /** @nocollapse */
    PsCardComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsCardComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsCardModule = (function () {
    function PsCardModule() {
    }
    PsCardModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsCardComponent
                    ],
                    declarations: [
                        PsCardComponent
                    ]
                },] },
    ];
    /** @nocollapse */
    PsCardModule.ctorParameters = function () { return []; };
    return PsCardModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-carousel>`
 *
 * Componente para criação de carrossel (slider de imagens, cards, etc.).
 * Baseado no componente 'ngx-carousel': https://github.com/sheikalthaf/ngx-carousel
 */
var PsCarouselComponent = (function () {
    function PsCarouselComponent() {
        this.arrow = true;
        this.points = true;
        this.start = 1;
        this.interval = 5000;
        this.slidesToScroll = 1;
        this.slidesToShow = 1;
        this.loop = true;
        this.dataItem = [];
        this.arrowOri = true;
        this.config = {};
    }
    /**
     * @return {?}
     */
    PsCarouselComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        var /** @type {?} */ xs = 1;
        var /** @type {?} */ sm = 1;
        var /** @type {?} */ md = this.slidesToShow;
        var /** @type {?} */ lg = this.slidesToShow;
        if (typeof this.responsive === 'object') {
            this.responsive.map(function (resp) {
                if (resp['breakpoint'] < 768) {
                    if (typeof resp['settings']['slidesToShow'] === 'number') {
                        xs = resp['settings']['slidesToShow'];
                        sm = resp['settings']['slidesToShow'];
                    }
                    _this.setConfig('xs', resp['settings']);
                    _this.setConfig('sm', resp['settings']);
                }
                if (resp['breakpoint'] >= 768 && resp['breakpoint'] < 992) {
                    if (typeof resp['settings']['slidesToShow'] === 'number') {
                        sm = resp['settings']['slidesToShow'];
                    }
                    _this.setConfig('sm', resp['settings']);
                }
                if (resp['breakpoint'] >= 992 && resp['breakpoint'] < 1200) {
                    if (typeof resp['settings']['slidesToShow'] === 'number') {
                        md = resp['settings']['slidesToShow'];
                    }
                    _this.setConfig('md', resp['settings']);
                }
                if (resp['breakpoint'] >= 1200) {
                    if (typeof resp['settings']['slidesToShow'] === 'number') {
                        lg = resp['settings']['slidesToShow'];
                    }
                    _this.setConfig('lg', resp['settings']);
                }
            });
        }
        this.start = this.start - 1;
        this.carousel = {
            interval: this.interval,
            slide: this.slidesToScroll,
            load: this.slidesToScroll,
            point: {
                visible: this.points
            },
            grid: { xs: xs, sm: sm, md: md, lg: lg, all: 0 },
            loop: this.loop,
            touch: true,
        };
        this.arrowOri = (this.arrow);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    PsCarouselComponent.prototype.onResize = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.loadResponsive();
    };
    /**
     * @param {?} type
     * @param {?} value
     * @return {?}
     */
    PsCarouselComponent.prototype.setConfig = /**
     * @param {?} type
     * @param {?} value
     * @return {?}
     */
    function (type, value) {
        this.config[type] = value;
    };
    /**
     * @return {?}
     */
    PsCarouselComponent.prototype.loadMain = /**
     * @return {?}
     */
    function () {
        this.carouselElement.data.loop = this.loop;
        this.carouselElement.userData.load = this.slidesToScroll;
        this.carouselElement.userData.slide = this.slidesToScroll;
        this.carouselElement.data.load = this.slidesToScroll;
        this.carouselElement.data.slideItems = this.slidesToScroll;
        if (this.arrowOri) {
            this.btnLeftRight(false);
        }
        else {
            this.btnLeftRight(true);
        }
    };
    /**
     * @param {?} status
     * @return {?}
     */
    PsCarouselComponent.prototype.btnLeftRight = /**
     * @param {?} status
     * @return {?}
     */
    function (status) {
        this.btnLeft.nativeElement.hidden = status;
        this.btnRight.nativeElement.hidden = status;
    };
    /**
     * @return {?}
     */
    PsCarouselComponent.prototype.loadResponsive = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ parent = this;
        setTimeout(function () {
            var /** @type {?} */ type = parent.carouselElement.data.deviceType;
            if (typeof parent.config[type] !== 'undefined') {
                var /** @type {?} */ responsive = parent.config[type];
                if (typeof responsive.infinite === 'boolean') {
                    parent.carouselElement.data.loop = responsive.infinite;
                }
                if (typeof responsive.slidesToScroll === 'number') {
                    parent.carouselElement.userData.load = responsive.slidesToScroll;
                    parent.carouselElement.userData.slide = responsive.slidesToScroll;
                    parent.carouselElement.data.load = responsive.slidesToScroll;
                    parent.carouselElement.data.slideItems = responsive.slidesToScroll;
                }
                if (typeof responsive.arrows === 'boolean') {
                    if (parent.arrow) {
                        parent.btnLeftRight(false);
                    }
                    else {
                        parent.btnLeftRight(true);
                    }
                }
            }
            else {
                parent.loadMain();
            }
        }, 400);
    };
    /**
     * @param {?} data
     * @return {?}
     */
    PsCarouselComponent.prototype.afterCarouselViewedFn = /**
     * @param {?} data
     * @return {?}
     */
    function (data) {
        this.loadResponsive();
    };
    PsCarouselComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-carousel',
                    template: "<div class=\"ps-ng-carousel\">\n              <ngx-carousel #carouselElement\n                class=\"ps-carousel-container\"\n                [inputs]=\"carousel\"\n                [moveToSlide]=\"start\"\n                (afterCarouselViewed)=\"afterCarouselViewedFn($event)\">\n                <ngx-item NgxCarouselItem *ngFor=\"let item of dataItem\" class=\"ps-carousel-item\">\n                    <ng-container *ngTemplateOutlet=\"template;context:item\"></ng-container>\n                </ngx-item>\n                <button #btnLeft  NgxCarouselPrev class='leftRs'>&lt;</button>\n                <button #btnRight  NgxCarouselNext class='rightRs'>&gt;</button>\n              </ngx-carousel>\n            </div>",
                    styles: ["@charset \"UTF-8\";\n            .ps-ng-carousel {\n              position: relative;\n              overflow-x: hidden;\n              visibility: visible !important;\n              max-width: 100%;\n            }\n            .ps-ng-carousel .ngxcarouselPoint li {\n              list-style: none;\n              display: inline-block;\n              width: 20px;\n              height: 20px;\n              margin: 0 2px;\n              cursor: pointer;\n              background: none !important;\n            }\n            .ps-ng-carousel .ngxcarouselPoint li:before {\n              content: \"\";\n              display: inline-block;\n              width: 6px;\n              height: 6px;\n              border-radius: 999px;\n              opacity: 0.25;\n              background: #000;\n              cursor: pointer;\n              -webkit-font-smoothing: antialiased;\n              transition: all ease 0.3s;\n            }\n            .ps-ng-carousel .ngxcarouselPoint li:hover:before {\n              opacity: 1;\n              background: #3DACFF;\n            }\n            .ps-ng-carousel .ngxcarouselPoint li.active {\n              transform: scale(1) !important;\n            }\n            .ps-ng-carousel .ngxcarouselPoint li.active:before {\n              opacity: 1;\n              background: #3DACFF;\n            }\n            .ps-ng-carousel .ngxcarousel {\n              margin: 0 48px;\n              position: relative;\n            }\n\n            .leftRs,\n            .rightRs {\n              box-shadow: none;\n              background: none;\n              position: relative;\n              color: transparent;\n              cursor: pointer;\n            }\n            .leftRs:focus, .leftRs:active, .leftRs:focus:active,\n            .rightRs:focus,\n            .rightRs:active,\n            .rightRs:focus:active {\n              box-shadow: none !important;\n              outline: none !important;\n            }\n            .leftRs:before,\n            .rightRs:before {\n              position: absolute;\n              letter-spacing: 0;\n              top: 0;\n              left: 0;\n              text-align: center;\n              width: 48px;\n              line-height: 48px;\n              font-family: ps_glyph_icons;\n              opacity: 0.75;\n              font-weight: 400;\n              color: #777;\n              font-size: 16px;\n            }\n\n            .leftRs {\n              position: absolute;\n              margin: auto;\n              top: 0;\n              bottom: 0;\n              left: -48px;\n              width: 48px;\n              height: 48px;\n              border-radius: 999px;\n              text-align: center;\n            }\n            .leftRs:before {\n              content: \"\\e961\";\n            }\n\n            .rightRs {\n              position: absolute;\n              margin: auto;\n              top: 0;\n              bottom: 0;\n              width: 48px;\n              height: 48px;\n              border-radius: 999px;\n              right: -48px;\n            }\n            .rightRs:before {\n              content: \"\\e962\";\n            }"],
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsCarouselComponent.ctorParameters = function () { return []; };
    PsCarouselComponent.propDecorators = {
        "carouselElement": [{ type: ViewChild, args: [NgxCarouselComponent,] },],
        "btnLeft": [{ type: ViewChild, args: ['btnLeft',] },],
        "btnRight": [{ type: ViewChild, args: ['btnRight',] },],
        "arrow": [{ type: Input, args: ['carouselarrow',] },],
        "points": [{ type: Input, args: ['carouselbullets',] },],
        "start": [{ type: Input, args: ['carouselstart',] },],
        "interval": [{ type: Input, args: ['carouselinterval',] },],
        "slidesToScroll": [{ type: Input, args: ['carouselscroll',] },],
        "template": [{ type: Input },],
        "slidesToShow": [{ type: Input },],
        "loop": [{ type: Input, args: ['carouselwrap',] },],
        "responsive": [{ type: Input, args: ['responsive',] },],
        "dataItem": [{ type: Input, args: ['data',] },],
        "onResize": [{ type: HostListener, args: ['window:resize', ['$event'],] },],
    };
    return PsCarouselComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsCarouselModule = (function () {
    function PsCarouselModule() {
    }
    PsCarouselModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [
                        PsCarouselComponent
                    ],
                    imports: [
                        NgxCarouselModule,
                        CommonModule
                    ],
                    exports: [
                        PsCarouselComponent
                    ],
                },] },
    ];
    /** @nocollapse */
    PsCarouselModule.ctorParameters = function () { return []; };
    return PsCarouselModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-ico>`
 *
 * Componente de Ícone.
 */
var PsIcoComponent = (function () {
    function PsIcoComponent() {
        /**
         * Prefixo das classes css na biblioteca de ícones.
         */
        this.PS_ICO_PREFIX = 'ps-ico-';
    }
    /**
     * @return {?}
     */
    PsIcoComponent.prototype.ngOnChanges = /**
     * @return {?}
     */
    function () {
        if (this._size) {
            this._size = this.PS_ICO_PREFIX + this._size;
        }
        if (this._ico) {
            this._ico = this.PS_ICO_PREFIX + this._ico;
        }
    };
    PsIcoComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-ico',
                    template: "<span class=\"ps-ico {{_size}} {{_type}} {{_ico}}\"></span>"
                },] },
    ];
    /** @nocollapse */
    PsIcoComponent.ctorParameters = function () { return []; };
    PsIcoComponent.propDecorators = {
        "_size": [{ type: Input, args: ['ps-size',] },],
        "_type": [{ type: Input, args: ['ps-type',] },],
        "_ico": [{ type: Input, args: ['ps-ico',] },],
    };
    return PsIcoComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsIcoModule = (function () {
    function PsIcoModule() {
    }
    PsIcoModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsIcoComponent
                    ],
                    declarations: [
                        PsIcoComponent
                    ],
                },] },
    ];
    /** @nocollapse */
    PsIcoModule.ctorParameters = function () { return []; };
    return PsIcoModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * `<ps-chart>`
 *
 * Componente para geração de gráficos (charts).
 * Baseado no componente 'ng2-charts': https://valor-software.com/ng2-charts/
 */
var PsChartComponent = (function () {
    function PsChartComponent(_renderer2) {
        this._renderer2 = _renderer2;
        this.type = 'line';
        this.source = [];
        this.config = [];
        this.showLegend = false;
        this.height = 400;
        this.download = false;
        this.chartData = [];
        this.chartLabels = [];
        this.psChartOptions = {};
        this.width = 600;
        this.isConfigured = false;
    }
    /**
     * @return {?}
     */
    PsChartComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.LoadChartData();
        this.ChartSetup1();
    };
    /**
     * @return {?}
     */
    PsChartComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        this.ChartSetup2();
        this.ChartSetup3();
    };
    /**
     * @param {?} changes
     * @return {?}
     */
    PsChartComponent.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if (changes.hasOwnProperty('source') && this.isConfigured) {
            this.LoadChartData();
            this.grafico.updateChartData(this.chartData);
            this.grafico.chart.data.labels = this.chartLabels;
            this.ChartSetup1();
            this.ChartSetup2();
            this.ChartSetup3();
        }
    };
    /**
     * @return {?}
     */
    PsChartComponent.prototype.LoadChartData = /**
     * @return {?}
     */
    function () {
        if (typeof this.source === 'undefined' || !this.source) {
            throw Error('Configuração incorreta do gráfico.');
        }
        if (this.type === 'pie' || this.type === 'doughnut' || this.type === 'polarArea') {
            if (this.chartData.length > 0) {
                this.chartData = [];
            }
            if (this.chartLabels.length > 0) {
                this.chartLabels = [];
            }
            for (var _i = 0, _a = this.source; _i < _a.length; _i++) {
                var v = _a[_i];
                this.chartData.push(v.value);
                this.chartLabels.push(v.label);
            }
        }
        else {
            this.chartData = this.source['datasets'];
            this.chartLabels = this.source['labels'];
        }
    };
    /**
     * @return {?}
     */
    PsChartComponent.prototype.ChartSetup1 = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ data = this.chartData;
        this.psChartOptions = {
            responsive: true,
            showLine: false,
            animation: false,
            scaleGridLineWidth: 1,
            tooltips: {
                fontFamily: '"open_sans", Arial, Sans-serif',
                cornerRadius: 2,
                backgroundColor: 'rgba(0,0,0,.5)'
            }
        };
        if (this.type === 'pie' || this.type === 'doughnut') {
            this.psChartOptions.showTooltips = false;
            this.psChartOptions.tooltips['caretSize'] = 3;
            this.psChartOptions.tooltips['mode'] = 'label';
            this.psChartOptions.tooltips['enabled'] = true;
            if (data.length <= 7) {
                this.psChartOptions.tooltips['callbacks'] = {
                    label: function (tooltipItem, _data) {
                        var /** @type {?} */ value = _data.datasets[0].data[tooltipItem.index];
                        var /** @type {?} */ label = _data.labels[tooltipItem.index];
                        var /** @type {?} */ totalSessions = _data.datasets[0].data.reduce(function (acumulador, valorAtual, indice, array) {
                            return acumulador + valorAtual;
                        }, 0);
                        // tslint:disable-next-line:radix
                        var /** @type {?} */ percentage = Math.round(parseInt(value) / totalSessions * 100);
                        return label + ' : ' + percentage + '%';
                    }
                };
            }
            else {
                this.psChartOptions.tooltips['callbacks'] = {
                    label: function (tooltipItem, _data) {
                        var /** @type {?} */ value = _data.datasets[0].data[tooltipItem.index];
                        return value;
                    }
                };
            }
        }
        if (this.type === 'line' || this.type === 'bar' || this.type === 'radar') {
            this.psChartOptions.tooltips['mode'] = 'index';
            this.psChartOptions.tooltips['intersect'] = true;
        }
        if (this.config) {
            this.psChartOptions = Object.assign({}, this.psChartOptions, this.config);
        }
    };
    /**
     * @return {?}
     */
    PsChartComponent.prototype.ChartSetup2 = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ datasets = [];
        var /** @type {?} */ setsCount = 0;
        // Find datasets and length
        var /** @type {?} */ chartType = this.grafico.chart.config.type;
        switch (chartType) {
            case 'pie':
            case 'doughnut':
            case 'polarArea':
                datasets = this.grafico.chart.config.data.datasets[0];
                setsCount = datasets['data'].length;
                break;
            case 'bar':
            case 'line':
            case 'radar':
                datasets = this.grafico.chart.config.data.datasets;
                setsCount = datasets.length;
                break;
        }
        var /** @type {?} */ bgColor = this.pschart['nativeElement'].style.background ? this.pschart['nativeElement'].style.background : '#018cb7';
        var /** @type {?} */ colors;
        for (var /** @type {?} */ i = 0; i < setsCount; i++) {
            switch (chartType) {
                case 'pie':
                case 'doughnut':
                    colors = typeof datasets['baseColor'] !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets['baseColor'], bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    if (!datasets['backgroundColor']) {
                        datasets['backgroundColor'] = [];
                    }
                    datasets['backgroundColor'][i] = colors['backgroundColor'];
                    if (!datasets['borderColor']) {
                        datasets['borderColor'] = [];
                    }
                    datasets['borderColor'][i] = colors['color'];
                    break;
                case 'polarArea':
                    colors = typeof datasets['baseColor'] !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets['baseColor'], bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    if (!datasets['backgroundColor']) {
                        datasets['backgroundColor'] = [];
                    }
                    datasets['backgroundColor'][i] = colors['backgroundColor'];
                    if (!datasets['borderColor']) {
                        datasets['borderColor'] = [];
                    }
                    datasets['borderColor'][i] = colors['color'];
                    if (!datasets['hoverBackgroundColor']) {
                        datasets['hoverBackgroundColor'] = [];
                    }
                    datasets['hoverBackgroundColor'][i] = colors['highlight'];
                    break;
                case 'bar':
                    colors = typeof datasets[i].baseColor !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets[i].datasets[i].baseColor, bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    datasets[i].borderColor = colors.borderColor;
                    datasets[i].backgroundColor = colors.backgroundColor;
                    datasets[i].borderWidth = colors.borderWidth;
                    datasets[i].hoverBackgroundColor = colors.highlightFill;
                    datasets[i].hoverBorderColor = colors.highlightStroke;
                    break;
                case 'radar':
                case 'line':
                    colors = typeof datasets[i].baseColor !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets[i].datasets[i].baseColor, bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    datasets[i].borderColor = colors.borderColor;
                    datasets[i].backgroundColor = colors.backgroundColor;
                    datasets[i].pointHoverBackgroundColor = colors.pointHoverBackgroundColor;
                    datasets[i].pointHoverBorderColor = colors.pointHoverBorderColor;
                    datasets[i].pointColor = colors.pointColor;
                    datasets[i].pointBorderColor = colors.pointBorderColor;
                    datasets[i].lineTension = 0;
                    break;
            }
        }
        // Update the chart to show the new colors
        this.grafico.chart.update();
        this.isConfigured = true;
    };
    /**
     * @return {?}
     */
    PsChartComponent.prototype.ChartSetup3 = /**
     * @return {?}
     */
    function () {
        if (this.download) {
            this._renderer2.setAttribute(this.base64Image.nativeElement, 'href', this.grafico.chart.toBase64Image());
        }
    };
    /**
     * @param {?} type
     * @param {?} color
     * @param {?} bgColor
     * @return {?}
     */
    PsChartComponent.prototype.ChartColorScheme = /**
     * @param {?} type
     * @param {?} color
     * @param {?} bgColor
     * @return {?}
     */
    function (type, color, bgColor) {
        var /** @type {?} */ rtn = {};
        if (color.indexOf('#') > -1) {
            color = this.ConvertHexToRGB(color);
        }
        if (type === 'line' || type === 'radar') {
            rtn = {
                backgroundColor: 'rgba(' + color + ',0.2)',
                borderColor: 'rgba(' + color + ',1)',
                pointColor: 'rgba(' + color + ',1)',
                pointHoverBackgroundColor: bgColor,
                pointBorderColor: bgColor,
                pointHoverBorderColor: 'rgba(' + color + ',1)'
            };
        }
        else if (type === 'bar') {
            rtn = {
                backgroundColor: 'rgba(' + color + ',0.5)',
                borderColor: 'rgba(' + color + ',0.8)',
                borderWidth: 2,
                highlightFill: 'rgba(' + color + ',0.75)',
                highlightStroke: 'rgba(' + color + ',1)'
            };
        }
        else {
            rtn = {
                backgroundColor: 'rgba(' + color + ',1)',
                color: 'rgba(' + color + ',1)',
                highlight: 'rgba(' + color + ',0.7)'
            };
        }
        return rtn;
    };
    /**
     * @param {?} hex
     * @return {?}
     */
    PsChartComponent.prototype.ConvertHexToRGB = /**
     * @param {?} hex
     * @return {?}
     */
    function (hex) {
        var /** @type {?} */ rtn = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        var /** @type {?} */ res = '' + parseInt(rtn[1], 16) + ',' + parseInt(rtn[2], 16) + ',' + parseInt(rtn[3], 16);
        return res;
    };
    /**
     * @param {?} type
     * @param {?} idx
     * @param {?} bgColor
     * @return {?}
     */
    PsChartComponent.prototype.ChartColors = /**
     * @param {?} type
     * @param {?} idx
     * @param {?} bgColor
     * @return {?}
     */
    function (type, idx, bgColor) {
        var /** @type {?} */ colors = {
            line: [
                '220,220,220',
                '0,164,216',
                '27,70,94',
                '35,131,163'
            ],
            radar: [
                '220,220,220',
                '0,164,216',
                '27,70,94',
                '35,131,163'
            ],
            bar: [
                '220,220,220',
                '0,164,216',
                '27,70,94',
                '35,131,163'
            ],
            polarArea: [
                '0,164,216',
                '34,126,156',
                '0,70,92',
                '34,51,56',
                '25,93,115',
                '0,108,145',
                '0,194,255'
            ],
            pie: [
                '0,164,216',
                '34,126,156',
                '0,108,145',
                '0,70,92',
                '34,51,56',
                '25,93,115',
                '0,194,255'
            ],
            doughnut: [
                '0,164,216',
                '34,126,156',
                '0,70,92',
                '34,51,56',
                '25,93,115',
                '0,108,145',
                '0,194,255'
            ]
        };
        var /** @type {?} */ rtn = {};
        if (typeof colors[type][idx] === 'undefined') {
            idx = idx % colors[type].length;
        }
        rtn = this.ChartColorScheme(type, colors[type][idx], bgColor);
        return rtn;
    };
    PsChartComponent.decorators = [
        { type: Injectable },
        { type: Component, args: [{
                    selector: 'ps-chart',
                    template: "<div #pschart class=\"ps-chart\" style=\"display: block;\" [ngClass]=\"{'ps-chart-downloadPad': download}\">\n              <canvas *ngIf=\" type === 'pie' || type === 'doughnut' ||  type == 'polarArea' \"  #grafico baseChart\n                      [chartType]=\"type\"\n                      [data]=\"chartData\"\n                      [labels]=\"chartLabels\"\n                      [options]=\"psChartOptions\"\n                      [legend]=\"showLegend\"></canvas>\n              <canvas *ngIf=\" type !== 'pie' && type !== 'doughnut' && type !== 'polarArea' \"  #grafico baseChart\n                      [chartType]=\"type\"\n                      [datasets]=\"chartData\"\n                      [labels]=\"chartLabels\"\n                      [options]=\"psChartOptions\"\n                      [legend]=\"showLegend\"></canvas>\n              <a [hidden]=\"!download\" #base64Image href=\"\" class=\"ps-chart-download\" target=\"_blank\" title=\"Download\">\n                <ps-ico ps-size=\"md\" ps-ico=\"download\"></ps-ico>\n              </a>\n            </div>",
                    styles: [""],
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsChartComponent.ctorParameters = function () { return [
        { type: Renderer2, },
    ]; };
    PsChartComponent.propDecorators = {
        "type": [{ type: Input, args: ['charttype',] },],
        "source": [{ type: Input, args: ['chartsource',] },],
        "config": [{ type: Input, args: ['chartconfig',] },],
        "showLegend": [{ type: Input, args: ['chartlegend',] },],
        "height": [{ type: Input, args: ['chartheight',] },],
        "download": [{ type: Input, args: ['chartdownload',] },],
        "grafico": [{ type: ViewChild, args: [BaseChartDirective,] },],
        "pschart": [{ type: ViewChild, args: ['pschart',] },],
        "base64Image": [{ type: ViewChild, args: ['base64Image',] },],
    };
    return PsChartComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var PsChartModule = (function () {
    function PsChartModule() {
    }
    PsChartModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [
                        PsChartComponent
                    ],
                    imports: [
                        ChartsModule,
                        CommonModule,
                        PsIcoModule
                    ],
                    exports: [
                        PsChartComponent
                    ],
                },] },
    ];
    /** @nocollapse */
    PsChartModule.ctorParameters = function () { return []; };
    return PsChartModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-datagrid>`
 *
 * Componente datagrid (tabela dinâmica com paginação e filtros de busca embutidos).
 * Baseado no componente 'ngx-datatable': https://github.com/swimlane/ngx-datatable
 * Documentação: https://swimlane.gitbook.io/ngx-datatable
 */
var PsDatagridComponent = (function () {
    function PsDatagridComponent(http$$1) {
        this.http = http$$1;
        this.temp = [];
        this.loadingIndicator = false;
        this.page = {
            totalElements: 0,
            offset: 0,
            limit: 10
        };
        this.parameters = {
            offset: 1,
            sort: '',
            order: '',
            search: '',
            field: '',
            limit: 10
        };
        this.pagesize = 10;
        this.columns = [];
        this.filtering = false;
        this.rows = [];
        this.searchDelay = (function () {
            var /** @type {?} */ timer = 0;
            return function (callback, ms) {
                clearTimeout(timer);
                timer = setTimeout(callback, ms);
            };
        })();
    }
    /**
     * @return {?}
     */
    PsDatagridComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.parameters.limit = this.page.limit = this.pagesize;
        this.Math = Math;
        // this.loadData();
        this.temp = this.rows;
    };
    /**
     * @param {?} value
     * @param {?} field
     * @return {?}
     */
    PsDatagridComponent.prototype.updateFilter = /**
     * @param {?} value
     * @param {?} field
     * @return {?}
     */
    function (value, field) {
        var /** @type {?} */ val = (/** @type {?} */ (value)).toLowerCase();
        if (typeof this.temp !== 'undefined') {
            if (this.temp.length === 0 && this.rows.length > 0) {
                this.temp = this.rows;
            }
            // filter our data
            var /** @type {?} */ temp = this.temp.filter(function (d) {
                if (typeof d !== 'undefined') {
                    return (/** @type {?} */ (d[field])).toString().toLowerCase().indexOf(val) !== -1 || !val;
                }
            });
            // update the rows
            this.rows = temp;
        }
    };
    /**
     * @param {?} data
     * @return {?}
     */
    PsDatagridComponent.prototype.setPage = /**
     * @param {?} data
     * @return {?}
     */
    function (data) { };
    /**
     * @param {?} data
     * @return {?}
     */
    PsDatagridComponent.prototype.onSort = /**
     * @param {?} data
     * @return {?}
     */
    function (data) { };
    PsDatagridComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-datagrid',
                    template: "\n\t\t\t<ngx-datatable #table ngClass=\"bootstrap ps-table ps-datagrid\"\n\t\t\t[rows]=\"rows\"\n\t\t\t[loadingIndicator]=\"loadingIndicator\"\n\t\t\t[columns]=\"columns\"\n\t\t\t[headerHeight]=\"50\"\n\t\t\t[footerHeight]=\"50\"\n\t\t\t[columnMode]=\"'force'\"\n\t\t\t[rowHeight]=\"'auto'\"\n\t\t\t[messages]=\"{\n\t\t\t\t\t\temptyMessage: 'Nenhum resultado encontrado.'\n\t\t\t\t\t\t}\"\n\t\t\t[externalPaging]=\"false\"\n\t\t\t[count]=\"page.totalElements\"\n\t\t\t[offset]=\"page.offset\"\n\t\t\t[limit]=\"page.limit\"\n\t\t\t(page)=\"setPage($event)\"\n\t\t\t(sort)=\"onSort($event)\">\n\t\t\t<ngx-datatable-column *ngFor=\"let col  of columns\" name=\"{{col['name']}}\">\n\t\t\t\t<ng-template  let-column=\"column\" ngx-datatable-header-template let-sort=\"sortFn\" let-sortDir=\"sortDir\">\n\t\t\t\t<div ngClass=\"th\" *ngIf=\"col['sortable']\" class=\"ps-cursor-pointer\" data-type=\"text\" (click)=\"sort()\"  >\n\t\t\t\t\t{{col.label ? col.label : col.name}}\n\t\t\t\t\t<span class=\"ps-sort-btn sort-btn\"\n\t\t\t\t\t\t\t[class.sort-asc]=\"sortDir === 'asc'\"\n\t\t\t\t\t\t\t[class.datatable-icon-up]=\"sortDir === 'asc'\"\n\t\t\t\t\t\t\t[class.sort-desc]=\"sortDir === 'desc'\"\n\t\t\t\t\t\t\t[class.datatable-icon-down]=\"sortDir === 'desc'\"></span>\n\t\t\t\t</div>\n\t\t\t\t<div ngClass=\"th\" *ngIf=\"!col['sortable']\" class=\"ps-sm\" data-type=\"text\">\n\t\t\t\t\t{{col.label ? col.label : col.name}}\n\t\t\t\t\t<span class=\"ps-sort-btn sort-btn\"></span>\n\t\t\t\t</div>\n\t\t\t\t<div *ngIf=\"filtering\"  class=\"filter-row\" >\n\t\t\t\t\t<input *ngIf=\"col.filter !== false\" type=\"text\"\n\t\t\t\t\t\t\t#textInput (keyup)=\"updateFilter(textInput.value, col['prop'])\"\n\t\t\t\t\t\t\tclass=\"ps-frm-entry ps-frm-valid\" [placeholder]=\"'Filtrar '+ (col.label ? col.label : col.name)\" />\n\t\t\t\t</div>\n\t\t\t\t</ng-template>\n\t\t\t\t<ng-template let-row=\"row\" let-value=\"value\" ngx-datatable-cell-template >\n\t\t\t\t<ng-container *ngTemplateOutlet=\"col.template; context:{ $implicit: row }\"></ng-container>\n\t\t\t\t<div class=\"text\" *ngIf=\"!col.template\" >{{value}}</div>\n\t\t\t\t</ng-template>\n\t\t\t</ngx-datatable-column>\n\t\t\t<ngx-datatable-footer>\n\t\t\t<ng-template\n\t\t\t\tngx-datatable-footer-template\n\t\t\t\tlet-rowCount=\"rowCount\"\n\t\t\t\tlet-pageSize=\"pageSize\"\n\t\t\t\tlet-selectedCount=\"selectedCount\"\n\t\t\t\tlet-curPage=\"curPage\"\n\t\t\t\tlet-offset=\"offset\">\n\t\t\t\t<div style=\"padding: 5px 10px\">\n\t\t\t\t<div class=\"float-left\">\n\t\t\t\t\tTotal {{rowCount}} | P\u00E1gina {{curPage}} de {{ Math.round(rowCount / pageSize ) }}\n\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t\t<ps-loading *ngIf=\"loadingIndicator\"></ps-loading>\n\t\t\t\t<datatable-pager\n\t\t\t\t[pagerLeftArrowIcon]=\"'datatable-icon-left'\"\n\t\t\t\t[pagerRightArrowIcon]=\"'datatable-icon-right'\"\n\t\t\t\t[pagerPreviousIcon]=\"'datatable-icon-prev'\"\n\t\t\t\t[pagerNextIcon]=\"'datatable-icon-skip'\"\n\t\t\t\t[page]=\"curPage\"\n\t\t\t\t[size]=\"pageSize\"\n\t\t\t\t[count]=\"rowCount\"\n\t\t\t\t[hidden]=\"!((rowCount / pageSize) > 1)\"\n\t\t\t\t(change)=\"table.onFooterPage($event)\">\n\t\t\t\t</datatable-pager>\n\t\t\t</ng-template>\n\t\t\t</ngx-datatable-footer>\n\t\t</ngx-datatable>",
                    styles: ["\n\t\t@charset \"UTF-8\";\n\t\tps-datagrid {\n\t\t\t/*\n\t\t\tbootstrap table theme\n\t\t\t*/\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap {\n\t\t\tbox-shadow: none;\n\t\t\tfont-size: 13px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-header {\n\t\t\theight: unset !important;\n\t\t\tborder-top: 1px solid #D2D2D2;\n\t\t\tborder-right: 1px solid #D2D2D2;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell {\n\t\t\tvertical-align: bottom;\n\t\t\tpadding: 0;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap {\n\t\t\tborder-left: 1px solid #D2D2D2;\n\t\t\tpadding-right: 1px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .th {\n\t\t\tbackground: #D2D2D2;\n\t\t\tcolor: #1c1c1c;\n\t\t\tpadding: 22px 20px;\n\t\t\ttext-align: center;\n\t\t\ttext-transform: uppercase;\n\t\t\tletter-spacing: 1px;\n\t\t\tline-height: 14px;\n\t\t\tfont-weight: 600;\n\t\t\tfont-size: 11px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .filter-row {\n\t\t\tpadding: 11px 11px !important;\n\t\t\tbackground: #f1f1f1;\n\t\t\tmin-height: 63px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .ps-cursor-pointer {\n\t\t\tcursor: pointer;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .sort-btn {\n\t\t\tfont-size: 15px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row {\n\t\t\tbackground: #f1f1f1;\n\t\t\tfont-size: 11px;\n\t\t\tcolor: #1c1c1c;\n\t\t\tletter-spacing: 1px;\n\t\t\tline-height: 14px;\n\t\t\ttext-align: center;\n\t\t\tborder-top: 1px solid #D2D2D2;\n\t\t\tborder-right: 1px solid #D2D2D2;\n\t\t\ttext-transform: uppercase;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row.datatable-row-even,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row.datatable-row-even {\n\t\t\tbackground: #fff;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row.active,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row.active {\n\t\t\tbackground-color: #1483ff;\n\t\t\tcolor: #FFF;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row .datatable-body-cell,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row .datatable-body-cell {\n\t\t\tvertical-align: top;\n\t\t\tborder-left: 1px solid #D2D2D2;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row div.text,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row div.text {\n\t\t\ttext-align: center;\n\t\t\tpadding: 22px 20px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row {\n\t\t\tborder-left: 1px solid #D2D2D2;\n\t\t\tbackground: #fff;\n\t\t\tpadding: 22px 20px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer {\n\t\t\tbackground: #D2D2D2;\n\t\t\tcolor: #000;\n\t\t\tmargin-top: -4px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-footer-inner > div {\n\t\t\tpadding: 0 !important;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-footer-inner .float-left,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .page-count {\n\t\t\tline-height: 41px;\n\t\t\tfont-size: 11px;\n\t\t\tpadding: 0 1.2rem 0 24px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager {\n\t\t\tmargin: 0 10px;\n\t\t\tvertical-align: top;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li {\n\t\t\tmargin: 0px;\n\t\t\tpadding: 2px 0;\n\t\t\tfont-size: 18px;\n\t\t\tfont-size: 11px;\n\t\t\tfont-weight: 600;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li a {\n\t\t\tdisplay: inline-block;\n\t\t\tbox-sizing: border-box;\n\t\t\twidth: 37px;\n\t\t\ttext-align: center;\n\t\t\tline-height: 37px;\n\t\t\tborder-radius: 3px;\n\t\t\tmargin: 0 2px;\n\t\t\ttext-decoration: none;\n\t\t\tcolor: #1c1c1c;\n\t\t\ttransition: all ease 0.3s;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap\n\t\t.datatable-footer .datatable-pager\n\t\tul li:not(.disabled):hover a,\n\t\tps-datagrid .ngx-datatable.bootstrap\n\t\t.datatable-footer\n\t\t.datatable-pager ul li:not(.disabled).active a {\n\t\t\tbackground: #fff;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li:not(.disabled).active a {\n\t\t\tcolor: #33BFFF !important;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-left,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev {\n\t\t\tfont-size: 12px;\n\t\t\tvertical-align: middle;\n\t\t\tletter-spacing: -5px;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap\n\t\t.datatable-footer .datatable-pager\n\t\tul li .datatable-icon-left:before,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-left:after,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip:before,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip:after,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right:before,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right:after,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev:before,\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev:after {\n\t\t\tfont-family: ps_glyph_icons !important;\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev:before {\n\t\t\tcontent: \"\\e961\\e961\";\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-left:before {\n\t\t\tcontent: \"\\e961\";\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip:before {\n\t\t\tcontent: \"\\e962\\e962\";\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right:before {\n\t\t\tcontent: \"\\e962\";\n\t\t}\n\t\tps-datagrid .ngx-datatable.bootstrap .datatable-summary-row .datatable-body-row .datatable-body-cell {\n\t\t\tfont-weight: bold;\n\t\t}\n\t\tps-datagrid .ngx-datatable.fixed-header .datatable-header .datatable-header-inner .datatable-header-cell {\n\t\t\tbackground: #F1F1F1;\n\t\t}\n\t\tps-datagrid .ngx-datatable .sort-btn {\n\t\t\tdisplay: none !important;\n\t\t}\n\t\tps-datagrid .ngx-datatable .ps-sort-btn.sort-btn {\n\t\t\tdisplay: inline !important;\n\t\t}\n\t\tps-datagrid .ngx-datatable .disabled {\n\t\t\tdisplay: none !important;\n\t\t}\n\t"],
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsDatagridComponent.ctorParameters = function () { return [
        { type: Http, },
    ]; };
    PsDatagridComponent.propDecorators = {
        "pagesize": [{ type: Input, args: ['pagesize',] },],
        "columns": [{ type: Input, args: ['columns',] },],
        "filtering": [{ type: Input, args: ['filtering',] },],
        "rows": [{ type: Input, args: ['source',] },],
    };
    return PsDatagridComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-loading>`
 *
 * Componente Loading (Carregamento).
 */
var PsLoadingComponent = (function () {
    function PsLoadingComponent() {
    }
    /**
     * @return {?}
     */
    PsLoadingComponent.prototype.ngOnChanges = /**
     * @return {?}
     */
    function () {
        if (this._size) {
            this._size = 'ps-ico-' + this._size;
        }
        if (this._color) {
            this._color = 'ps-ico-loading-' + this._color;
        }
    };
    PsLoadingComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-loading',
                    template: "<span class=\"ps-ico-loading {{_color}} {{_size}}\"></span>"
                },] },
    ];
    /** @nocollapse */
    PsLoadingComponent.ctorParameters = function () { return []; };
    PsLoadingComponent.propDecorators = {
        "_color": [{ type: Input, args: ['ps-color',] },],
        "_size": [{ type: Input, args: ['ps-size',] },],
    };
    return PsLoadingComponent;
}());
/**
 * `<ps-loading-bar>`
 *
 * Componente Loading Bar (Horizontal).
 */
var PsLoadingBarComponent = (function () {
    function PsLoadingBarComponent() {
    }
    /**
     * @return {?}
     */
    PsLoadingBarComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ leftFather = this._psLoadingBarContainer.nativeElement.getBoundingClientRect().width;
        var /** @type {?} */ leftSpinner = this._psBarSpinner.nativeElement.getBoundingClientRect().width;
        this.animate(this._psBarSpinner.nativeElement, 'left', -leftSpinner, leftFather, 700);
    };
    /**
     * @param {?} object
     * @param {?} property
     * @param {?} start_value
     * @param {?} end_value
     * @param {?} time
     * @return {?}
     */
    PsLoadingBarComponent.prototype.animate = /**
     * @param {?} object
     * @param {?} property
     * @param {?} start_value
     * @param {?} end_value
     * @param {?} time
     * @return {?}
     */
    function (object, property, start_value, end_value, time) {
        var /** @type {?} */ self = this;
        var /** @type {?} */ frame_rate = 0.05; // 50 FPS
        var /** @type {?} */ frame = 0;
        var /** @type {?} */ delta = (end_value - start_value) / time / frame_rate;
        var /** @type {?} */ handle = setInterval(function () {
            frame++;
            var /** @type {?} */ value = start_value + delta * frame;
            object.style[property] = value + 'px';
            if (value === end_value) {
                clearInterval(handle);
                self.animate(object, property, start_value, end_value, time);
            }
        }, 1 / frame_rate);
    };
    PsLoadingBarComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-loading-bar',
                    template: "<span [ngClass]=\"{'ps-ico-loading-bar-white': _color}\" class=\"ps-ico-loading-bar\">\n                <div #psLoadingBarContainer class=\"ps-ico-bar-container\">\n                  <div #psBarSpinner class=\"ps-ico-bar-spinner\"></div>\n                </div>\n            </span>"
                },] },
    ];
    /** @nocollapse */
    PsLoadingBarComponent.ctorParameters = function () { return []; };
    PsLoadingBarComponent.propDecorators = {
        "_color": [{ type: Input, args: ['ps-color',] },],
        "_psLoadingBarContainer": [{ type: ViewChild, args: ['psLoadingBarContainer',] },],
        "_psBarSpinner": [{ type: ViewChild, args: ['psBarSpinner',] },],
    };
    return PsLoadingBarComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsLoadingModule = (function () {
    function PsLoadingModule() {
    }
    PsLoadingModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsLoadingComponent,
                        PsLoadingBarComponent
                    ],
                    declarations: [
                        PsLoadingComponent,
                        PsLoadingBarComponent
                    ],
                },] },
    ];
    /** @nocollapse */
    PsLoadingModule.ctorParameters = function () { return []; };
    return PsLoadingModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsDatagridModule = (function () {
    function PsDatagridModule() {
    }
    PsDatagridModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        NgxDatatableModule,
                        PsLoadingModule
                    ],
                    exports: [
                        PsDatagridComponent
                    ],
                    declarations: [
                        PsDatagridComponent
                    ]
                },] },
    ];
    /** @nocollapse */
    PsDatagridModule.ctorParameters = function () { return []; };
    return PsDatagridModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva de atributo que configura uma Lista de campos adicionando a respectiva classe css.
 */
var PsDataviewDirective = (function () {
    function PsDataviewDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-dataview');
    }
    PsDataviewDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-dataview]'
                },] },
    ];
    /** @nocollapse */
    PsDataviewDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsDataviewDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsDataviewModule = (function () {
    function PsDataviewModule() {
    }
    PsDataviewModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsDataviewDirective
                    ],
                    declarations: [
                        PsDataviewDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsDataviewModule.ctorParameters = function () { return []; };
    return PsDataviewModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva que configura um grid (grade).
 */
var PsGridDirective = (function () {
    function PsGridDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-container');
    }
    PsGridDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'div[ps-grid], div[ps-container]'
                },] },
    ];
    /** @nocollapse */
    PsGridDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsGridDirective;
}());
/**
 * Diretiva que configura um grid fluída (grade).
 */
var PsGridFluidDirective = (function () {
    function PsGridFluidDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-container-fluid');
    }
    PsGridFluidDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'div[ps-container-fluid]'
                },] },
    ];
    /** @nocollapse */
    PsGridFluidDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsGridFluidDirective;
}());
/**
 * Diretiva de atributo que configura uma linha (row) no grid.
 */
var PsGridRowDirective = (function () {
    function PsGridRowDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-row');
    }
    PsGridRowDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-row]'
                },] },
    ];
    /** @nocollapse */
    PsGridRowDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsGridRowDirective;
}());
/**
 * Mapeamento dos atributos do grid para as classes css do guide.
 */
var PS_COLUMN_ATTRIBUTES = [
    { prop: 'ps-mobile-hide', css: 'ps-hide' },
    { prop: 'ps-tablet-hide', css: 'ps-sm-hide' },
    { prop: 'ps-desktop-sm-hide', css: 'ps-md-hide' },
    { prop: 'ps-desktop-lg-hide', css: 'ps-lg-hide' },
    { prop: 'ps-mobile-show', css: 'ps-show' },
    { prop: 'ps-tablet-show', css: 'ps-sm-show' },
    { prop: 'ps-desktop-sm-show', css: 'ps-md-show' },
    { prop: 'ps-desktop-lg-show', css: 'ps-lg-show' },
    { prop: 'ps-mobile-only', css: 'ps-only' },
    { prop: 'ps-tablet-only', css: 'ps-sm-only' },
    { prop: 'ps-desktop-sm-only', css: 'ps-md-only' },
    { prop: 'ps-desktop-lg-only', css: 'ps-lg-only' },
    { prop: 'ps-mobile-noGutter', css: 'ps-noGutter' },
    { prop: 'ps-tablet-noGutter', css: 'ps-sm-noGutter' },
    { prop: 'ps-desktop-sm-noGutter', css: 'ps-md-noGutter' },
    { prop: 'ps-desktop-lg-noGutter', css: 'ps-lg-noGutter' },
    { prop: 'ps-mobile-noGutter-left', css: 'ps-noGutter-left' },
    { prop: 'ps-tablet-noGutter-left', css: 'ps-sm-noGutter-left' },
    { prop: 'ps-desktop-sm-noGutter-left', css: 'ps-md-noGutter-left' },
    { prop: 'ps-desktop-lg-noGutter-left', css: 'ps-lg-noGutter-left' },
    { prop: 'ps-mobile-noGutter-right', css: 'ps-noGutter-right' },
    { prop: 'ps-tablet-noGutter-right', css: 'ps-sm-noGutter-right' },
    { prop: 'ps-desktop-sm-noGutter-right', css: 'ps-md-noGutter-right' },
    { prop: 'ps-desktop-lg-noGutter-right', css: 'ps-lg-noGutter-right' }
];
/**
 * Diretiva que configura uma coluna (column) no grid.
 */
var PsGridColumnDirective = (function () {
    function PsGridColumnDirective(_renderer, _elementRef, _platform) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
        this._platform = _platform;
        for (var _i = 0, PS_COLUMN_ATTRIBUTES_1 = PS_COLUMN_ATTRIBUTES; _i < PS_COLUMN_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_COLUMN_ATTRIBUTES_1[_i];
            if (this._hasHostAttributes(attribute.prop)) {
                this._renderer.addClass(this._getHostElement(), attribute.css);
            }
        }
    }
    /**
     * @return {?}
     */
    PsGridColumnDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this._addCssByProperty(this._ps_mod, 'ps-mod');
        this._addCssByProperty(this._ps_sm_mod, 'ps-sm-mod');
        this._addCssByProperty(this._ps_md_mod, 'ps-md-mod');
        this._addCssByProperty(this._ps_lg_mod, 'ps-lg-mod');
        this._addCssByProperty(this._ps_lspan, 'ps-lspan');
        this._addCssByProperty(this._ps_sm_lspan, 'ps-sm-lspan');
        this._addCssByProperty(this._ps_md_lspan, 'ps-md-lspan');
        this._addCssByProperty(this._ps_lg_lspan, 'ps-lg-lspan');
        this._addCssByProperty(this._ps_align, 'ps-align');
        this._addCssByProperty(this._ps_sm_align, 'ps-sm-align');
        this._addCssByProperty(this._ps_md_align, 'ps-md-align');
        this._addCssByProperty(this._ps_lg_align, 'ps-lg-align');
    };
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    PsGridColumnDirective.prototype._getHostElement = /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsGridColumnDirective.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        if (!this._platform.isBrowser) {
            return false;
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    /**
     * Método que adiciona uma propriedade css na de notificação.
     * @param {?} property Propriedade css.
     * @param {?} css Valor da propriedade.
     * @return {?}
     */
    PsGridColumnDirective.prototype._addCssByProperty = /**
     * Método que adiciona uma propriedade css na de notificação.
     * @param {?} property Propriedade css.
     * @param {?} css Valor da propriedade.
     * @return {?}
     */
    function (property, css) {
        if (property) {
            this._renderer.addClass(this._getHostElement(), (css + property));
        }
    };
    PsGridColumnDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-column]'
                },] },
    ];
    /** @nocollapse */
    PsGridColumnDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
    ]; };
    PsGridColumnDirective.propDecorators = {
        "_ps_mod": [{ type: Input, args: ['ps-mobile',] },],
        "_ps_sm_mod": [{ type: Input, args: ['ps-tablet',] },],
        "_ps_md_mod": [{ type: Input, args: ['ps-desktop-sm',] },],
        "_ps_lg_mod": [{ type: Input, args: ['ps-desktop-lg',] },],
        "_ps_lspan": [{ type: Input, args: ['ps-mobile-lspan',] },],
        "_ps_sm_lspan": [{ type: Input, args: ['ps-tablet-lspan',] },],
        "_ps_md_lspan": [{ type: Input, args: ['ps-desktop-sm-lspan',] },],
        "_ps_lg_lspan": [{ type: Input, args: ['ps-desktop-lg-lspan',] },],
        "_ps_align": [{ type: Input, args: ['ps-align',] },],
        "_ps_sm_align": [{ type: Input, args: ['ps-sm-align',] },],
        "_ps_md_align": [{ type: Input, args: ['ps-md-align',] },],
        "_ps_lg_align": [{ type: Input, args: ['ps-lg-align',] },],
    };
    return PsGridColumnDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsGridModule = (function () {
    function PsGridModule() {
    }
    PsGridModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsGridDirective,
                        PsGridFluidDirective,
                        PsGridRowDirective,
                        PsGridColumnDirective
                    ],
                    declarations: [
                        PsGridDirective,
                        PsGridFluidDirective,
                        PsGridRowDirective,
                        PsGridColumnDirective
                    ],
                    providers: [
                        Platform
                    ]
                },] },
    ];
    /** @nocollapse */
    PsGridModule.ctorParameters = function () { return []; };
    return PsGridModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva que define uma lista.
 */
var PsListDirective = (function () {
    function PsListDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-list');
    }
    PsListDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-list]'
                },] },
    ];
    /** @nocollapse */
    PsListDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsListDirective;
}());
/**
 * Diretiva que define uma lista de grupo.
 */
var PsListGrpDirective = (function () {
    function PsListGrpDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-list-grp');
    }
    PsListGrpDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-list-grp]'
                },] },
    ];
    /** @nocollapse */
    PsListGrpDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsListGrpDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsListModule = (function () {
    function PsListModule() {
    }
    PsListModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsListDirective,
                        PsListGrpDirective
                    ],
                    declarations: [
                        PsListDirective,
                        PsListGrpDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsListModule.ctorParameters = function () { return []; };
    return PsListModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Classes CSS do menu
 */
var PS_MENU_CSS = {
    psMenu: 'ps-menu',
    psMenuHorizontal: 'ps-menu-horizontal',
    psMenuVertical: 'ps-menu-vertical',
    psMenuMobile: 'ps-menu-mobile',
    psMenuMobileToggle: 'ps-menu-mobile-toggle',
    psMenuMobileToggleNoText: 'ps-menu-mobile-toggle-noText',
    psMenuOpened: 'ps-menu-opened',
    psSubMenuOpened: 'ps-submenu-opened',
    psMenuHasLevel: 'ps-menu-hasLevel',
    psMenuAllCaps: 'ps-menu-allCaps'
};
/**
 * Diretiva de atributo para transformar uma lista ul em um menu.
 */
var PsMenuDirective = (function () {
    function PsMenuDirective(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        this._platform.setScreen();
    }
    /**
     * Método hook do angular - configura o menu e submenus adicionando classes css
     * e o ícone que identifica um submenu.
     */
    /**
     * Método hook do angular - configura o menu e submenus adicionando classes css
     * e o ícone que identifica um submenu.
     * @return {?}
     */
    PsMenuDirective.prototype.ngOnInit = /**
     * Método hook do angular - configura o menu e submenus adicionando classes css
     * e o ícone que identifica um submenu.
     * @return {?}
     */
    function () {
        var /** @type {?} */ psMenuElement = this._getHostElement();
        this._renderer2.addClass(psMenuElement, PS_MENU_CSS.psMenu);
        this._addClassIfHasAttribute(PS_MENU_CSS.psMenuHorizontal);
        this._addClassIfHasAttribute(PS_MENU_CSS.psMenuVertical);
        this._addClassIfHasAttribute(PS_MENU_CSS.psMenuAllCaps);
        if (this._platform.IsMobile && psMenuElement.hasAttribute(PS_MENU_CSS.psMenuMobile)) {
            var /** @type {?} */ mobilewithouttext = psMenuElement.getAttribute('mobilewithouttext');
            var /** @type {?} */ notText = (typeof mobilewithouttext === 'undefined') ? false : mobilewithouttext;
            var /** @type {?} */ toggleElem = this._renderer2.createElement('a');
            toggleElem.setAttribute('href', 'javascript:;');
            toggleElem.innerHTML = '<span class="ps-ico ps-ico-sm ps-ico-menu"></span>';
            this._renderer2.addClass(toggleElem, PS_MENU_CSS.psMenuMobileToggle);
            if (notText) {
                this._renderer2.addClass(toggleElem, PS_MENU_CSS.psMenuMobileToggleNoText);
            }
            this._renderer2.insertBefore(psMenuElement, toggleElem, psMenuElement.firstChild);
            var /** @type {?} */ psMenuMobileToggle = psMenuElement.getElementsByClassName(PS_MENU_CSS.psMenuMobileToggle).item(0);
            this._addMenuMobileToggleClickEventListener(psMenuMobileToggle);
        }
        var /** @type {?} */ menuItens = psMenuElement.querySelectorAll('li');
        var /** @type {?} */ isNotVerticalOrHorizontal = (!this._platform.IsMobile && !psMenuElement.classList.contains(PS_MENU_CSS.psMenuVertical) && !psMenuElement.classList.contains(PS_MENU_CSS.psMenuHorizontal)) || (this._platform.IsMobile);
        if (isNotVerticalOrHorizontal) {
            this._addSubmenuItemCSSAndEventListener(menuItens);
        }
    };
    /**
     * Método para configurar eventos e adicionar classes no submenu.
     * @param {?} menuItens Coleção de elementos submenus.
     * @return {?}
     */
    PsMenuDirective.prototype._addSubmenuItemCSSAndEventListener = /**
     * Método para configurar eventos e adicionar classes no submenu.
     * @param {?} menuItens Coleção de elementos submenus.
     * @return {?}
     */
    function (menuItens) {
        if (menuItens.length > 0) {
            var /** @type {?} */ psMenuDirectiveObj_1 = this;
            menuItens.forEach(function (menuItem) {
                var /** @type {?} */ submenuItens = menuItem.querySelectorAll('ul > li > a');
                var /** @type {?} */ submenuItem = (submenuItens.length > 1) ? submenuItens.item(0) : false;
                if (submenuItem) {
                    psMenuDirectiveObj_1._renderer2.addClass(submenuItem, PS_MENU_CSS.psMenuHasLevel);
                    submenuItem.addEventListener('click', function () { psMenuDirectiveObj_1._openCloseSubmenu(submenuItem, event); }, false);
                }
            });
        }
    };
    /**
     * Método que adiciona evento de click no menu e gerencia a funcionalidade de toggle
     * adicionando e removendo classes e mudando a propriedade style do elemento.
     * @param {?} psMenuMobileToggle Referência do elemento de menu.
     * @return {?}
     */
    PsMenuDirective.prototype._addMenuMobileToggleClickEventListener = /**
     * Método que adiciona evento de click no menu e gerencia a funcionalidade de toggle
     * adicionando e removendo classes e mudando a propriedade style do elemento.
     * @param {?} psMenuMobileToggle Referência do elemento de menu.
     * @return {?}
     */
    function (psMenuMobileToggle) {
        var _this = this;
        psMenuMobileToggle.addEventListener('click', function (event) {
            event.preventDefault();
            var /** @type {?} */ menu = /** @type {?} */ (psMenuMobileToggle.nextElementSibling);
            var /** @type {?} */ visible = _this._isVisible(menu);
            visible ? _this._renderer2.removeClass(psMenuMobileToggle, PS_MENU_CSS.psMenuOpened) : _this._renderer2.addClass(psMenuMobileToggle, PS_MENU_CSS.psMenuOpened);
            visible ? _this._renderer2.setStyle(menu, 'display', 'none') : _this._renderer2.setStyle(menu, 'display', 'block');
        }, false);
    };
    /**
     * Método que abre e fecha os submenus adicionando e removendo classes css e alterando
     * o atributo style.
     * @param {?} elem Referência ao elemento submenu.
     * @param {?} event Evento do listener.
     * @return {?}
     */
    PsMenuDirective.prototype._openCloseSubmenu = /**
     * Método que abre e fecha os submenus adicionando e removendo classes css e alterando
     * o atributo style.
     * @param {?} elem Referência ao elemento submenu.
     * @param {?} event Evento do listener.
     * @return {?}
     */
    function (elem, event) {
        event.preventDefault();
        if (elem.classList) {
            var /** @type {?} */ hide = elem.classList.contains(PS_MENU_CSS.psMenuOpened);
            var /** @type {?} */ nextElementSibling = /** @type {?} */ (elem.nextElementSibling);
            hide ? this._renderer2.removeClass(elem, PS_MENU_CSS.psMenuOpened) : this._renderer2.addClass(elem, PS_MENU_CSS.psMenuOpened);
            hide ? this._renderer2.setStyle(nextElementSibling, 'display', 'none') : this._renderer2.setStyle(nextElementSibling, 'display', 'block');
            hide ? this._renderer2.removeClass(nextElementSibling, PS_MENU_CSS.psSubMenuOpened) : this._renderer2.addClass(nextElementSibling, PS_MENU_CSS.psSubMenuOpened);
        }
    };
    /**
     * Método que testa se um elemento está visível no portview.
     * @param {?} elem Referência HTMLElement do elemento que deve ser testado.
     * @return {?} boolean Verdadeiro se o elemento estiver visível, Falso caso contrário.
     */
    PsMenuDirective.prototype._isVisible = /**
     * Método que testa se um elemento está visível no portview.
     * @param {?} elem Referência HTMLElement do elemento que deve ser testado.
     * @return {?} boolean Verdadeiro se o elemento estiver visível, Falso caso contrário.
     */
    function (elem) {
        return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
    };
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    PsMenuDirective.prototype._getHostElement = /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Método que adiciona uma classe css ao host element se ela estiver definida
     * como atributo no mesmo.
     * @param {?} css Classe css.
     * @return {?}
     */
    PsMenuDirective.prototype._addClassIfHasAttribute = /**
     * Método que adiciona uma classe css ao host element se ela estiver definida
     * como atributo no mesmo.
     * @param {?} css Classe css.
     * @return {?}
     */
    function (css) {
        if (this._getHostElement().hasAttribute(css)) {
            this._renderer2.addClass(this._getHostElement(), css);
        }
    };
    PsMenuDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-menu], [ps-menu-horizontal], [ps-menu-vertical], [ps-menu-mobile]',
                    providers: [Platform]
                },] },
    ];
    /** @nocollapse */
    PsMenuDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: Platform, },
    ]; };
    return PsMenuDirective;
}());
/**
 * Diretiva para uma lista de ícones.
 */
var PsListIcoDirective = (function () {
    function PsListIcoDirective(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /**
     * @return {?}
     */
    PsListIcoDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this._renderer2.addClass(this._elementRef.nativeElement, 'ps-list-ico');
    };
    PsListIcoDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-list-ico]'
                },] },
    ];
    /** @nocollapse */
    PsListIcoDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsListIcoDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsMenuModule = (function () {
    function PsMenuModule() {
    }
    PsMenuModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsMenuDirective,
                        PsListIcoDirective
                    ],
                    declarations: [
                        PsMenuDirective,
                        PsListIcoDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsMenuModule.ctorParameters = function () { return []; };
    return PsMenuModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var nextNofityId = 0;
/**
 * Tipos de notificação.
 */
var PS_NOTIFY_SELECTORS = [
    { name: 'ps-notify-success' },
    { name: 'ps-notify-error' },
    { name: 'ps-notify-alert' }
];
/**
 * `<ps-notify-success>`, `<ps-notify-error>`, `<ps-notify-alert>`
 *
 * Componente de mensagens (notificações).
 */
var PsNotifyComponent = (function () {
    function PsNotifyComponent(_renderer2, _elementRef, psNotifyConfig) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this.psNotifyConfig = psNotifyConfig;
        /**
         * Id único do componente.
         */
        this._notifyId = "Notify" + nextNofityId++;
    }
    /**
     * @return {?}
     */
    PsNotifyComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        if (typeof this.psNotifyConfig !== 'undefined') {
            this._notifyCSS = this.psNotifyConfig.notifyType;
            this._duration = this.psNotifyConfig.duration;
            this._show = this.psNotifyConfig.show;
        }
        else {
            for (var _i = 0, PS_NOTIFY_SELECTORS_1 = PS_NOTIFY_SELECTORS; _i < PS_NOTIFY_SELECTORS_1.length; _i++) {
                var selector = PS_NOTIFY_SELECTORS_1[_i];
                if (this._hasHostTagName(selector.name)) {
                    this._notifyCSS = selector.name;
                }
            }
        }
    };
    /**
     * @return {?}
     */
    PsNotifyComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        if (typeof this._show !== 'undefined' && this._show) {
            this.open();
        }
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    PsNotifyComponent.prototype.onkeyup = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (ev.key === 'Escape') {
            this.close();
        }
    };
    /** Método que mostra a notificação. Geralmente, deve ser chamado de algum callback de eventos.  */
    /**
     * Método que mostra a notificação. Geralmente, deve ser chamado de algum callback de eventos.
     * @return {?}
     */
    PsNotifyComponent.prototype.open = /**
     * Método que mostra a notificação. Geralmente, deve ser chamado de algum callback de eventos.
     * @return {?}
     */
    function () {
        this._translateY('100%');
        this._setTimeout();
    };
    /** Método que esconde a notificação. Geralmente, deve ser chamado de algum callback de eventos.  */
    /**
     * Método que esconde a notificação. Geralmente, deve ser chamado de algum callback de eventos.
     * @return {?}
     */
    PsNotifyComponent.prototype.close = /**
     * Método que esconde a notificação. Geralmente, deve ser chamado de algum callback de eventos.
     * @return {?}
     */
    function () {
        this._translateY('-10%');
    };
    /**
     * Método que movimenta a notificação no eixo Y.
     * @param {?} size
     * @return {?}
     */
    PsNotifyComponent.prototype._translateY = /**
     * Método que movimenta a notificação no eixo Y.
     * @param {?} size
     * @return {?}
     */
    function (size) {
        var /** @type {?} */ psNotifyElem = this._getPsNotifyElem();
        this._renderer2.setStyle(psNotifyElem, 'transform', 'translateY(' + size + ')');
    };
    /**
     * Espera um intervalo de tempo antes de esconder a notificação.
     * @return {?}
     */
    PsNotifyComponent.prototype._setTimeout = /**
     * Espera um intervalo de tempo antes de esconder a notificação.
     * @return {?}
     */
    function () {
        var _this = this;
        this._duration = (typeof this._duration !== 'undefined') ? this._duration : 5000;
        setTimeout(function () {
            _this.close();
        }, this._duration);
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsNotifyComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Método que adiciona uma propriedade css na de notificação.
     * @param {?} property Propriedade css.
     * @param {?} css Valor da propriedade.
     * @return {?}
     */
    PsNotifyComponent.prototype._addCssByProperty = /**
     * Método que adiciona uma propriedade css na de notificação.
     * @param {?} property Propriedade css.
     * @param {?} css Valor da propriedade.
     * @return {?}
     */
    function (property, css) {
        if (property) {
            (/** @type {?} */ (this._getHostElement())).classList.add(css + property);
        }
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsNotifyComponent.prototype._hasHostTagName = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return (_this._getHostElement().tagName.toLowerCase() === attribute); });
    };
    /**
     * Método que retorna o elemento de notificação pelo seu atributo ID.
     * @return {?}
     */
    PsNotifyComponent.prototype._getPsNotifyElem = /**
     * Método que retorna o elemento de notificação pelo seu atributo ID.
     * @return {?}
     */
    function () {
        var /** @type {?} */ psNotifyElem = document.getElementById(this._notifyId);
        if (typeof psNotifyElem === 'undefined' || psNotifyElem === null) {
            psNotifyElem = this._psNotifyContainer.nativeElement;
        }
        return psNotifyElem;
    };
    PsNotifyComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-notify-success, ps-notify-error, ps-notify-alert',
                    template: "<div class=\"ps-notify ps-caption ps-caption-uppercased {{_notifyCSS}}\"\n                  id=\"{{_notifyId}}\" #psNotifyContainer>\n                <span class=\"ps-ico ps-ico-sm ps-ico-alert\"></span>\n                <ng-content></ng-content>\n                <a href=\"javascript:;\" (click)=\"close()\" class=\"ps-notify-close ps-notify-close-default\">\n                  <span class=\"ps-ico ps-ico-xsm ps-ico-close\"></span>\n                </a>\n            </div>",
                    styles: ["\n            .ps-notify {\n              transition: all 500ms ease-in-out;\n            }\n    "]
                },] },
    ];
    /** @nocollapse */
    PsNotifyComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: undefined, decorators: [{ type: Inject, args: ['psNotifyConfig',] },] },
    ]; };
    PsNotifyComponent.propDecorators = {
        "_duration": [{ type: Input, args: ['duration',] },],
        "_show": [{ type: Input, args: ['show',] },],
        "_psNotifyContainer": [{ type: ViewChild, args: ['psNotifyContainer',] },],
        "onkeyup": [{ type: HostListener, args: ['document:keyup', ['$event'],] },],
    };
    return PsNotifyComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Service para criar um componente de notificação dinamicamente.
 */
var PsNotifyService = (function () {
    function PsNotifyService(_rendererFactory, _injector, _resolver) {
        this._rendererFactory = _rendererFactory;
        this._injector = _injector;
        this._resolver = _resolver;
        this._renderer2 = _rendererFactory.createRenderer(null, null);
    }
    /**
     * Método que cria e mostra uma notificação.
     * @param msg Texto de conteúdo da notificação.
     * @param type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param viewContainerRef Container passado do componente que utiliza o service.
     * @param duration Tempo que a notificação deverá ficar visível.
     */
    /**
     * Método que cria e mostra uma notificação.
     * @param {?} msg Texto de conteúdo da notificação.
     * @param {?} type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param {?} viewContainerRef Container passado do componente que utiliza o service.
     * @param {?=} duration Tempo que a notificação deverá ficar visível.
     * @return {?}
     */
    PsNotifyService.prototype.showNotify = /**
     * Método que cria e mostra uma notificação.
     * @param {?} msg Texto de conteúdo da notificação.
     * @param {?} type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param {?} viewContainerRef Container passado do componente que utiliza o service.
     * @param {?=} duration Tempo que a notificação deverá ficar visível.
     * @return {?}
     */
    function (msg, type, viewContainerRef, duration) {
        var /** @type {?} */ componentRef = this.createNotify(msg, type, viewContainerRef, false, duration);
        setTimeout(function () {
            (/** @type {?} */ (componentRef.instance)).open();
        }, 300);
    };
    /**
     * Método utilitário que cria uma notificação dinamicamente (também é usado em diretiva).
     * @param msg Texto de conteúdo da notificação.
     * @param type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param viewContainerRef Container passado do componente que utiliza o service.
     * @param duration Tempo que a notificação deverá ficar visível.
     * @param show Flag indicando se ela deverá aparecer ou não.
     * @returns Referência do PsNotifyComponent criado dinamicamente.
     */
    /**
     * Método utilitário que cria uma notificação dinamicamente (também é usado em diretiva).
     * @param {?} msn
     * @param {?} type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param {?} viewContainerRef Container passado do componente que utiliza o service.
     * @param {?=} show Flag indicando se ela deverá aparecer ou não.
     * @param {?=} duration Tempo que a notificação deverá ficar visível.
     * @return {?} Referência do PsNotifyComponent criado dinamicamente.
     */
    PsNotifyService.prototype.createNotify = /**
     * Método utilitário que cria uma notificação dinamicamente (também é usado em diretiva).
     * @param {?} msn
     * @param {?} type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param {?} viewContainerRef Container passado do componente que utiliza o service.
     * @param {?=} show Flag indicando se ela deverá aparecer ou não.
     * @param {?=} duration Tempo que a notificação deverá ficar visível.
     * @return {?} Referência do PsNotifyComponent criado dinamicamente.
     */
    function (msn, type, viewContainerRef, show, duration) {
        var /** @type {?} */ factory = this._resolver.resolveComponentFactory(PsNotifyComponent);
        var /** @type {?} */ notifyType = type;
        var /** @type {?} */ content = this._renderer2.createText(msn);
        var /** @type {?} */ injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psNotifyConfig',
                useValue: {
                    notifyType: notifyType,
                    duration: duration,
                    show: show
                }
            }
        ]);
        var /** @type {?} */ componentRef = viewContainerRef.createComponent(factory, 0, injector, [[content]]);
        var /** @type {?} */ psNotifyElem = /** @type {?} */ ((/** @type {?} */ (componentRef.hostView)).rootNodes[0]);
        document.body.appendChild(psNotifyElem);
        return componentRef;
    };
    PsNotifyService.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    PsNotifyService.ctorParameters = function () { return [
        { type: RendererFactory2, },
        { type: Injector, },
        { type: ComponentFactoryResolver, },
    ]; };
    return PsNotifyService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva que cria uma notificação quando outro componente é anotado com ela.
 */
var PsNotifyDirective = (function () {
    function PsNotifyDirective(_renderer2, _elementRef, _viewContainerRef, psNotifyService) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._viewContainerRef = _viewContainerRef;
        this.psNotifyService = psNotifyService;
    }
    /**
     * @return {?}
     */
    PsNotifyDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
        var /** @type {?} */ _notifyType = this._getNotifyType();
        this.componentRef = this.psNotifyService.createNotify(this._content, _notifyType, this._viewContainerRef, this._show, this._duration);
    };
    /**
     * @return {?}
     */
    PsNotifyDirective.prototype.onclick = /**
     * @return {?}
     */
    function () {
        (/** @type {?} */ (this.componentRef.instance)).open();
    };
    /**
     * Método para definir o tipo de notificação baseada no conteúdo.
     * @return {?}
     */
    PsNotifyDirective.prototype._getNotifyType = /**
     * Método para definir o tipo de notificação baseada no conteúdo.
     * @return {?}
     */
    function () {
        if (typeof this._contentSuccess !== 'undefined') {
            this._content = this._contentSuccess;
            return 'ps-notify-success';
        }
        else if (typeof this._contentError !== 'undefined') {
            this._content = this._contentError;
            return 'ps-notify-error';
        }
        else if (typeof this._contentAlert !== 'undefined') {
            this._content = this._contentAlert;
            return 'ps-notify-alert';
        }
    };
    PsNotifyDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-notify-success], [ps-notify-error], [ps-notify-alert]',
                    providers: [PsNotifyService]
                },] },
    ];
    /** @nocollapse */
    PsNotifyDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
        { type: ViewContainerRef, },
        { type: PsNotifyService, },
    ]; };
    PsNotifyDirective.propDecorators = {
        "_contentSuccess": [{ type: Input, args: ['ps-notify-success',] },],
        "_contentError": [{ type: Input, args: ['ps-notify-error',] },],
        "_contentAlert": [{ type: Input, args: ['ps-notify-alert',] },],
        "_duration": [{ type: Input, args: ['duration',] },],
        "_show": [{ type: Input, args: ['show',] },],
        "onclick": [{ type: HostListener, args: ['click',] },],
    };
    return PsNotifyDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsNotifyModule = (function () {
    function PsNotifyModule() {
    }
    PsNotifyModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsNotifyComponent,
                        PsNotifyDirective
                    ],
                    declarations: [
                        PsNotifyComponent,
                        PsNotifyDirective
                    ],
                    providers: [
                        PsNotifyService
                    ],
                    entryComponents: [
                        PsNotifyComponent
                    ]
                },] },
    ];
    /** @nocollapse */
    PsNotifyModule.ctorParameters = function () { return []; };
    return PsNotifyModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-sharer>` ou `<ps-sharer-matte-dark>`
 *
 * Componente de compartilhamento (share) dos links de mídias sociais.
 */
var PsSharerComponent = (function () {
    function PsSharerComponent(_elementRef) {
        this._elementRef = _elementRef;
    }
    /**
     * @return {?}
     */
    PsSharerComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ actualUrl = window.location.href;
        switch (this._type) {
            case 'facebook':
                this._url = 'https://www.facebook.com/sharer/sharer.php?u=' + actualUrl;
                break;
            case 'twitter':
                var /** @type {?} */ textParam = (typeof this._text !== 'undefined') ? ('&text=' + encodeURIComponent(this._text)) : '';
                var /** @type {?} */ hashTagsParam = (typeof this._hashtags !== 'undefined') ? ('&hashtags=' + encodeURIComponent(this._hashtags)) : '';
                this._url = 'https://twitter.com/intent/tweet?url=' + textParam + hashTagsParam;
                break;
            case 'googlePlus':
                this._url = 'https://plus.google.com/share?url=' + actualUrl;
                break;
            case 'linkedIn':
                var /** @type {?} */ profileParam = (typeof this._profile !== 'undefined') ? ('&source=' + encodeURIComponent(this._profile)) :
                    ('&source=' + encodeURIComponent('Porto Seguro'));
                var /** @type {?} */ titleParam = (typeof this._title !== 'undefined') ? ('&text=' + encodeURIComponent(this._title)) : '';
                var /** @type {?} */ _textParam = (typeof this._text !== 'undefined') ? ('&text=' + encodeURIComponent(this._text)) : '';
                this._url = 'http://www.linkedin.com/shareArticle?mini=true&url=' + profileParam + titleParam + _textParam;
                break;
        }
        var /** @type {?} */ matteDarkCSS = 'ps-sharer-matte-dark';
        if (this._elementRef.nativeElement.tagName.toLowerCase() === matteDarkCSS) {
            this._isMatteDarkCSS = matteDarkCSS;
        }
    };
    PsSharerComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-sharer, ps-sharer-matte-dark',
                    template: "<a href=\"{{_url}}\" class=\"ps-sharer-{{_type}} {{_isMatteDarkCSS}}\" target=\"_blank\">\n              <ng-content></ng-content>\n             </a>"
                },] },
    ];
    /** @nocollapse */
    PsSharerComponent.ctorParameters = function () { return [
        { type: ElementRef, },
    ]; };
    PsSharerComponent.propDecorators = {
        "_type": [{ type: Input, args: ['ps-type',] },],
        "_text": [{ type: Input, args: ['ps-sharer-text',] },],
        "_hashtags": [{ type: Input, args: ['ps-sharer-hashtags',] },],
        "_profile": [{ type: Input, args: ['ps-sharer-profile',] },],
        "_title": [{ type: Input, args: ['ps-sharer-title',] },],
    };
    return PsSharerComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsSharerModule = (function () {
    function PsSharerModule() {
    }
    PsSharerModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsSharerComponent
                    ],
                    declarations: [
                        PsSharerComponent
                    ],
                },] },
    ];
    /** @nocollapse */
    PsSharerModule.ctorParameters = function () { return []; };
    return PsSharerModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Classe que contém o css do componente PsSliderComponent.
 * Obs.: Não foi usado um arquivo .scss por motivos de build da lib.
 *
 */
var PsSliderStyle = (function () {
    function PsSliderStyle() {
    }
    PsSliderStyle.styles = ["\n    nouislider {\n        margin-top: 2em !important;\n        margin-bottom: 1em !important;\n    }\n    /*! nouislider - 11.1.0 - 2018-04-02 11:18:13 */\n    /* Functional styling;\n    * These styles are required for noUiSlider to function.\n    * You don't need to change these rules to apply your design.\n    */\n    .noUi-target,\n    .noUi-target * {\n        -webkit-touch-callout: none;\n        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n        -webkit-user-select: none;\n        -ms-touch-action: none;\n        touch-action: none;\n        -ms-user-select: none;\n        -moz-user-select: none;\n        user-select: none;\n        -moz-box-sizing: border-box;\n        box-sizing: border-box;\n    }\n    .noUi-target {\n        position: relative;\n        direction: ltr;\n    }\n    .noUi-base,\n    .noUi-connects {\n        width: 100%;\n        height: 100%;\n        position: relative;\n        z-index: 1;\n    }\n    /* Wrapper for all connect elements.\n    */\n    .noUi-connects {\n        overflow: hidden;\n        z-index: 0;\n    }\n    .noUi-connect,\n    .noUi-origin {\n        will-change: transform;\n        position: absolute;\n        z-index: 1;\n        top: 0;\n        left: 0;\n        height: 100%;\n        width: 100%;\n        -ms-transform-origin: 0 0;\n        -webkit-transform-origin: 0 0;\n        transform-origin: 0 0;\n    }\n    /* Offset direction\n    */\n    html:not([dir=\"rtl\"]) .noUi-horizontal .noUi-origin {\n        left: auto;\n        right: 0;\n    }\n    /* Give origins 0 height/width so they don't interfere with clicking the\n    * connect elements.\n    */\n    .noUi-vertical .noUi-origin {\n        width: 0;\n    }\n    .noUi-horizontal .noUi-origin {\n        height: 0;\n    }\n    .noUi-handle {\n        position: absolute;\n    }\n    .noUi-state-tap .noUi-connect,\n    .noUi-state-tap .noUi-origin {\n    -webkit-transition: transform 0.3s;\n        transition: transform 0.3s;\n    }\n    .noUi-state-drag * {\n        cursor: inherit !important;\n    }\n    /* Slider size and handle placement;\n    */\n    .noUi-horizontal {\n        height: 18px;\n    }\n    .noUi-horizontal .noUi-handle {\n        width: 34px;\n        height: 28px;\n        left: -17px;\n        top: -6px;\n    }\n    .noUi-vertical {\n        width: 18px;\n    }\n    .noUi-vertical .noUi-handle {\n        width: 28px;\n        height: 34px;\n        left: -6px;\n        top: -17px;\n    }\n    html:not([dir=\"rtl\"]) .noUi-horizontal .noUi-handle {\n        right: -17px;\n        left: auto;\n    }\n    /* Styling;\n    * Giving the connect element a border radius causes issues with using transform: scale\n    */\n    .noUi-target {\n        background: none !important;\n        border-radius: 0 !important;\n        border: none !important;\n        box-shadow: none !important;\n    }\n    .noUi-connects {\n        border-radius: 1px;\n        height: 2px;\n        background: #c7c7c7;\n    }\n    .noUi-connect {\n        background: #30C5FF;\n    }\n    /* Handles and cursors;\n    */\n    .noUi-draggable {\n        cursor: ew-resize;\n    }\n    .noUi-vertical .noUi-draggable {\n        cursor: ns-resize;\n    }\n    .noUi-handle {\n        border: none;\n        border-radius: 99px;\n        background: #30C5FF;\n        cursor: default;\n        width: 40px !important;\n        height: 40px !important;\n        display: inline-block;\n        margin-top: -16px;\n        box-shadow: -2px 2px 3px 0 rgba(0,0,0,.2);\n        cursor: pointer;\n\n    &:focus,\n    &:focus:active {\n        outline: none !important;\n    }\n    }\n    .noUi-active {\n        box-shadow: -2px 2px 3px 0 rgba(0,0,0,.2);\n    }\n    /* Handle stripes;\n    */\n    .noUi-handle:before,\n    .noUi-handle:after {\n        content: \"\";\n        display: none;\n        position: absolute;\n        height: 14px;\n        width: 1px;\n        background: #E8E7E6;\n        left: 14px;\n        top: 6px;\n    }\n    .noUi-handle:after {\n        left: 17px;\n    }\n    .noUi-vertical .noUi-handle:before,\n    .noUi-vertical .noUi-handle:after {\n        width: 14px;\n        height: 1px;\n        left: 6px;\n        top: 14px;\n    }\n    .noUi-vertical .noUi-handle:after {\n        top: 17px;\n    }\n    /* Disabled state;\n    */\n    [disabled] .noUi-connect {\n        background: #B8B8B8;\n    }\n    [disabled].noUi-target,\n    [disabled].noUi-handle,\n    [disabled] .noUi-handle {\n        cursor: not-allowed;\n    }\n    /* Base;\n    *\n    */\n    .noUi-pips,\n    .noUi-pips * {\n    -moz-box-sizing: border-box;\n        box-sizing: border-box;\n    }\n    .noUi-pips {\n        position: absolute;\n        color: #999;\n    }\n    /* Values;\n    *\n    */\n    .noUi-value {\n        position: absolute;\n        white-space: nowrap;\n        text-align: center;\n    }\n    .noUi-value-sub {\n        color: #ccc;\n        font-size: 10px;\n    }\n    /* Markings;\n    *\n    */\n    .noUi-marker {\n        position: absolute;\n        background: #CCC;\n    }\n    .noUi-marker-sub {\n        background: #AAA;\n    }\n    .noUi-marker-large {\n        background: #AAA;\n    }\n    /* Horizontal layout;\n    *\n    */\n    .noUi-pips-horizontal {\n        padding: 10px 0;\n        height: 80px;\n        top: 100%;\n        left: 0;\n        width: 100%;\n    }\n    .noUi-value-horizontal {\n    -webkit-transform: translate(-50%, 50%);\n        transform: translate(-50%, 50%);\n    }\n    .noUi-rtl .noUi-value-horizontal {\n    -webkit-transform: translate(50%, 50%);\n        transform: translate(50%, 50%);\n    }\n    .noUi-marker-horizontal.noUi-marker {\n        margin-left: -1px;\n        width: 2px;\n        height: 5px;\n    }\n    .noUi-marker-horizontal.noUi-marker-sub {\n        height: 10px;\n    }\n    .noUi-marker-horizontal.noUi-marker-large {\n        height: 15px;\n    }\n    /* Vertical layout;\n    *\n    */\n    .noUi-pips-vertical {\n        padding: 0 10px;\n        height: 100%;\n        top: 0;\n        left: 100%;\n    }\n    .noUi-value-vertical {\n        -webkit-transform: translate(0, -50%);\n        transform: translate(0, -50%, 0);\n        padding-left: 25px;\n    }\n    .noUi-rtl .noUi-value-vertical {\n        -webkit-transform: translate(0, 50%);\n        transform: translate(0, 50%);\n    }\n    .noUi-marker-vertical.noUi-marker {\n        width: 5px;\n        height: 2px;\n        margin-top: -1px;\n    }\n    .noUi-marker-vertical.noUi-marker-sub {\n        width: 10px;\n    }\n    .noUi-marker-vertical.noUi-marker-large {\n        width: 15px;\n    }\n    .noUi-tooltip {\n        display: block;\n        position: absolute;\n        border: 1px solid #D9D9D9;\n        border-radius: 3px;\n        background: #fff;\n        color: #000;\n        padding: 5px;\n        text-align: center;\n        white-space: nowrap;\n    }\n    .noUi-horizontal .noUi-tooltip {\n        -webkit-transform: translate(-50%, 0);\n        transform: translate(-50%, 0);\n        left: 50%;\n        bottom: 120%;\n    }\n    .noUi-vertical .noUi-tooltip {\n        -webkit-transform: translate(0, -50%);\n        transform: translate(0, -50%);\n        top: 50%;\n        right: 120%;\n    }"];
    return PsSliderStyle;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-range-slider>`
 *
 * Componente range slider (Slider com Intervalo).
 */
var PsRangeSliderComponent = (function () {
    function PsRangeSliderComponent() {
        /**
         * Valor mínimo do intervalo.
         */
        this._minvalue = 1;
        /**
         * Valor máximo do intervalo.
         */
        this._maxvalue = 100;
        /**
         * Unidades adicionadas ou subtraidas do valor atual do slider quando altera-se o tracker.
         */
        this._steps = 1;
        /**
         * Flag para disabilitar o slider.
         */
        this._disabled = false;
        /**
         * Callback chamado a cada alteração do valor atual no slider.
         */
        this.onChange = new EventEmitter();
        /**
         * Intervalo padrão (caso nenhum seja configurado).
         */
        this._range = [0, 100];
    }
    /**
     * @return {?}
     */
    PsRangeSliderComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    PsRangeSliderComponent.prototype.ngAfterContentInit = /**
     * @return {?}
     */
    function () {
        if (this._defaultvalues) {
            var /** @type {?} */ values = this._defaultvalues.replace(/'/g, '').split(',');
            this._range[0] = parseFloat(values[0]);
            this._range[1] = parseFloat(values[1]);
        }
    };
    /**
     * @param {?} $event
     * @return {?}
     */
    PsRangeSliderComponent.prototype._onChange = /**
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
        this.onChange.emit($event);
    };
    PsRangeSliderComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-range-slider',
                    template: " <nouislider\n                [connect]=\"true\"\n                [min]=\"_minvalue\"\n                [max]=\"_maxvalue\"\n                [step]=\"_steps\"\n                [(ngModel)]=\"_range\"\n                [disabled]=\"_disabled\"\n                (ngModelChange)=\"_onChange($event)\">\n              </nouislider>",
                    styles: PsSliderStyle.styles,
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsRangeSliderComponent.ctorParameters = function () { return []; };
    PsRangeSliderComponent.propDecorators = {
        "_defaultvalues": [{ type: Input, args: ['defaultvalues',] },],
        "_minvalue": [{ type: Input, args: ['minvalue',] },],
        "_maxvalue": [{ type: Input, args: ['maxvalue',] },],
        "_steps": [{ type: Input, args: ['steps',] },],
        "_disabled": [{ type: Input, args: ['disabled',] },],
        "onChange": [{ type: Output },],
    };
    return PsRangeSliderComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ps-slider>`
 *
 * Componente slider.
 */
var PsSliderComponent = (function () {
    function PsSliderComponent() {
        /**
         * Valor mínimo do intervalo.
         */
        this._minvalue = 1;
        /**
         * Valor máximo do intervalo.
         */
        this._maxvalue = 100;
        /**
         * Unidades adicionadas ou subtraidas do valor atual do slider quando altera-se o tracker.
         */
        this._steps = 1;
        /**
         * Flag para disabilitar o slider.
         */
        this._disabled = false;
        /**
         * Callback chamado a cada alteração do valor atual no slider.
         */
        this.onChange = new EventEmitter();
    }
    /**
     * @return {?}
     */
    PsSliderComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @param {?} $event
     * @return {?}
     */
    PsSliderComponent.prototype._onChange = /**
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
        this.onChange.emit($event);
    };
    PsSliderComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-slider',
                    template: " <nouislider\n                  [min]=\"_minvalue\"\n                  [max]=\"_maxvalue\"\n                  [step]=\"_steps\"\n                  [disabled]=\"_disabled\"\n                  [(ngModel)]=\"_defaultvalue\"\n                  (ngModelChange)=\"_onChange($event)\">\n                </nouislider>",
                    styles: PsSliderStyle.styles,
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsSliderComponent.ctorParameters = function () { return []; };
    PsSliderComponent.propDecorators = {
        "_defaultvalue": [{ type: Input, args: ['defaultvalue',] },],
        "_minvalue": [{ type: Input, args: ['minvalue',] },],
        "_maxvalue": [{ type: Input, args: ['maxvalue',] },],
        "_steps": [{ type: Input, args: ['steps',] },],
        "_disabled": [{ type: Input, args: ['disabled',] },],
        "onChange": [{ type: Output },],
    };
    return PsSliderComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsSliderModule = (function () {
    function PsSliderModule() {
    }
    PsSliderModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        NouisliderModule
                    ],
                    exports: [
                        PsRangeSliderComponent,
                        PsSliderComponent
                    ],
                    declarations: [
                        PsRangeSliderComponent,
                        PsSliderComponent
                    ]
                },] },
    ];
    /** @nocollapse */
    PsSliderModule.ctorParameters = function () { return []; };
    return PsSliderModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Array contento atributos mapeados para classes css.
 */
var PS_TABLE_HOST_ATTRIBUTES = ['ps-table-grid', 'ps-table-stripped'];
/**
 * Diretiva de atributo para alterar o estilo de um elemento table.
 */
var PsTableDirective = (function () {
    function PsTableDirective(_renderer, _elementRef) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
        _renderer.addClass(_elementRef.nativeElement, 'ps-table');
        for (var _i = 0, PS_TABLE_HOST_ATTRIBUTES_1 = PS_TABLE_HOST_ATTRIBUTES; _i < PS_TABLE_HOST_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_TABLE_HOST_ATTRIBUTES_1[_i];
            if (this._hasHostAttributes(attribute)) {
                this._renderer.addClass(this._elementRef.nativeElement, attribute);
            }
        }
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    PsTableDirective.prototype._getHostElement = /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsTableDirective.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    PsTableDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-table], [ps-table-grid], [ps-table-stripped]'
                },] },
    ];
    /** @nocollapse */
    PsTableDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    return PsTableDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsTableModule = (function () {
    function PsTableModule() {
    }
    PsTableModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsTableDirective
                    ],
                    declarations: [
                        PsTableDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsTableModule.ctorParameters = function () { return []; };
    return PsTableModule;
}());

var __extends$1 = (undefined && undefined.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ng-template ps-tab-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-tab>`.
 */
var PsTabTitleDirective = (function () {
    function PsTabTitleDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsTabTitleDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-tab-title]'
                },] },
    ];
    /** @nocollapse */
    PsTabTitleDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsTabTitleDirective;
}());
/**
 * `<ng-template ps-tab-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-tab>`.
 */
var PsTabContentDirective = (function () {
    function PsTabContentDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsTabContentDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-tab-content]'
                },] },
    ];
    /** @nocollapse */
    PsTabContentDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsTabContentDirective;
}());
var nextUniqueId$7 = 1;
var PS_TAB_ATTRIBUTES = ['ps-tab-ico'];
/**
 * Superclasse para o componente ps-tab e seu pai ps-tabs.
 */
var PsTabsBase = (function () {
    function PsTabsBase(_elementRef) {
        this._elementRef = _elementRef;
    }
    /** Retorna uma referência HTMLElement do componente. */
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsTabsBase.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    PsTabsBase.prototype._hasHostAttributes = /**
     * Verifica se o host element possui algum dos atributos.
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) { return _this._getHostElement().hasAttribute(attribute); });
    };
    return PsTabsBase;
}());
/**
 * `<ps-tab>`
 *
 * Este componente corresponde a aba (tab) de um componente `<ps-tabs>`.
 */
var PsTabComponent = (function (_super) {
    __extends$1(PsTabComponent, _super);
    function PsTabComponent(_elementRef) {
        var _this = _super.call(this, _elementRef) || this;
        /**
         * Contém o id único da aba.
         */
        _this.tabIndex = "tab" + nextUniqueId$7++;
        return _this;
    }
    /**
     * @return {?}
     */
    PsTabComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        for (var _i = 0, PS_TAB_ATTRIBUTES_1 = PS_TAB_ATTRIBUTES; _i < PS_TAB_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_TAB_ATTRIBUTES_1[_i];
            if (this._hasHostAttributes(attribute)) {
                this.hasIco = true;
            }
        }
    };
    PsTabComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-tab',
                    template: ""
                },] },
    ];
    /** @nocollapse */
    PsTabComponent.ctorParameters = function () { return [
        { type: ElementRef, },
    ]; };
    PsTabComponent.propDecorators = {
        "tabIndex": [{ type: Input },],
        "selected": [{ type: Input, args: ['selected',] },],
        "_titleTpl": [{ type: ContentChild, args: [PsTabTitleDirective,] },],
        "_contentTpl": [{ type: ContentChild, args: [PsTabContentDirective,] },],
    };
    return PsTabComponent;
}(PsTabsBase));
/**
 * Opções de alinhamento do conteúdo das abas.
 */
var PS_TABS_ATTRIBUTES = ['ps-tabs-left', 'ps-tabs-center'];
/**
 * `<ps-tabs>`
 *
 * Componente que contém as tabs (Abas).
 */
var PsTabsComponent = (function (_super) {
    __extends$1(PsTabsComponent, _super);
    function PsTabsComponent(_renderer2, _elementRef) {
        var _this = _super.call(this, _elementRef) || this;
        _this._renderer2 = _renderer2;
        /**
         * Evento de callback quando uma aba é aberta.
         */
        _this._ontabshow = new EventEmitter();
        /**
         * Evento de callback quando uma aba é fechada.
         */
        _this._ontabhide = new EventEmitter();
        return _this;
    }
    /**
     * @return {?}
     */
    PsTabsComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        for (var _i = 0, PS_TABS_ATTRIBUTES_1 = PS_TABS_ATTRIBUTES; _i < PS_TABS_ATTRIBUTES_1.length; _i++) {
            var attribute = PS_TABS_ATTRIBUTES_1[_i];
            if (this._hasHostAttributes(attribute)) {
                this._renderer2.addClass(this.psTabs.nativeElement, attribute);
            }
        }
    };
    /**
     * @return {?}
     */
    PsTabsComponent.prototype.ngAfterContentChecked = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ activeTab = this.getTabByIndex(this.activeTabId);
        this.activeTabId = activeTab ? activeTab.tabIndex : (this.tabs.length ? this.tabs.first.tabIndex : null);
    };
    /**
     * Método para selecionar uma aba pelo índice.
     * @param tabIndex Índice da tab.
     */
    /**
     * Método para selecionar uma aba pelo índice.
     * @param {?} tabIndex Índice da tab.
     * @return {?}
     */
    PsTabsComponent.prototype.selectTabByIndex = /**
     * Método para selecionar uma aba pelo índice.
     * @param {?} tabIndex Índice da tab.
     * @return {?}
     */
    function (tabIndex) {
        var /** @type {?} */ selectedTab = this.getTabByIndex(tabIndex);
        if (selectedTab && this.activeTabId !== selectedTab.tabIndex) {
            this._ontabhide.emit(this.activeTabId);
            this.activeTabId = selectedTab.tabIndex;
            this._ontabshow.emit(selectedTab.tabIndex);
        }
    };
    /**
     * Método que retorna um componente PsTabComponent pelo correspondente índice.
     * @param tabIndex Índice da tab.
     * @returns Referência da tab (PsTabComponent).
     */
    /**
     * Método que retorna um componente PsTabComponent pelo correspondente índice.
     * @param {?} tabIndex Índice da tab.
     * @return {?} Referência da tab (PsTabComponent).
     */
    PsTabsComponent.prototype.getTabByIndex = /**
     * Método que retorna um componente PsTabComponent pelo correspondente índice.
     * @param {?} tabIndex Índice da tab.
     * @return {?} Referência da tab (PsTabComponent).
     */
    function (tabIndex) {
        var /** @type {?} */ tabsSelected;
        if (!this.activeTabId) {
            tabsSelected = this.tabs.filter(function (tab) { return tab.selected === true; });
        }
        else {
            tabsSelected = this.tabs.filter(function (tab) { return tab.tabIndex === tabIndex; });
        }
        return tabsSelected.length ? tabsSelected[0] : null;
    };
    PsTabsComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-tabs',
                    template: "\n        <ul class=\"ps-tabs\" role=\"tablist\" #psTabs>\n            <li *ngFor=\"let tab of tabs\">\n               <a href=\"javascript:void(0);\"\n                  (click)=\"selectTabByIndex(tab.tabIndex)\"\n                  class=\"ps-tab\"\n                  [ngClass]=\"{'ps-tab-selected' : tab.tabIndex === activeTabId, 'ps-tab-ico': tab.hasIco}\"\n                  role=\"tab\" #{{tab.tabIndex}}>\n                <ng-template [ngTemplateOutlet]=\"tab._titleTpl.templateRef\"></ng-template>\n               </a>\n            </li>\n        </ul>\n        <div class=\"ps-tab-content\">\n            <ng-template ngFor let-tab [ngForOf]=\"tabs\">\n                <div class=\"ps-tab-content-item\" *ngIf=\"tab.tabIndex === activeTabId\">\n                    <ng-template [ngTemplateOutlet]=\"tab._contentTpl.templateRef\"></ng-template>\n                </div>\n            </ng-template>\n        </div>\n        "
                },] },
    ];
    /** @nocollapse */
    PsTabsComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsTabsComponent.propDecorators = {
        "tabs": [{ type: ContentChildren, args: [PsTabComponent,] },],
        "activeTabId": [{ type: Input },],
        "psTabs": [{ type: ViewChild, args: ['psTabs',] },],
        "_ontabshow": [{ type: Output, args: ['ontabshow',] },],
        "_ontabhide": [{ type: Output, args: ['ontabhide',] },],
    };
    return PsTabsComponent;
}(PsTabsBase));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsTabsModule = (function () {
    function PsTabsModule() {
    }
    PsTabsModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsTabsComponent,
                        PsTabComponent,
                        PsTabTitleDirective,
                        PsTabContentDirective
                    ],
                    declarations: [
                        PsTabsComponent,
                        PsTabComponent,
                        PsTabTitleDirective,
                        PsTabContentDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsTabsModule.ctorParameters = function () { return []; };
    return PsTabsModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva de atributo para alterar o estilo das tags de título (h1, h2, etc.).
 */
var PsTitleDirective = (function () {
    function PsTitleDirective(_renderer, _el) {
        this._renderer = _renderer;
        this._el = _el;
    }
    /**
     * @return {?}
     */
    PsTitleDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this._renderer.addClass(this._el.nativeElement, 'ps-heading-' + this._heading);
        if (this._light) {
            this._renderer.addClass(this._el.nativeElement, this._light);
        }
    };
    PsTitleDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ps-title]'
                },] },
    ];
    /** @nocollapse */
    PsTitleDirective.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsTitleDirective.propDecorators = {
        "_heading": [{ type: Input, args: ['ps-heading',] },],
        "_light": [{ type: Input, args: ['ps-light',] },],
    };
    return PsTitleDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsTitleModule = (function () {
    function PsTitleModule() {
    }
    PsTitleModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    exports: [
                        PsTitleDirective
                    ],
                    declarations: [
                        PsTitleDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsTitleModule.ctorParameters = function () { return []; };
    return PsTitleModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Diretiva interna usada como elemento seletor no componente PsTooltipComponent.
 * \@docs-private
 */
var PsTooltipCttDirective = (function () {
    function PsTooltipCttDirective() {
    }
    PsTooltipCttDirective.decorators = [
        { type: Directive, args: [{
                    selector: '.ps-tooltip-ctt'
                },] },
    ];
    /** @nocollapse */
    PsTooltipCttDirective.ctorParameters = function () { return []; };
    return PsTooltipCttDirective;
}());
/**
 * Componente tooltip interno criado dinamicamente.
 * \@docs-private
 */
var PsTooltipComponent = (function () {
    function PsTooltipComponent(psTooltipConfig) {
        this.psTooltipConfig = psTooltipConfig;
    }
    /**
     * @return {?}
     */
    PsTooltipComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ p = this.positionElements(this.psTooltipConfig.hostElement, this.psTooltipCtt.nativeElement, this.placement);
        this.top = p.top;
        this.left = p.left;
    };
    /**
     * Método para posicionamento do tooltip e direção da seta.
     * @param {?} hostEl HTMLElement contendo o componente tooltip.
     * @param {?} targetEl HTMLElement que possui o tooltip e é registrado o evento.
     * @param {?} positionStr Posição (top, bottom, right e lef).
     * @param {?=} appendToBody Anexa o componente tooltip criado ao body ao invés do container do targetEl.
     * @return {?} Posições top e left corrigidas.
     */
    PsTooltipComponent.prototype.positionElements = /**
     * Método para posicionamento do tooltip e direção da seta.
     * @param {?} hostEl HTMLElement contendo o componente tooltip.
     * @param {?} targetEl HTMLElement que possui o tooltip e é registrado o evento.
     * @param {?} positionStr Posição (top, bottom, right e lef).
     * @param {?=} appendToBody Anexa o componente tooltip criado ao body ao invés do container do targetEl.
     * @return {?} Posições top e left corrigidas.
     */
    function (hostEl, targetEl, positionStr, appendToBody) {
        if (appendToBody === void 0) { appendToBody = false; }
        var /** @type {?} */ positionStrParts = positionStr.split('-');
        var /** @type {?} */ pos0 = positionStrParts[0];
        var /** @type {?} */ pos1 = positionStrParts[1] || 'center';
        var /** @type {?} */ hostElPos = appendToBody ? this.offset(hostEl) : this.position(hostEl);
        var /** @type {?} */ targetElWidth = targetEl.offsetWidth;
        var /** @type {?} */ targetElHeight = targetEl.offsetHeight;
        var /** @type {?} */ shiftWidth = {
            center: function () {
                return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
            },
            left: function () {
                return hostElPos.left;
            },
            right: function () {
                return hostElPos.left + hostElPos.width;
            }
        };
        var /** @type {?} */ shiftHeight = {
            center: function () {
                return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
            },
            top: function () {
                return hostElPos.top;
            },
            bottom: function () {
                return hostElPos.top + hostElPos.height;
            }
        };
        var /** @type {?} */ targetElPos;
        switch (pos0) {
            case 'right':
                targetElPos = {
                    top: shiftHeight[pos1](),
                    left: shiftWidth[pos0]() + 7
                };
                break;
            case 'left':
                targetElPos = {
                    top: shiftHeight[pos1](),
                    left: hostElPos.left - targetElWidth - 7
                };
                break;
            case 'bottom':
                targetElPos = {
                    top: shiftHeight[pos0]() + 7,
                    left: shiftWidth[pos1]()
                };
                break;
            default:
                targetElPos = {
                    top: hostElPos.top - targetElHeight - 7,
                    left: shiftWidth[pos1]()
                };
                break;
        }
        return targetElPos;
    };
    /**
     * Método que calcula a posição e dimensões de um elemento.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Posições (top e left) e dimenões (width, height) calculadas.
     */
    PsTooltipComponent.prototype.position = /**
     * Método que calcula a posição e dimensões de um elemento.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Posições (top e left) e dimenões (width, height) calculadas.
     */
    function (nativeEl) {
        var /** @type {?} */ offsetParentBCR = { top: 0, left: 0 };
        var /** @type {?} */ elBCR = this.offset(nativeEl);
        var /** @type {?} */ offsetParentEl = this.parentOffsetEl(nativeEl);
        if (offsetParentEl !== window.document) {
            offsetParentBCR = this.offset(offsetParentEl);
            offsetParentBCR.top += offsetParentEl.clientTop - offsetParentEl.scrollTop;
            offsetParentBCR.left += offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
        }
        var /** @type {?} */ boundingClientRect = nativeEl.getBoundingClientRect();
        return {
            width: boundingClientRect.width || nativeEl.offsetWidth,
            height: boundingClientRect.height || nativeEl.offsetHeight,
            top: elBCR.top - offsetParentBCR.top,
            left: elBCR.left - offsetParentBCR.left
        };
    };
    /**
     * Método que retorna os valores de posições de um elemento pelo método getBoundingClientRect().
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Posições (top e left) e dimenões (width, height) calculadas.
     */
    PsTooltipComponent.prototype.offset = /**
     * Método que retorna os valores de posições de um elemento pelo método getBoundingClientRect().
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Posições (top e left) e dimenões (width, height) calculadas.
     */
    function (nativeEl) {
        var /** @type {?} */ boundingClientRect = nativeEl.getBoundingClientRect();
        return {
            width: boundingClientRect.width || nativeEl.offsetWidth,
            height: boundingClientRect.height || nativeEl.offsetHeight,
            top: boundingClientRect.top + (window.pageYOffset || window.document.documentElement.scrollTop),
            left: boundingClientRect.left + (window.pageXOffset || window.document.documentElement.scrollLeft)
        };
    };
    /**
     * Método que retorna o valor de uma propriedade definida no atributo style do elemento.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @param {?} cssProp
     * @return {?} string contendo o valor do atributo style.
     */
    PsTooltipComponent.prototype.getStyle = /**
     * Método que retorna o valor de uma propriedade definida no atributo style do elemento.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @param {?} cssProp
     * @return {?} string contendo o valor do atributo style.
     */
    function (nativeEl, cssProp) {
        if ((/** @type {?} */ (nativeEl)).currentStyle) {
            // IE
            return (/** @type {?} */ (nativeEl)).currentStyle[cssProp];
        }
        if (window.getComputedStyle) {
            return (/** @type {?} */ (window.getComputedStyle(nativeEl)))[cssProp];
        }
        // finally try and get inline style.
        return (/** @type {?} */ (nativeEl.style))[cssProp];
    };
    /**
     * Método que verifica se o elemento não está com a propriedade position: static definida no atributo style.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Verdadeiro se conter a propriedade 'position' com valor 'static'.
     */
    PsTooltipComponent.prototype.isStaticPositioned = /**
     * Método que verifica se o elemento não está com a propriedade position: static definida no atributo style.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Verdadeiro se conter a propriedade 'position' com valor 'static'.
     */
    function (nativeEl) {
        return (this.getStyle(nativeEl, 'position') || 'static') === 'static';
    };
    /**
     * Método que retorna o pai de um elemento.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} HTMLElement | document do elemento nativeEl.
     */
    PsTooltipComponent.prototype.parentOffsetEl = /**
     * Método que retorna o pai de um elemento.
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} HTMLElement | document do elemento nativeEl.
     */
    function (nativeEl) {
        var /** @type {?} */ offsetParent = nativeEl.offsetParent || window.document;
        while (offsetParent && offsetParent !== window.document && this.isStaticPositioned(offsetParent)) {
            offsetParent = offsetParent.offsetParent;
        }
        return offsetParent || window.document;
    };
    PsTooltipComponent.decorators = [
        { type: Component, args: [{
                    template: "<div class=\"ps-tooltip-ctt ps-arrow-center\"\n                  [ngClass]=\"{'ps-arrow-bottom': placement === 'top',\n                              'ps-arrow-side-left': placement === 'right',\n                              'ps-arrow-top': placement === 'bottom',\n                              'ps-arrow-side-right': placement === 'left'}\"\n                  [ngStyle]=\"{visibility: 'visible', opacity: '1'}\"\n                  [style.top]=\"top + 'px'\"\n                  [style.left]=\"left + 'px'\">\n                  <ng-content></ng-content>\n              </div>"
                },] },
    ];
    /** @nocollapse */
    PsTooltipComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: ['psTooltipConfig',] },] },
    ]; };
    PsTooltipComponent.propDecorators = {
        "psTooltipCtt": [{ type: ViewChild, args: [PsTooltipCttDirective, { read: ElementRef },] },],
    };
    return PsTooltipComponent;
}());
/**
 * Diretiva de atributo para abrir um tooltip no elemento assinalado.
 */
var PsTooltipDirective = (function () {
    function PsTooltipDirective(_element, _renderer, _injector, _resolver, _viewContainerRef) {
        this._element = _element;
        this._renderer = _renderer;
        this._injector = _injector;
        this._resolver = _resolver;
        this._viewContainerRef = _viewContainerRef;
    }
    /**
     * Método acionado pelos eventos focus e mouseenter que cria o tooltip.
     * @return {?}
     */
    PsTooltipDirective.prototype.create = /**
     * Método acionado pelos eventos focus e mouseenter que cria o tooltip.
     * @return {?}
     */
    function () {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
        var /** @type {?} */ factory = this._resolver.resolveComponentFactory(PsTooltipComponent);
        var /** @type {?} */ injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psTooltipConfig',
                useValue: {
                    hostElement: this._element.nativeElement
                }
            }
        ]);
        var /** @type {?} */ position = { placement: 'top' };
        var /** @type {?} */ tooltipContent = this.generatePsTooltipContent(position);
        this.componentRef = this._viewContainerRef.createComponent(factory, 0, injector, tooltipContent);
        this.componentRef.instance.placement = position.placement;
        var /** @type {?} */ hostElement = this._element.nativeElement;
        var /** @type {?} */ tooltipElement = this.componentRef.location.nativeElement;
        hostElement.addEventListener('mouseleave', function (event) {
            tooltipElement.style.visibility = 'hidden';
            tooltipElement.style.opacity = '0';
        });
    };
    /**
     * Método que cria o conteúdo do tooltip e define sua posição através dos parâmetros @Input.
     * @param position Posição do tooltip.
     * @returns Array<Array<any>> contendo o conteúdo do tooltip.
     */
    /**
     * Método que cria o conteúdo do tooltip e define sua posição através dos parâmetros \@Input.
     * @param {?} position Posição do tooltip.
     * @return {?} Array<Array<any>> contendo o conteúdo do tooltip.
     */
    PsTooltipDirective.prototype.generatePsTooltipContent = /**
     * Método que cria o conteúdo do tooltip e define sua posição através dos parâmetros \@Input.
     * @param {?} position Posição do tooltip.
     * @return {?} Array<Array<any>> contendo o conteúdo do tooltip.
     */
    function (position) {
        if (typeof this.content === 'string') {
            position.placement = 'top';
            var /** @type {?} */ element = this._renderer.createText(this.content);
            return [[element]];
        }
        if (typeof this.contentBottom === 'string') {
            position.placement = 'bottom';
            var /** @type {?} */ element = this._renderer.createText(this.contentBottom);
            return [[element]];
        }
        if (typeof this.contentLeft === 'string') {
            position.placement = 'left';
            var /** @type {?} */ element = this._renderer.createText(this.contentLeft);
            return [[element]];
        }
        if (typeof this.contentRight === 'string') {
            position.placement = 'right';
            var /** @type {?} */ element = this._renderer.createText(this.contentRight);
            return [[element]];
        }
        if (this.content instanceof TemplateRef) {
            var /** @type {?} */ _viewRef = this.content.createEmbeddedView({});
            return [_viewRef.rootNodes];
        }
        var /** @type {?} */ factory = this._resolver.resolveComponentFactory(this.content);
        var /** @type {?} */ viewRef = factory.create(this._injector);
        return [[viewRef.location.nativeElement]];
    };
    PsTooltipDirective.decorators = [
        { type: Directive, args: [{
                    selector: "[ps-tooltip],\n             [ps-tooltip-bottom],\n             [ps-tooltip-left],\n             [ps-tooltip-right]"
                },] },
    ];
    /** @nocollapse */
    PsTooltipDirective.ctorParameters = function () { return [
        { type: ElementRef, },
        { type: Renderer2, },
        { type: Injector, },
        { type: ComponentFactoryResolver, },
        { type: ViewContainerRef, },
    ]; };
    PsTooltipDirective.propDecorators = {
        "content": [{ type: Input, args: ['ps-tooltip',] },],
        "contentBottom": [{ type: Input, args: ['ps-tooltip-bottom',] },],
        "contentLeft": [{ type: Input, args: ['ps-tooltip-left',] },],
        "contentRight": [{ type: Input, args: ['ps-tooltip-right',] },],
        "create": [{ type: HostListener, args: ['focusin',] }, { type: HostListener, args: ['mouseenter',] },],
    };
    return PsTooltipDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsTooltipModule = (function () {
    function PsTooltipModule() {
    }
    PsTooltipModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        FormsModule
                    ],
                    exports: [
                        PsTooltipDirective
                    ],
                    declarations: [
                        PsTooltipComponent,
                        PsTooltipCttDirective,
                        PsTooltipDirective
                    ],
                    entryComponents: [
                        PsTooltipComponent
                    ]
                },] },
    ];
    /** @nocollapse */
    PsTooltipModule.ctorParameters = function () { return []; };
    return PsTooltipModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * `<ng-template ps-wizard-label>`
 *
 * Diretiva que corresponde ao label de um componente `<ps-wizard-step>`.
 */
var PsWizardLabelDirective = (function () {
    function PsWizardLabelDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsWizardLabelDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-wizard-label]'
                },] },
    ];
    /** @nocollapse */
    PsWizardLabelDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsWizardLabelDirective;
}());
/**
 * `<ng-template ps-wizard-content>`
 *
 * Diretiva que corresponde ao conteúdo de um componente `<ps-wizard-step>`.
 */
var PsWizardContentDirective = (function () {
    function PsWizardContentDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsWizardContentDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-wizard-content]'
                },] },
    ];
    /** @nocollapse */
    PsWizardContentDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsWizardContentDirective;
}());
/**
 * `<ng-template ps-wizard-submit-row>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-wizard-step>`.
 */
var PsWizardSubmitRowDirective = (function () {
    function PsWizardSubmitRowDirective(templateRef) {
        this.templateRef = templateRef;
    }
    PsWizardSubmitRowDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'ng-template[ps-wizard-submit-row]'
                },] },
    ];
    /** @nocollapse */
    PsWizardSubmitRowDirective.ctorParameters = function () { return [
        { type: TemplateRef, },
    ]; };
    return PsWizardSubmitRowDirective;
}());
var nextUniqueId$8 = 0;
/**
 * `<ps-wizard-step>`
 *
 * Este componente corresponde ao elemento step (passo) de um `<ps-wizard>`.
 */
var PsWizardStepComponent = (function () {
    function PsWizardStepComponent(_elementRef) {
        this._elementRef = _elementRef;
        this.stepId = nextUniqueId$8++;
    }
    PsWizardStepComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-wizard-step',
                    template: "<ng-template><ng-content></ng-content></ng-template>",
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsWizardStepComponent.ctorParameters = function () { return [
        { type: ElementRef, },
    ]; };
    PsWizardStepComponent.propDecorators = {
        "_selected": [{ type: Input, args: ['selected',] },],
        "label": [{ type: ContentChild, args: [PsWizardLabelDirective,] },],
        "content": [{ type: ContentChild, args: [PsWizardContentDirective,] },],
        "submitRow": [{ type: ContentChild, args: [PsWizardSubmitRowDirective,] },],
    };
    return PsWizardStepComponent;
}());
var nextWizardId = 0;
/**
 * `<ps-wizard>`
 *
 * Componente wizard (passo a passo).
 */
var PsWizardComponent = (function () {
    function PsWizardComponent(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único para ser usado caso necessário (atribuído ao atributo id da div principal).
         */
        this._wizardId = "Wizard" + nextWizardId++;
        /**
         * Guarda o número do passo atual.
         */
        this._actualStep = 0;
    }
    /**
     * Método de suporte para a diretiva *ngFor do angular.
     * @param index Índice do laço.
     * @param step referência ao componente PsWizardStepComponent da iteração.
     * @returns Indíce do passo
     */
    /**
     * Método de suporte para a diretiva *ngFor do angular.
     * @param {?} index Índice do laço.
     * @param {?} step referência ao componente PsWizardStepComponent da iteração.
     * @return {?} Indíce do passo
     */
    PsWizardComponent.prototype.trackBySteps = /**
     * Método de suporte para a diretiva *ngFor do angular.
     * @param {?} index Índice do laço.
     * @param {?} step referência ao componente PsWizardStepComponent da iteração.
     * @return {?} Indíce do passo
     */
    function (index, step) {
        return step.stepId;
    };
    /** Move para o próximo passo. */
    /**
     * Move para o próximo passo.
     * @return {?}
     */
    PsWizardComponent.prototype.next = /**
     * Move para o próximo passo.
     * @return {?}
     */
    function () {
        var /** @type {?} */ steps = this._getAllSteps();
        var /** @type {?} */ stepContentItems = this._getAllStepContentItems();
        if (this._actualStep < steps.length) {
            this._actualStep++;
        }
        else {
            this._actualStep = 0;
        }
        this._selecteStep(steps);
        this._selectStepContent(stepContentItems);
    };
    /** Move para o passo anterior. */
    /**
     * Move para o passo anterior.
     * @return {?}
     */
    PsWizardComponent.prototype.previous = /**
     * Move para o passo anterior.
     * @return {?}
     */
    function () {
        var /** @type {?} */ steps = this._getAllSteps();
        var /** @type {?} */ stepContentItems = this._getAllStepContentItems();
        if (this._actualStep > 0 && this._actualStep < steps.length) {
            this._actualStep--;
        }
        else {
            this._actualStep = 0;
        }
        this._selecteStep(steps);
        this._selectStepContent(stepContentItems);
    };
    /**
     * Método chamado para selecionar o passo atual (variável _actualStep).
     * @param {?} steps Coleção HTMLCollection representando os passos.
     * @return {?}
     */
    PsWizardComponent.prototype._selecteStep = /**
     * Método chamado para selecionar o passo atual (variável _actualStep).
     * @param {?} steps Coleção HTMLCollection representando os passos.
     * @return {?}
     */
    function (steps) {
        for (var /** @type {?} */ i = 0; i < steps.length; i++) {
            var /** @type {?} */ step = (/** @type {?} */ (steps.item(i)));
            step.classList.remove('ps-wizard-step-selected');
            if (i === this._actualStep) {
                step.classList.add('ps-wizard-step-selected');
            }
        }
    };
    /**
     * Método chamado para selecionar o bloco de conteúdo do passo atual (variável _actualStep).
     * @param {?} stepContentItems Coleção HTMLCollection representando os conteúdos dos passos.
     * @return {?}
     */
    PsWizardComponent.prototype._selectStepContent = /**
     * Método chamado para selecionar o bloco de conteúdo do passo atual (variável _actualStep).
     * @param {?} stepContentItems Coleção HTMLCollection representando os conteúdos dos passos.
     * @return {?}
     */
    function (stepContentItems) {
        for (var /** @type {?} */ i = 0; i < stepContentItems.length; i++) {
            var /** @type {?} */ stepContentItem = (/** @type {?} */ (stepContentItems.item(i)));
            stepContentItem.style.display = 'none';
            if (i === this._actualStep) {
                stepContentItem.style.display = 'block';
            }
        }
    };
    /**
     * Retorna todos os passos (elementos filho com a classe 'ps-wizard-step').
     * @return {?}
     */
    PsWizardComponent.prototype._getAllSteps = /**
     * Retorna todos os passos (elementos filho com a classe 'ps-wizard-step').
     * @return {?}
     */
    function () {
        return this._getHostElement().getElementsByClassName('ps-wizard-step');
    };
    /**
     * Retorna todos os conteúdos dos passos (elementos filho com a classe 'ps-wizard-content-item').
     * @return {?}
     */
    PsWizardComponent.prototype._getAllStepContentItems = /**
     * Retorna todos os conteúdos dos passos (elementos filho com a classe 'ps-wizard-content-item').
     * @return {?}
     */
    function () {
        return this._getHostElement().getElementsByClassName('ps-wizard-content-item');
    };
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    PsWizardComponent.prototype._getHostElement = /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    function () {
        return this._elementRef.nativeElement;
    };
    PsWizardComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ps-wizard',
                    template: "\n            <ul class=\"ps-wizard\" [ngClass]=\"{'ps-wizard-icon': _icon}\">\n              <li *ngFor=\"let step of _wizardSteps; let i = index; trackBy: trackBySteps\" class=\"ps-wizard-step\"\n                [ngClass]=\"{'ps-wizard-step-selected': step._selected}\">\n                  <a href=\"javascript:void(0);\">\n                    <ng-template [ngTemplateOutlet]=\"step.label.templateRef\"></ng-template>\n                  </a>\n              </li>\n            </ul>\n            <div class=\"ps-wizard-content\">\n             <div *ngFor=\"let step of _wizardSteps; let i = index; trackBy: trackBySteps\"\n                  class=\"ps-wizard-content-item\" id=\"{{_wizardId}}step{{i + 1}}\"\n                  [ngStyle]=\"{'display' : step._selected ? '': 'none'}\">\n                <div class=\"ps-row\">\n                  <ng-template [ngTemplateOutlet]=\"step.content.templateRef\"></ng-template>\n                </div>\n                <div *ngIf=\"step.submitRow\" class=\"ps-row ps-wizard-submit-row\">\n                <ng-template [ngTemplateOutlet]=\"step.submitRow.templateRef\"></ng-template>\n                </div>\n              </div>\n            </div>",
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    PsWizardComponent.ctorParameters = function () { return [
        { type: Renderer2, },
        { type: ElementRef, },
    ]; };
    PsWizardComponent.propDecorators = {
        "_icon": [{ type: Input, args: ['icon',] },],
        "_wizardSteps": [{ type: ContentChildren, args: [PsWizardStepComponent,] },],
    };
    return PsWizardComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
var PsWizardModule = (function () {
    function PsWizardModule() {
    }
    PsWizardModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        PsWizardComponent,
                        PsWizardStepComponent,
                        PsWizardLabelDirective,
                        PsWizardContentDirective,
                        PsWizardSubmitRowDirective
                    ],
                    declarations: [
                        PsWizardComponent,
                        PsWizardStepComponent,
                        PsWizardLabelDirective,
                        PsWizardContentDirective,
                        PsWizardSubmitRowDirective
                    ],
                },] },
    ];
    /** @nocollapse */
    PsWizardModule.ctorParameters = function () { return []; };
    return PsWizardModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Service de suporte para chamada de mensagens de console nos callbacks.
 */
var Logger = (function () {
    function Logger() {
    }
    /**
     * Encapsula uma chamada ao método console.log().
     * @param msg Texto da mensagem.
     */
    /**
     * Encapsula uma chamada ao método console.log().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    Logger.prototype.log = /**
     * Encapsula uma chamada ao método console.log().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    function (msg) {
        console.log(msg);
    };
    /**
     * Encapsula uma chamada ao método console.error().
     * @param msg Texto da mensagem.
     */
    /**
     * Encapsula uma chamada ao método console.error().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    Logger.prototype.error = /**
     * Encapsula uma chamada ao método console.error().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    function (msg) {
        console.error(msg);
    };
    /**
     * Encapsula uma chamada ao método console.warn().
     * @param msg Texto da mensagem.
     */
    /**
     * Encapsula uma chamada ao método console.warn().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    Logger.prototype.warn = /**
     * Encapsula uma chamada ao método console.warn().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    function (msg) {
        console.warn(msg);
    };
    Logger.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    Logger.ctorParameters = function () { return []; };
    return Logger;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Pipe usado quando se quer injetar html via binding [innerHTML] sem ser convertido em texto.
 *
 * ## Examples
 *
 * <p [innerHTML]="value | psSanitizeHTML"></p>
 */
var PsSanitizeHTMLPipe = (function () {
    function PsSanitizeHTMLPipe(sanitized) {
        this.sanitized = sanitized;
    }
    /**
     * Utilizada a referência a um DomSanitizer para analisar o HTML e deixar as tags.
     * @param value HTML passado como parâmetro para o pipe.
     * @returns Referência a um SafeHtml contento o html válido para ser injetado no componente.
     */
    /**
     * Utilizada a referência a um DomSanitizer para analisar o HTML e deixar as tags.
     * @param {?} value HTML passado como parâmetro para o pipe.
     * @return {?} Referência a um SafeHtml contento o html válido para ser injetado no componente.
     */
    PsSanitizeHTMLPipe.prototype.transform = /**
     * Utilizada a referência a um DomSanitizer para analisar o HTML e deixar as tags.
     * @param {?} value HTML passado como parâmetro para o pipe.
     * @return {?} Referência a um SafeHtml contento o html válido para ser injetado no componente.
     */
    function (value) {
        return this.sanitized.bypassSecurityTrustHtml(value);
    };
    PsSanitizeHTMLPipe.decorators = [
        { type: Pipe, args: [{
                    name: 'psSanitizeHTML'
                },] },
    ];
    /** @nocollapse */
    PsSanitizeHTMLPipe.ctorParameters = function () { return [
        { type: DomSanitizer, },
    ]; };
    return PsSanitizeHTMLPipe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Service para dar suporte aos exemplos de uso dos componentes.
 */
var Util = (function () {
    function Util(http$$1, _rendererFactory) {
        this.http = http$$1;
        this._rendererFactory = _rendererFactory;
        this._renderer2 = _rendererFactory.createRenderer(null, null);
    }
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @param {?} url a url que deve ser requisitada para consultar os dados.
     * @return {?} Referência para um objeto Observable contendo o resultado.
     */
    Util.prototype.getObservableSourceFromUrlByGet = /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @param {?} url a url que deve ser requisitada para consultar os dados.
     * @return {?} Referência para um objeto Observable contendo o resultado.
     */
    function (url) {
        var _this = this;
        return function (keyword) {
            var /** @type {?} */ final_url = url + keyword;
            if (keyword) {
                console.log(keyword);
                return _this.http.get(final_url).map(function (res) {
                    var /** @type {?} */ results = res.json();
                    return results;
                });
            }
            else {
                return Observable$1.of([]);
            }
        };
    };
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @return {?} Referência para um objeto Observable contendo o resultado da consulta no Array data.
     */
    Util.prototype.getObservableFromArray = /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @return {?} Referência para um objeto Observable contendo o resultado da consulta no Array data.
     */
    function () {
        var /** @type {?} */ data = ['ActionScript', 'AppleScript', 'Asp', 'BASIC', 'C', 'C++', 'Clojure', 'COBOL', 'ColdFusion', 'Erlang', 'Fortran',
            'Groovy', 'Haskell', 'Java', 'JavaScript', 'Lisp', 'Perl', 'PHP', 'Python', 'Ruby', 'Scala', 'Scheme'];
        return function (keyword) {
            var /** @type {?} */ filteredList = data.filter(function (el) { return el.indexOf(keyword) !== -1; });
            return Observable$1.of(filteredList);
        };
    };
    /**
     * Método para fazer a interação entre os componentes ps-calendar-availability e ps-frm-select-list.
     * @param {?} date Data selecionada no calendário.
     * @param {?} psFormField
     * @param {?} selectList Referência ao elemento select contido no componente ps-frm-select-list.
     * @param {?} psFormSelectList Referência ao componente ps-frm-select-list.
     * @return {?}
     */
    Util.prototype.openCaledarSchedules = /**
     * Método para fazer a interação entre os componentes ps-calendar-availability e ps-frm-select-list.
     * @param {?} date Data selecionada no calendário.
     * @param {?} psFormField
     * @param {?} selectList Referência ao elemento select contido no componente ps-frm-select-list.
     * @param {?} psFormSelectList Referência ao componente ps-frm-select-list.
     * @return {?}
     */
    function (date, psFormField, selectList, psFormSelectList) {
        selectList.innerHTML = null;
        switch (date) {
            case '02/05/2018':
                this._addOptions(selectList, ['10:30', '11:00', '14:00', '15:30']);
                break;
            case '22/05/2018':
                this._addOptions(selectList, ['01:15', '02:00', '03:00', '04:30']);
                break;
            case '23/05/2018':
                this._addOptions(selectList, ['06:30', '07:00', '08:00', '09:30']);
                break;
            case '25/05/2018':
                this._addOptions(selectList, ['12:30', '13:00', '14:00', '15:30']);
                break;
            case '30/05/2018':
                this._addOptions(selectList, ['20:30', '21:15', '22:10', '23:30']);
                break;
        }
        this._renderer2.setStyle(psFormField.getHostElement(), 'display', 'block');
        psFormSelectList.renderSelectList();
    };
    /**
     * Método privado para adicionar elementos <options></options> dentro de um elemento select.
     * @param {?} selectList Referência ao elemento select.
     * @param {?} options Array de valores que a serem usados na criação dos options.
     * @return {?}
     */
    Util.prototype._addOptions = /**
     * Método privado para adicionar elementos <options></options> dentro de um elemento select.
     * @param {?} selectList Referência ao elemento select.
     * @param {?} options Array de valores que a serem usados na criação dos options.
     * @return {?}
     */
    function (selectList, options) {
        var /** @type {?} */ self = this;
        Array.prototype.forEach.call(options, function (option, l) {
            self._renderer2.appendChild(selectList, self._createOption(option));
        });
    };
    /**
     * Método privado para criar um elemento <options></options>.
     * @param {?} text Texto para o option.
     * @param {?=} value Valor do atributo value do option.
     * @return {?} Referência a um HTMLOptionElement criado com os parâmetros fornecidos.
     */
    Util.prototype._createOption = /**
     * Método privado para criar um elemento <options></options>.
     * @param {?} text Texto para o option.
     * @param {?=} value Valor do atributo value do option.
     * @return {?} Referência a um HTMLOptionElement criado com os parâmetros fornecidos.
     */
    function (text, value) {
        var /** @type {?} */ option = this._renderer2.createElement('option');
        option.text = text;
        option.value = (typeof value === 'undefined') ? text : value;
        return option;
    };
    Util.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    Util.ctorParameters = function () { return [
        { type: Http, },
        { type: RendererFactory2, },
    ]; };
    return Util;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var PsGuideModule = (function () {
    function PsGuideModule() {
    }
    /**
     * @return {?}
     */
    PsGuideModule.forRoot = /**
     * @return {?}
     */
    function () {
        return {
            ngModule: PsGuideModule,
            providers: [Logger, FormValidate, Platform, ClickOutsideDirective, Util]
        };
    };
    PsGuideModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        PsAccordionModule,
                        PsAutocompleteModule,
                        PsBadgeModule,
                        PsBtnModule,
                        PsCalendarModule,
                        PsCalendarAvailabilityModule,
                        PsCardModule,
                        PsCarouselModule,
                        PsChartModule,
                        PsDatagridModule,
                        PsDataviewModule,
                        PsFormResourcesModule,
                        PsGridModule,
                        PsIcoModule,
                        PsListModule,
                        PsLoadingModule,
                        PsMenuModule,
                        PsModalModule,
                        PsNotifyModule,
                        PsPanelModule,
                        PsPopoverModule,
                        PsSharerModule,
                        PsSliderModule,
                        PsTableModule,
                        PsTabsModule,
                        PsTitleModule,
                        PsTooltipModule,
                        PsWizardModule
                    ],
                    exports: [
                        PsAccordionModule,
                        PsAutocompleteModule,
                        PsBadgeModule,
                        PsBtnModule,
                        PsCalendarModule,
                        PsCalendarAvailabilityModule,
                        PsCardModule,
                        PsCarouselModule,
                        PsChartModule,
                        PsDatagridModule,
                        PsDataviewModule,
                        PsFormResourcesModule,
                        PsGridModule,
                        PsIcoModule,
                        PsListModule,
                        PsLoadingModule,
                        PsMenuModule,
                        PsModalModule,
                        PsNotifyModule,
                        PsPanelModule,
                        PsPopoverModule,
                        PsSharerModule,
                        PsSliderModule,
                        PsTableModule,
                        PsTabsModule,
                        PsTitleModule,
                        PsTooltipModule,
                        PsWizardModule
                    ],
                    declarations: [
                        PsSanitizeHTMLPipe
                    ]
                },] },
    ];
    /** @nocollapse */
    PsGuideModule.ctorParameters = function () { return []; };
    return PsGuideModule;
}());

export { PsGuideModule, PsAccordionModule, PsAccordionPanelComponent, PsAccordionComponent, PsAutocompleteModule, PsAutocompleteComponent, PsBadgeModule, PsBadgeComponent, PsBadgeAlertComponent, PsBtnModule, PsBtnBase, PsBtnDirective, PsBtnPrimaryDirective, PsBtnAlertDirective, PsCalendarModule, CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR, PsCalendarComponent, PsCalendarModel, PsCalendarStyle, PsCalendarAvailabilityModule, PsDateDirective, PsCalendarAvailabilityComponent, PsCardModule, PsCardComponent, PsCarouselModule, PsCarouselComponent, PsChartModule, PsChartComponent, PsDatagridModule, PsDatagridComponent, PsDataviewModule, PsDataviewDirective, PsFieldEntryDirective, PsFormCheckboxDirective, PsFormFieldItemComponent, PsFormFieldComponent, PsFormMultiselectComponent, PsFormOnOffComponent, PsFormRadioDirective, PsFormResourcesModule, PsFormSelectListComponent, PsFormSelectComponent, PsFormTextAreaDirective, PsFrmCleanupDirective, PsMaskDirective, PsGridModule, PsGridDirective, PsGridFluidDirective, PsGridRowDirective, PsGridColumnDirective, PsIcoModule, PsIcoComponent, PsListModule, PsListDirective, PsListGrpDirective, PsLoadingModule, PsLoadingComponent, PsLoadingBarComponent, PsMenuModule, PsMenuDirective, PsListIcoDirective, PsModalRefComponent, PsModalAttributes, PsModalTitleDirective, PsModalContentDirective, PsModalFootDirective, PsModalComponent, PsModalModule, PsModalService, PsNotifyComponent, PsNotifyDirective, PsNotifyModule, PsNotifyService, PsPanelHeadDirective, PsPanelCttDirective, PsPanelFootDirective, PsPanelComponent, PsPanelModule, PsPopoverTitleDirective, PsPopoverContentDirective, PsPopoverComponent, PsPopoverModule, PsSharerComponent, PsSharerModule, PsRangeSliderComponent, PsSliderComponent, PsSliderModule, PsSliderStyle, PsTableDirective, PsTableModule, PsTabTitleDirective, PsTabContentDirective, PsTabsBase, PsTabComponent, PsTabsComponent, PsTabsModule, PsTitleDirective, PsTitleModule, PsTooltipCttDirective, PsTooltipComponent, PsTooltipDirective, PsTooltipModule, PsWizardLabelDirective, PsWizardContentDirective, PsWizardSubmitRowDirective, PsWizardStepComponent, PsWizardComponent, PsWizardModule, ClickOutsideDirective, FormValidate, Logger, Platform, PsSanitizeHTMLPipe, Util };
