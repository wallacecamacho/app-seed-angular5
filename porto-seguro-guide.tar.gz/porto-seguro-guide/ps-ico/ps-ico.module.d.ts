export declare class PsIcoModule {
}
