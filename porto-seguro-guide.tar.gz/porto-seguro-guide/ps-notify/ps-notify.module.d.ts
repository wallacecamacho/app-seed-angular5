export declare class PsNotifyModule {
}
