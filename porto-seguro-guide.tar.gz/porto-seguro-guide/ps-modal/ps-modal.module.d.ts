export declare class PsModalModule {
}
