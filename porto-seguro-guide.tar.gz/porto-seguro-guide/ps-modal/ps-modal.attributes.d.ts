/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Classe que contém o mapeamento de atributos e css do componente PsModal.
 */
export declare class PsModalAttributes {
    static ATTRIBUTES: {
        prop: string;
        css: string;
    }[];
}
