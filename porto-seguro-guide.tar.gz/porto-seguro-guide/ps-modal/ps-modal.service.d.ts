/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { ComponentFactoryResolver, Renderer2, Injector, ViewContainerRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
/**
 * Service para criar um componente modal dinamicamente.
 */
export declare class PsModalService {
    private _renderer2;
    private _injector;
    private _resolver;
    /** Variável para listeners do callback chamado depois de abrir o modal. */
    private readonly _afterOpen;
    /** Variável para listeners do callback chamado depois de fechar o modal. */
    private _afterClosed;
    /** Referência do componente modal criado dinamicamente.  */
    private componentRef;
    constructor(_renderer2: Renderer2, _injector: Injector, _resolver: ComponentFactoryResolver);
    /**
     * Método que configura, cria e abre um componente modal.
     * @param config Valores de configuração passados para o modal.
     * @param viewContainerRef Referência passada do componente que utiliza o service.
     * @param afterOpen Valor que deve ser passado quando o modal abrir aos callbacks.
     * @param afterClosed Valor que deve ser passado quando o modal fechar aos callbacks.
     */
    openModal(config: any, viewContainerRef: ViewContainerRef, afterOpen?: any, afterClosed?: any): void;
    /** Método que retorna um Observable para escutar evento de abertura do modal.  */
    afterOpen(): Observable<void>;
    /** Método que fecha (esconde) o modal criado dinamicamente.  */
    closeModal(afterClosed?: any): void;
    /** Método que retorna um Observable para escutar evento de fechamento do modal.  */
    afterClosed(): Observable<void>;
}
