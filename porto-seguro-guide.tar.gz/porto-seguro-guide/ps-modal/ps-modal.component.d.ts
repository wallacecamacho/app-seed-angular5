/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, AfterViewInit, Renderer2, ElementRef, TemplateRef, EventEmitter } from '@angular/core';
import { Platform } from './../util/platform.service';
/**
 * `<ng-template ps-modal-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-modal>`.
 */
export declare class PsModalTitleDirective {
    templateRef: TemplateRef<any>;
    css?: string;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-tab-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-modal>`.
 */
export declare class PsModalContentDirective {
    templateRef: TemplateRef<any>;
    css?: string;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-modal-foot>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-modal>`.
 */
export declare class PsModalFootDirective {
    templateRef: TemplateRef<any>;
    css?: string;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ps-modal>`
 *
 * Componente Modal.
 */
export declare class PsModalComponent implements OnInit, AfterViewInit {
    private _renderer2;
    private _elementRef;
    private _platform;
    /** Flag que indica se o modal está visível ou não.  */
    _show?: boolean;
    /** Flag que desabilita o modal ser fechado clicando fora do mesmo. */
    _backdrop?: 'static' | false;
    /** Flag que controla a ação de fechar o teclado com a tecla esc. */
    _keyboard?: 'disable' | false;
    /** Referência ao elemento que contém o 'título' do modal.  */
    _modalTitle: PsModalTitleDirective;
    psModalTitle: ElementRef;
    /** Referência ao elemento que contém o 'conteúdo' do modal.  */
    _modalContent: PsModalContentDirective;
    psModalContent: ElementRef;
    /** Referência ao elemento que contém o 'rodapé' do modal.  */
    _modalFoot: PsModalFootDirective;
    psModalFoot: ElementRef;
    /** Evento disparado quando o modal é aberto (torna-se visível). */
    _modalOnShow?: EventEmitter<any>;
    /** Evento disparado quando o modal é fechado. */
    _modalOnHide?: EventEmitter<any>;
    /** Id único para o modal.  */
    _modalId: string;
    /** Id único para o container do modal. */
    _modalContainerId: string;
    /** Flag que controla se o modal é aberto. */
    _open?: boolean;
    /** Guarda o valor da propriedade display do modal. */
    _display?: string;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    /** Método que abre o modal. Geralmente, chamado de algum evento de outro componente. */
    open($event: any): void;
    /** Método que fecha o modal. */
    close(): void;
    /** Método que verifica se houve um clique fora do modal.  */
    closeOnClickedOutside(e: Event): void;
    onkeyup(ev: KeyboardEvent): void;
    /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @param $event Evento passado do elemento trigger.
     */
    private _setupTransitionModalBeforeOpen($event);
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement();
    /**
     * Configura a propriedade overflow do body.
     * @param overflow Valor da propriedade.
     */
    private _setBodyOverflow(overflow);
    /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @param css Classe css usada para a busca.
     * @returns Os elementos filhos que contém a classe css especificada.
     */
    private _getChildElementByClassName(css);
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes(...attributes);
    /** Adiciona classes css passadas como parâmetros nos elementos filhos do modal (title, content e foot).  */
    private _addCSSToViewChild();
    /**
     * Adiciona uma classe css ao elemento.
     * @param element Referência de elemento HTMLElement.
     * @param className Propriedade e valor css para ser adicionado no elemento.
     */
    private _addClass(element, className);
}
