/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
import { Platform } from '../util/platform.service';
import { Subject } from 'rxjs/Subject';
/**
 * Componente Modal aberto somente via service.
 */
export declare class PsModalRefComponent implements OnInit, AfterViewInit {
    private _renderer2;
    private _elementRef;
    private _platform;
    private psModalConfig;
    /** Flag que indica se o modal está visível ou não.  */
    _show?: boolean;
    /** Flag que desabilita o modal ser fechado clicando fora do mesmo. */
    _backdrop?: 'static' | false;
    /** Flag que controla a ação de fechar o teclado com a tecla esc. */
    _keyboard?: 'disable' | false;
    /** Referência ao elemento que contém o 'título' do modal.  */
    psModalTitle: ElementRef;
    /** Referência ao elemento que contém o 'conteúdo' do modal.  */
    psModalContent: ElementRef;
    /** Referência ao elemento que contém o 'rodapé' do modal.  */
    psModalFoot: ElementRef;
    /** Id único para o modal.  */
    _modalId: string;
    /** Id único para o container do modal. */
    _modalContainerId: string;
    /** Flag que controla se o modal é aberto. */
    _open?: boolean;
    /** Guarda o valor da propriedade display do modal. */
    _display?: string;
    /** Evento disparado quando o modal é fechado. */
    _afterClosedObservable: Subject<any>;
    afterClosed: any;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform, psModalConfig?: any);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    /** Método que abre o modal. Chamado pelo service do modal. */
    open($event: any): void;
    /** Método que fecha o modal. */
    close(): void;
    /** Método que verifica se houve um clique fora do modal.  */
    closeOnClickedOutside(e: Event): void;
    /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @param $event Evento passado do elemento trigger.
     */
    private _setupTransitionModalBeforeOpen($event);
    private _appendChild(element, content?);
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement();
    /**
     * Configura a propriedade overflow do body.
     * @param overflow Valor da propriedade.
     */
    private _setBodyOverflow(overflow);
    /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @param css Classe css usada para a busca.
     * @returns Os elementos filhos que contém a classe css especificada.
     */
    private _getChildElementByClassName(css);
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes(...attributes);
    /**
     * Adiciona uma classe css ao elemento.
     * @param element Referência de elemento HTMLElement.
     * @param className Propriedade e valor css para ser adicionado no elemento.
     */
    private _addClass(element, className);
}
