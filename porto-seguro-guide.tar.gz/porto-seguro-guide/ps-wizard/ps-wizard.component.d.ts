/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { Renderer2, ElementRef, TemplateRef, QueryList } from '@angular/core';
/**
 * `<ng-template ps-wizard-label>`
 *
 * Diretiva que corresponde ao label de um componente `<ps-wizard-step>`.
 */
export declare class PsWizardLabelDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-wizard-content>`
 *
 * Diretiva que corresponde ao conteúdo de um componente `<ps-wizard-step>`.
 */
export declare class PsWizardContentDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-wizard-submit-row>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-wizard-step>`.
 */
export declare class PsWizardSubmitRowDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ps-wizard-step>`
 *
 * Este componente corresponde ao elemento step (passo) de um `<ps-wizard>`.
 */
export declare class PsWizardStepComponent {
    private _elementRef;
    _selected?: boolean;
    label: PsWizardLabelDirective;
    content: PsWizardContentDirective;
    submitRow?: PsWizardSubmitRowDirective;
    stepId: number;
    constructor(_elementRef: ElementRef);
}
/**
 * `<ps-wizard>`
 *
 * Componente wizard (passo a passo).
 */
export declare class PsWizardComponent {
    private _renderer2;
    private _elementRef;
    /** Flag indicando se o componente deve mostar o ícone. */
    _icon?: boolean;
    /** Lista de componentes filhos. */
    _wizardSteps: QueryList<PsWizardStepComponent>;
    /** Id único para ser usado caso necessário (atribuído ao atributo id da div principal). */
    _wizardId: string;
    /** Guarda o número do passo atual. */
    private _actualStep;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /**
     * Método de suporte para a diretiva *ngFor do angular.
     * @param index Índice do laço.
     * @param step referência ao componente PsWizardStepComponent da iteração.
     * @returns Indíce do passo
     */
    trackBySteps(index: number, step: PsWizardStepComponent): number;
    /** Move para o próximo passo. */
    next(): void;
    /** Move para o passo anterior. */
    previous(): void;
    /**
     * Método chamado para selecionar o passo atual (variável _actualStep).
     * @param steps Coleção HTMLCollection representando os passos.
     */
    private _selecteStep(steps);
    /**
     * Método chamado para selecionar o bloco de conteúdo do passo atual (variável _actualStep).
     * @param stepContentItems Coleção HTMLCollection representando os conteúdos dos passos.
     */
    private _selectStepContent(stepContentItems);
    /** Retorna todos os passos (elementos filho com a classe 'ps-wizard-step'). */
    private _getAllSteps();
    /** Retorna todos os conteúdos dos passos (elementos filho com a classe 'ps-wizard-content-item'). */
    private _getAllStepContentItems();
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement();
}
