export declare class PsWizardModule {
}
