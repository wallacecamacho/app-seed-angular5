export declare class PsTooltipModule {
}
