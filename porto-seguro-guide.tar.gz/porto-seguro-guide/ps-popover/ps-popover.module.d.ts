export declare class PsPopoverModule {
}
