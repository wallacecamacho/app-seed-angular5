/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { EventEmitter, QueryList } from '@angular/core';
import { PsPanelHeadDirective, PsPanelCttDirective, PsPanelFootDirective } from '../ps-panel/ps-panel.component';
/**
 * `<ps-accordion-panel>`
 *
 * Este componente corresponde ao painel (panel) de um componente `<ps-accordion>`.
 */
export declare class PsAccordionPanelComponent {
    /** Contém o id único da painel. */
    accordionId: string;
    /** Flag para dizer se o painel está aberto. */
    open?: boolean;
    /** Flag para dizer se o painel está desabilitado, evitando de poder ser clicado. */
    disable?: boolean;
    /** Elemento filho com a diretiva de título do painel. */
    _psPanelHeadDirective: PsPanelHeadDirective;
    /** Elemento filho com a diretiva de conteúdo do painel. */
    _psPanelCttDirective: PsPanelCttDirective;
    /** Elemento filho com a diretiva de rodapé do painel. */
    _psPanelFootDirective: PsPanelFootDirective;
    constructor();
}
/**
 * `<ps-accordion>`
 *
 * Componente que contém os painés (accordion).
 */
export declare class PsAccordionComponent {
    /** Id do painel(s) que deve estar selecionado.  */
    activeIds: string | string[];
    /** Lista de componentes ps-accordion-panel.  */
    psAccordionPanels: QueryList<PsAccordionPanelComponent>;
    /** Flag que define se o accordion deve ser aberto por links.   */
    links?: boolean;
    /** Evento de callback quando um painel é aberto.  */
    _accordionOnOpen?: EventEmitter<any>;
    /** Evento de callback quando um painel é fechado.  */
    _accordionOnClose?: EventEmitter<any>;
    constructor();
    /** Método que abre o painel com o id passado como parâmetro e fecha todos os demais. Emite o evento de open.  */
    openAccordion(accordionId: string): void;
    /** Método que fecha todos os painéis com o id diferente do especificado como parâmetro. Emite o evento de close.  */
    private _closeOthers(accordionId);
    /** Atualiza a lista de Ids de accordions ativos e não desabilitados.  */
    private _updateActiveIds();
}
