export declare class PsAccordionModule {
}
