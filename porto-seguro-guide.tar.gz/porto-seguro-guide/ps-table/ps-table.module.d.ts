export declare class PsTableModule {
}
