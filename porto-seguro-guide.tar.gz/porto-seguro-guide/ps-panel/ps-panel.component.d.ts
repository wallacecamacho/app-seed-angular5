/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { TemplateRef } from '@angular/core';
/**
 * `<ng-template ps-panel-head>`
 *
 * Diretiva que corresponde ao 'cabeçalho' de um componente `<ps-panel>`.
 */
export declare class PsPanelHeadDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-panel-ctt>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-panel>`.
 */
export declare class PsPanelCttDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-panel-foot>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-panel>`.
 */
export declare class PsPanelFootDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ps-panel>`
 *
 * Componente panel.
 */
export declare class PsPanelComponent {
    /** Especifica o tipo do painel.  */
    _type?: string;
    /** Especifica o ícone do painel.  */
    _icon?: string;
    /** Referência ao elemento que contém o 'cabeçalho' do painel.  */
    _psPanelHeadTpl?: PsPanelHeadDirective;
    /** Referência ao elemento que contém o 'conteúdo' do painel.  */
    _psPanelCttTpl: PsPanelCttDirective;
    /** Referência ao elemento que contém o 'rodapé' do painel.  */
    _psPanelFootTpl?: PsPanelFootDirective;
    constructor();
}
