export declare class PsPanelModule {
}
