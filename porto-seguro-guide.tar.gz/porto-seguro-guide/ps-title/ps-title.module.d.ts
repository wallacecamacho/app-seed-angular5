export declare class PsTitleModule {
}
