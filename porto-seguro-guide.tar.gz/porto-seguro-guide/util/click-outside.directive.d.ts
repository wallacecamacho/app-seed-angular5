/**
 * @license
 * Copyright Eugene Cheung Rights Reserved.
 * @author
 * Eugene Cheung https://github.com/arkon/ng-click-outside
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/arkon/ng-click-outside/blob/master/LICENSE
 */
import { ElementRef, EventEmitter, OnChanges, OnDestroy, OnInit, SimpleChanges, NgZone } from '@angular/core';
export declare class ClickOutsideDirective implements OnInit, OnChanges, OnDestroy {
    private _el;
    private _ngZone;
    private platformId;
    attachOutsideOnClick: boolean;
    delayClickOutsideInit: boolean;
    exclude: string;
    excludeBeforeClick: boolean;
    clickOutsideEvents: string;
    clickOutsideEnabled: boolean;
    clickOutside: EventEmitter<Event>;
    private _nodesExcluded;
    private _events;
    constructor(_el: ElementRef, _ngZone: NgZone, platformId: Object);
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private _init();
    private _initOnClickBody();
    private _initClickListeners();
    private _excludeCheck();
    private _onClickBody(ev);
    private _shouldExclude(target);
}
