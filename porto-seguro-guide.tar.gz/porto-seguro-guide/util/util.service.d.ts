/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { RendererFactory2 } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import 'rxjs/add/observable/of';
import { PsFormSelectListComponent } from './../ps-form-resources/ps-form-select-list.component';
import { PsFormFieldComponent } from '../ps-form-resources/ps-form-field.component';
/**
 * Service para dar suporte aos exemplos de uso dos componentes.
 */
export declare class Util {
    http: Http;
    private _rendererFactory;
    /** Usado nos exemplos que modificam atributos dos elementos. */
    private _renderer2;
    constructor(http: Http, _rendererFactory: RendererFactory2);
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @param url a url que deve ser requisitada para consultar os dados.
     * @returns Referência para um objeto Observable contendo o resultado.
     */
    getObservableSourceFromUrlByGet(url: string): (keyword: any) => Observable<any[]>;
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @returns Referência para um objeto Observable contendo o resultado da consulta no Array data.
     */
    getObservableFromArray(): (keyword: any) => Observable<any[]>;
    /**
     * Método para fazer a interação entre os componentes ps-calendar-availability e ps-frm-select-list.
     * @param date Data selecionada no calendário.
     * @param PsFormFieldComponent Referência ao componente que contém o ps-frm-select-list.
     * @param selectList Referência ao elemento select contido no componente ps-frm-select-list.
     * @param psFormSelectList Referência ao componente ps-frm-select-list.
     */
    openCaledarSchedules(date: string, psFormField: PsFormFieldComponent, selectList: HTMLSelectElement, psFormSelectList: PsFormSelectListComponent): void;
    /**
     * Método privado para adicionar elementos <options></options> dentro de um elemento select.
     * @param selectList Referência ao elemento select.
     * @param options Array de valores que a serem usados na criação dos options.
     */
    private _addOptions(selectList, options);
    /**
     * Método privado para criar um elemento <options></options>.
     * @param text Texto para o option.
     * @param value Valor do atributo value do option.
     * @returns Referência a um HTMLOptionElement criado com os parâmetros fornecidos.
     */
    private _createOption(text, value?);
}
