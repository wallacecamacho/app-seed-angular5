/**
 * Service para validação dos inputs dos elementos de formulários utilizando máscaras.
 */
export declare class FormValidate {
    /**
     * Transforma uma data no formato americano yyyy-mm-dd.
     * @param str Data no format dd/mm/yyyy.
     * @returns Falso se o parâmetro for indefinido ou a data no formato yyyy-mm-dd.
     */
    FormCalendarDateFormatter(str: any): boolean | string;
    /**
     * Usa regex para testar se o email está em formato válido (texto, arroba, domínio, etc).
     * @param email Email.
     * @returns Verdadeiro se o email é válido, falso caso contrário.
     */
    FormValidateMail(email: string): boolean;
    /**
     * Valida um cpf usando o algoritmo padrão.
     * @param cpf Valor do cpf com pontuação.
     * @returns Verdadeiro se o cpf é válido, falso caso contrário.
     */
    FormValidateCPF(cpf: string): boolean;
    /**
     * Valida um CNPJ usando o algoritmo padrão.
     * @param cnpj Valor do cnpj com pontuação.
     * @returns Verdadeiro se o cnpj é válido, falso caso contrário.
     */
    FormValidateCNPJ(cnpj: string): boolean;
    /**
     * Valida um número de telefone, evita que seja aceita números iguais.
     * @param phone Número de telefone com pontuação.
     * @returns Verdadeiro se o telefone é válido, falso caso contrário.
     */
    FormValidatePhone(phone: any): boolean;
    /**
     * Remove caracteres que podem ocasionar problemas com encoding, permitindo ou não, números.
     * @param string Texto para ser limpo.
     * @param allowNumbers Opção de permitir números ou não.
     * @returns String contendo somente caracteres válidos.
     */
    FormCleanupString(string: any, allowNumbers: boolean): string;
}
