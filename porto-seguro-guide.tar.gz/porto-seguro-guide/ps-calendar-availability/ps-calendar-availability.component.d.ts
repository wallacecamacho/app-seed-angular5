/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { AfterContentInit, EventEmitter, ElementRef } from '@angular/core';
import 'pikaday';
/**
 * Diretiva que define o elemento que contém a data para o calendário.
 */
export declare class PsDateDirective {
    private elementRef;
    constructor(elementRef: ElementRef);
    getTextContent(): any;
}
/**
 * `<ps-calendar-availability>`
 *
 * Componente que define um calendário de disponibilidade de datas (Calendário in-page).
 * Usa o JavaScript Datepicker: https://github.com/dbushell/Pikaday
 */
export declare class PsCalendarAvailabilityComponent implements AfterContentInit {
    /** Texto do label do calendário.   */
    _label?: string;
    /** Valor do atributo name.  */
    _name?: string;
    /** Valor do atributo id.  */
    _id?: string;
    /** Formato da data. Padrão é dd/mm/yyyy */
    _format?: string;
    /** Evento de callback quando uma data é selecionada.  */
    onSelect: EventEmitter<any>;
    /** Lista de datas (elementos com a diretiva ps-date).  */
    private _psDates;
    /** Referência ao elemento datepicker (calendário em si).  */
    private _datepicker;
    /** Referência ao container do calendário.  */
    private _datepickerContainer;
    /** Objeto que cria o calendário.  */
    private _pikaday;
    constructor();
    /** Método hook do angular. Instancia e configura o calendário.  */
    ngAfterContentInit(): void;
}
