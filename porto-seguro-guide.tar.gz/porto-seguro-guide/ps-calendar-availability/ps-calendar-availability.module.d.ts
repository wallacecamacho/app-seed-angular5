export declare class PsCalendarAvailabilityModule {
}
