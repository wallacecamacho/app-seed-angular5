/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { AfterContentInit, Renderer2, ElementRef } from '@angular/core';
/**
 * `<ps-form-select-list>`
 *
 * Componente que configura uma lista de seleção a partir de um select.
 */
export declare class PsFormSelectListComponent implements AfterContentInit {
    private _renderer2;
    private _elementRef;
    /** Id da lista (opcional).  */
    _selectlistID?: string;
    /** Referência ao elemento select (HTMLSelectElement) que será usado para criar a lista.  */
    private selectElement;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    ngAfterContentInit(): void;
    /** Método que configura o select interno (tornando invísivel) e cria a lista (ul, li) a partir dele.  */
    renderSelectList(): void;
    /** Método que regista eventos na lista e sincroniza com o select.  */
    private _bindClickEventHandler(a, ul, selectList);
    /** Método que retorna um array contento os valores dos options no select.  */
    private _getSelectValues2Array(selectElement, addOnlyValue);
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param el Referência HTMLElement do elemento que deve ser testado.
     * @param selector Parâmetro para testar se o elemento possui.
     * @returns boolean.
     */
    private _is(el, selector);
    /** Retorna uma referência HTMLElement do componente. */
    private _getElementHost();
}
