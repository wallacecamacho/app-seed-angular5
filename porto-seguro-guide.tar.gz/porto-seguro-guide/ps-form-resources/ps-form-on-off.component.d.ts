/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { AfterViewInit, Renderer2, ElementRef } from '@angular/core';
/**
 * `<ps-form-on-off>`
 *
 * Componente que cria o toggle de on / off (liga / desliga).
 */
export declare class PsFormOnOffComponent implements AfterViewInit {
    private _renderer2;
    private _elementRef;
    /** Texto do label.  */
    _label: string;
    /** Id único gerado automaticamente para evitar problemas caso o usuário não tenha definido.  */
    private _psFormOnOffId;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Método que configura o label e o input checkbox contidos no componente.  */
    ngAfterViewInit(): void;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement();
}
