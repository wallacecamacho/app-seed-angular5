/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { AfterContentInit, Renderer2, ElementRef } from '@angular/core';
import { PsModalComponent } from './../ps-modal/ps-modal.component';
/**
 * `<ps-form-multiselect>`
 *
 * Componente que define o select no formato de multiselect podendo selecionar
 * mais de um item em uma lista.
 */
export declare class PsFormMultiselectComponent implements AfterContentInit {
    private _renderer2;
    private _elementRef;
    /** Texto do label que aparece em cima da lista.  */
    _label?: string;
    /** Texto do título do modal. */
    _title?: string;
    /** Texto da mensagem de erro.  */
    _onerror?: string;
    /** Referência ao modal do componente multiselect.  */
    _modalMultiselect: PsModalComponent;
    /** Array contendo as opções selecionadas no multiselect que são sincronizadas na select list de suporte.  */
    private _modalCheckboxList;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Inicia a configuração do componente multiselect e suas dependências.  */
    ngAfterContentInit(): void;
    /** Método que configura o multiselect quando o modal é fechado. */
    _formMultiSelectConfig(): void;
    /** Método que remove um item do multiselect e sincroniza com os checkboxes do modal.  */
    _formMultiSelectRemove(a_psFrmMultiselectRemove: any): void;
    /** Cria o elemento container que conterá os elementos do multiselect.  */
    private _createMultiselectContainer(isValid, isDisabled, listId, selectElement);
    /** Método que cria a lista de checkbox a partir dos options no select definido para o componente.  */
    private _createModalCheckboxList(selectOptions, thisId, modalItens, listBuffer);
    /** Método que cria um item (li) de lista (ul) e configura o link para exclusão. */
    private _createListItem(id, text, value);
    /**
     * Método que insere um novo elemento após o elemento alvo.
     * @param newElement Referência HTMLElement do novo elemento.
     * @param targetElement Referência HTMLElement do elemento que deve ser predecessor do novo.
     */
    private _insertAfter(newElement, targetElement);
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param el Referência HTMLElement do elemento que deve ser testado.
     * @param selector Parâmetro para testar se o elemento possui.
     * @returns boolean.
     */
    private _is(el, selector);
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement();
}
