/**
 * `<ps-form-select>`
 *
 * Componente de suporte para listas select adicionando um 'container' com a classe css específica.
 */
export declare class PsFormSelectComponent {
    constructor();
}
