/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
/**
 * Diretiva de atributo que configura um radio.
 */
export declare class PsFormRadioDirective implements OnInit, AfterViewInit {
    private _renderer2;
    private _elementRef;
    /** Variável que guarda o valor do atributo name do campo.  */
    private _name;
    /** Id único gerado automaticamente para evitar problemas caso o usuário não tenha definido.  */
    private _radioId;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Método hook do angular que configura o tipo, id e adicionada a classe css específica para o radio.  */
    ngOnInit(): void;
    ngAfterViewInit(): void;
    /** Método que adiciona o valor do atributo for do label.   */
    private _addForValueInLabel(forValue);
    /** Método que retorna o label correspondente ao campo. */
    private _getLabelElement();
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    private _getHostElement();
}
