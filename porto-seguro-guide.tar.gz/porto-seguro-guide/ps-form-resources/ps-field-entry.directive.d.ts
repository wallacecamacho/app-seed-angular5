/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, AfterViewChecked, Renderer2, ElementRef } from '@angular/core';
import { FormValidate } from './../util/form-validate.service';
/**
 * Diretiva de atributo que configura os diferentes tipos de campos dos elementos e formulários.
 */
export declare class PsFieldEntryDirective implements OnInit, AfterViewChecked {
    private _renderer2;
    private _elementRef;
    private _formValidate;
    /** Variável que guarda o tipo do campo.  */
    private _fieldType;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _formValidate: FormValidate);
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    focus(): void;
    blur(): void;
    keydown(event: KeyboardEvent): void;
    change(): void;
    /**
     * Método que configura o input com a classe para animação do label.
     * @param isToAdd Flag para inserir ou remover a classe css.
     */
    private _addFormLabelFocusCSS(isToAdd);
    /** Método que verifica e adiciona os atributos no campo input.  */
    private _setAttributes();
    /** Método de validação do campo dependendo tipo (é reforçado pela mask / máscara). */
    private _validate();
    /**
     * Método que permiti somente caracteres numéricos.
     * @param e KeyboardEvent
     */
    private _validateNumbers(e);
    /** Método que verifica se o elemento contém uma data válida (formato dd/mm/yyy) criando um objeto Date.  */
    private _validateDate();
    /**
     * Método que adiciona ou remove a classe de erro no campo.
     * @param add Flag para adicionar ou remover a classe css.
     */
    private _addErrorCSS(add);
    /**
     * Método que remove a pontuação de um texto.
     * @param value Texto que deve ter a pontuação removida .
     */
    private _removePontuationCharacters(value);
    /** Retorna uma referência HTMLElement contendo a diretiva. */
    private _getHostElement();
    /**
     * Método que retorna o label correspondente ao campo.
     * Levando em conta se existe o componente popover.
     */
    private _getLabelElement();
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes(...attributes);
}
