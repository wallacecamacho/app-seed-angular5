export declare class PsFormResourcesModule {
}
