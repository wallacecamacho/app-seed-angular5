import 'hammerjs';
export declare class PsCarouselModule {
}
