/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, TemplateRef } from '@angular/core';
import { NgxCarousel } from 'ngx-carousel';
/**
 * `<ps-carousel>`
 *
 * Componente para criação de carrossel (slider de imagens, cards, etc.).
 * Baseado no componente 'ngx-carousel': https://github.com/sheikalthaf/ngx-carousel
 */
export declare class PsCarouselComponent implements OnInit {
    private carouselElement;
    private btnLeft;
    private btnRight;
    arrow: boolean;
    points: boolean;
    start: number;
    interval: number;
    slidesToScroll: number;
    template: TemplateRef<any>;
    slidesToShow: number;
    loop: boolean;
    responsive: any;
    dataItem: Array<any>;
    arrowOri: boolean;
    config: {};
    carousel: NgxCarousel;
    ngOnInit(): void;
    onResize(event: any): void;
    setConfig(type: any, value: any): void;
    loadMain(): void;
    btnLeftRight(status: boolean): void;
    loadResponsive(): void;
    afterCarouselViewedFn(data: any): void;
}
