export declare class PsCardModule {
}
