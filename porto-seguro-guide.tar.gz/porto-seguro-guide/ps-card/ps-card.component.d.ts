/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { Renderer2, AfterContentInit, ElementRef } from '@angular/core';
/**
 * `<ps-card>`
 *
 * Componente que cria um card (cartão ou painel) responsive.
 */
export declare class PsCardComponent implements AfterContentInit {
    private _renderer;
    private _elementRef;
    constructor(_renderer: Renderer2, _elementRef: ElementRef);
    /** Método hook do angular que adiciona as classes css de acordo com os atributos contidos no  host elemento.  */
    ngAfterContentInit(): void;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement();
    /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @param css Classe css usada para a busca.
     * @returns Os elementos filhos que contém a classe css especificada.
     */
    private _getChildElementByClassName(css);
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes(...attributes);
}
