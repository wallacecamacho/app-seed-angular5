export declare class PsListModule {
}
