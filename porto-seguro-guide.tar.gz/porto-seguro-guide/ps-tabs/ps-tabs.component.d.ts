/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { AfterContentChecked, OnInit, QueryList, TemplateRef, Renderer2, ElementRef, EventEmitter } from '@angular/core';
/**
 * `<ng-template ps-tab-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-tab>`.
 */
export declare class PsTabTitleDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-tab-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-tab>`.
 */
export declare class PsTabContentDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/** Superclasse para o componente ps-tab e seu pai ps-tabs.  */
export declare class PsTabsBase {
    _elementRef: ElementRef;
    constructor(_elementRef: ElementRef);
    /** Retorna uma referência HTMLElement do componente. */
    protected _getHostElement(): any;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    protected _hasHostAttributes(...attributes: string[]): boolean;
}
/**
 * `<ps-tab>`
 *
 * Este componente corresponde a aba (tab) de um componente `<ps-tabs>`.
 */
export declare class PsTabComponent extends PsTabsBase implements OnInit {
    /** Contém o id único da aba. */
    tabIndex: string;
    /** Flag para dizer se a aba está selecionada. */
    selected?: boolean;
    /** Elemento filho com a diretiva de título da aba. */
    _titleTpl: PsTabTitleDirective;
    /** Elemento filho com a diretiva de conteúdo da aba. */
    _contentTpl: PsTabContentDirective;
    /** Flag para dizer se a aba possui ícone (se sim, é adicionada uma classe). */
    hasIco?: boolean;
    constructor(_elementRef: ElementRef);
    ngOnInit(): void;
}
/**
 * `<ps-tabs>`
 *
 * Componente que contém as tabs (Abas).
 */
export declare class PsTabsComponent extends PsTabsBase implements OnInit, AfterContentChecked {
    private _renderer2;
    /** Lista de componentes ps-tab.  */
    tabs: QueryList<PsTabComponent>;
    /** Id da aba que deve estar ativada (selecionada).  */
    activeTabId?: string;
    /** Referência a lista de títulos das abas  */
    psTabs: ElementRef;
    /** Evento de callback quando uma aba é aberta.  */
    _ontabshow?: EventEmitter<any>;
    /** Evento de callback quando uma aba é fechada.  */
    _ontabhide?: EventEmitter<any>;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    ngOnInit(): void;
    ngAfterContentChecked(): void;
    /**
     * Método para selecionar uma aba pelo índice.
     * @param tabIndex Índice da tab.
     */
    selectTabByIndex(tabIndex: string): void;
    /**
     * Método que retorna um componente PsTabComponent pelo correspondente índice.
     * @param tabIndex Índice da tab.
     * @returns Referência da tab (PsTabComponent).
     */
    getTabByIndex(tabIndex: string): PsTabComponent;
}
