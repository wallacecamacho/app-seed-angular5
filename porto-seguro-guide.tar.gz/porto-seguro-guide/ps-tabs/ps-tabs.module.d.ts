export declare class PsTabsModule {
}
