export declare class PsSharerModule {
}
