export declare class PsAutocompleteModule {
}
