/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { Renderer2, ElementRef, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Observable';
/**
 * `<ps-autocomplete>`
 *
 * Complemente autocomplete.
 * Baseado no componente 'ng2-ui': https://github.com/ng2-ui/auto-complete
 */
export declare class PsAutocompleteComponent {
    private _renderer2;
    private _elementRef;
    /** Variável que define o atributo name do campo input encapsulado.  */
    _name: string;
    /** Variável que define o atributo placeholder campo input encapsulado.  */
    _placeholder?: string;
    /** Variável que define o atributo minlength (comprimento mínimo) campo input encapsulado. */
    _minlength?: number;
    /** Referência ao objeto Observable que é a fonte de dados do autocomplete.  */
    _source?: Observable<any[]>;
    /** Evento de callback quando um valor é selecionado.  */
    onselect: EventEmitter<any>;
    /** Variável que guarda o valor selecionado do autocomplete.  */
    selected: string;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    _onselect($event: any): void;
    getSelected(): string;
}
