export declare class PsGridModule {
}
