/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { Renderer2, ElementRef } from '@angular/core';
/**
 * Diretiva de atributo que configura uma Lista de campos adicionando a respectiva classe css.
 */
export declare class PsDataviewDirective {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
}
