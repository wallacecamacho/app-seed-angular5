export declare class PsDataviewModule {
}
