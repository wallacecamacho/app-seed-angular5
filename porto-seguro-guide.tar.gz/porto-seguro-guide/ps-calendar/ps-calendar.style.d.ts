/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
/**
 * Classe que contém o css dos componentes PsCalendar e PsCalendarAvailability.
 * Obs.: Não foi usado um arquivo .scss por motivos de build da lib.
 * */
export declare class PsCalendarStyle {
    static readonly styles: string[];
}
