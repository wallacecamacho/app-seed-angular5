/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { OnInit, ElementRef, EventEmitter, Renderer2, OnChanges, AfterViewInit } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';
import { Platform } from './../util/platform.service';
import 'pikaday';
export declare const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any;
/**
 * `<ps-calendar>`
 *
 * Componente que define um calendário (Datepicker).
 * Usa o JavaScript Datepicker: https://github.com/dbushell/Pikaday
 */
export declare class PsCalendarComponent implements OnInit, OnChanges, AfterViewInit, ControlValueAccessor {
    private _renderer2;
    private _plaftform;
    private _elementRef;
    /** Valor do atributo name.  */
    _name?: string;
    /** Placeholder input */
    _placeholder: string;
    /** Valor do atributo id.  */
    _id?: string;
    /** Data padrão que o calendário usa sempre que for inicilizado.  */
    _defaultdate?: string;
    /** Data mínima que poderá ser selecionada.  */
    _mindate?: string;
    /** Data máxima que poderá ser selecionada.  */
    _maxdate?: string;
    /** Formato da data. Padrão é dd/mm/yyyy. */
    _format?: string;
    /** Entrada de controle de formulário. Útil na validação e acesso ao controle de formulários. */
    formControl: FormControl;
    /** Evento de callback quando uma data é selecionada.  */
    onSelect: EventEmitter<any>;
    /** Referência ao elemento datepicker (calendário em si).  */
    private _datepicker;
    /** Referência ao container do calendário.  */
    private _datepickerMobile;
    /** Objeto que cria o calendário.  */
    private _pikaday;
    /** Id único para o calendário.  */
    _calendarId: string;
    /** Flag que indica se o usuário está em dispositivo móvel ou não. */
    _isMobile: boolean;
    /** Erros para o controle de formulário serão armazenados neste array. */
    errors: Array<any>;
    private innerValue;
    propagateChange: (_: any) => void;
    _onTouched: () => void;
    constructor(_renderer2: Renderer2, _plaftform: Platform, _elementRef: ElementRef);
    /** Método hook do angular. Instancia e configura o calendário.  */
    ngOnInit(): void;
    ngOnChanges(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    /**
     * Evento acionado quando o valor de entrada é alterado.
     * Posteriormente propagado até o controle de formulário usando a
     * interface acessadora de valor personalizado.
     * */
    onChange(e: Event, value: any): void;
    onblur(): void;
    value: any;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    /** Permite que o Angular desative o input. */
    setDisabledState(isDisabled: boolean): void;
    /** Método que cria o link e registra o evento de fechar o calendário.  */
    private _createCloseElement(calendarElement);
    /** Método que valida a data no ambiente mobile, pois o calendário usado é o nativo do browser.  */
    validateCalendarMobile(): void;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement();
    /** Retorna uma referência HTMLElement do componente na versão mobile. */
    private _getMobileHostElement();
}
