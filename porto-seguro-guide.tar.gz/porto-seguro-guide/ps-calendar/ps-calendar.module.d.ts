export declare class PsCalendarModule {
}
