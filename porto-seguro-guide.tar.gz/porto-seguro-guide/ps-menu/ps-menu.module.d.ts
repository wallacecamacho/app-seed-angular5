export declare class PsMenuModule {
}
